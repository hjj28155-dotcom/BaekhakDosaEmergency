package com.baekhak.centralcontrol;

import android.Manifest;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Rational;
import android.content.res.Configuration;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.content.ClipData;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** V1052: one in-app video player. MP4/AVI never spawn duplicate external players. */
public class LocalMediaPickerActivity extends Activity {
    public static final String EXTRA_MIME="mime";
    private static final int REQ_VIDEO=7311;
    private static final int REQ_VIDEO_PICK=7312;
    private String wantedMime="video/mp4";
    private String mode="MP4";
    private int pendingStep=0;
    private String pendingControl="open";
    private VideoView video;
    private TextView title;
    private Uri currentUri;
    private Button fullscreen;
    private Button importVideo;
    private boolean full=false;
    private MediaPlayer preparedPlayer;
    private LinearLayout fullControls;
    private SeekBar seek;
    private Button playPause;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable hideControls=()->{ if(full && fullControls!=null) fullControls.setVisibility(View.GONE); };
    private final Runnable seekUpdater=new Runnable(){ @Override public void run(){ try{ if(video!=null&&seek!=null&&currentUri!=null){ int d=video.getDuration(),p=video.getCurrentPosition(); if(d>0){seek.setMax(d);if(!seek.isPressed())seek.setProgress(p);} updatePlayPauseLabel(); }}catch(Exception ignored){} handler.postDelayed(this,500); } };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); buildUi(); configurePip(); handleIntent(getIntent(),true); handler.post(seekUpdater);
    }

    /** V1060: keep video visible over other apps using Android Picture-in-Picture. */
    private void configurePip(){
        if(Build.VERSION.SDK_INT>=26){
            try{
                PictureInPictureParams.Builder b=new PictureInPictureParams.Builder()
                        .setAspectRatio(currentPipRatio());
                if(Build.VERSION.SDK_INT>=31)b.setAutoEnterEnabled(true);
                setPictureInPictureParams(b.build());
            }catch(Exception ignored){}
        }
    }
    private Rational currentPipRatio(){
        int w=16,h=9;
        try{
            if(preparedPlayer!=null&&preparedPlayer.getVideoWidth()>0&&preparedPlayer.getVideoHeight()>0){
                w=preparedPlayer.getVideoWidth();h=preparedPlayer.getVideoHeight();
            }
        }catch(Exception ignored){}
        // Android PIP aspect-ratio limits are generous, but clamp pathological files.
        if(w<=0||h<=0){w=16;h=9;}
        return new Rational(w,h);
    }
    private void updatePipParams(){
        if(Build.VERSION.SDK_INT>=26){
            try{
                PictureInPictureParams.Builder b=new PictureInPictureParams.Builder().setAspectRatio(currentPipRatio());
                if(Build.VERSION.SDK_INT>=31)b.setAutoEnterEnabled(true);
                setPictureInPictureParams(b.build());
            }catch(Exception ignored){}
        }
    }
    private void setPipChrome(boolean pip){
        if(title!=null)title.setVisibility(pip?View.GONE:View.VISIBLE);
        if(fullscreen!=null)fullscreen.setVisibility(pip?View.GONE:View.VISIBLE);
        if(importVideo!=null)importVideo.setVisibility(pip?View.GONE:View.VISIBLE);
        if(fullControls!=null)fullControls.setVisibility(View.GONE);
    }
    @Override public void onUserLeaveHint(){
        super.onUserLeaveHint();
        if(Build.VERSION.SDK_INT>=26 && !isInPictureInPictureMode() && currentUri!=null){
            try{
                boolean playing=video!=null&&video.isPlaying();
                if(playing){
                    updatePipParams();
                    enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(currentPipRatio()).build());
                }
            }catch(Exception ignored){}
        }
    }
    @Override public void onPictureInPictureModeChanged(boolean inPip, Configuration newConfig){
        super.onPictureInPictureModeChanged(inPip,newConfig);
        setPipChrome(inPip);
        if(!inPip && !full){
            getWindow().getDecorView().setSystemUiVisibility(0);
            setPipChrome(false);
        }
    }

    @Override protected void onNewIntent(Intent i){
        super.onNewIntent(i); setIntent(i); handleIntent(i,false);
    }
    private Button ctl(String text){ Button b=new Button(this);b.setText(text);b.setTextSize(13);b.setTextColor(Color.WHITE);b.setBackgroundColor(0xCC12324A);b.setPadding(8,4,8,4);return b; }
    private void buildUi(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
        video=new VideoView(this);root.addView(video,new FrameLayout.LayoutParams(-1,-1));
        title=new TextView(this);title.setTextColor(Color.WHITE);title.setTextSize(15);title.setGravity(Gravity.CENTER);title.setBackgroundColor(0x99000000);title.setPadding(12,10,12,10);root.addView(title,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
        fullscreen=ctl("⛶ 전체화면");fullscreen.setOnClickListener(v->{setFullscreen(!full);showControls();});FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT);fp.setMargins(8,8,8,8);root.addView(fullscreen,fp);
        importVideo=ctl("＋ 불러오기");importVideo.setOnClickListener(v->openVideoPicker());FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);ip.setMargins(8,8,8,8);root.addView(importVideo,ip);
        fullControls=new LinearLayout(this);fullControls.setOrientation(LinearLayout.VERTICAL);fullControls.setPadding(8,6,8,8);fullControls.setBackgroundColor(0xB0000000);fullControls.setVisibility(View.GONE);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER);row.setOrientation(LinearLayout.HORIZONTAL);
        Button back10=ctl("⏪ 10초");playPause=ctl("▶ 재생");Button fwd10=ctl("10초 ⏩");Button stop=ctl("■ 종료");Button normal=ctl("↩ 원래화면");
        row.addView(back10,new LinearLayout.LayoutParams(0,-2,1));row.addView(playPause,new LinearLayout.LayoutParams(0,-2,1));row.addView(fwd10,new LinearLayout.LayoutParams(0,-2,1));row.addView(stop,new LinearLayout.LayoutParams(0,-2,1));row.addView(normal,new LinearLayout.LayoutParams(0,-2,1));
        seek=new SeekBar(this);fullControls.addView(row,new LinearLayout.LayoutParams(-1,-2));fullControls.addView(seek,new LinearLayout.LayoutParams(-1,-2));root.addView(fullControls,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
        back10.setOnClickListener(v->{seekBy(-10000);showControls();});fwd10.setOnClickListener(v->{seekBy(10000);showControls();});playPause.setOnClickListener(v->{toggle();showControls();});stop.setOnClickListener(v->stopAndClose());normal.setOnClickListener(v->setFullscreen(false));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean from){if(from&&video!=null)try{video.seekTo(p);}catch(Exception ignored){}}public void onStartTrackingTouch(SeekBar s){handler.removeCallbacks(hideControls);}public void onStopTrackingTouch(SeekBar s){showControls();}});
        video.setOnClickListener(v->{if(full){if(fullControls.getVisibility()==View.VISIBLE){fullControls.setVisibility(View.GONE);handler.removeCallbacks(hideControls);}else showControls();}});
        setContentView(root);video.setOnCompletionListener(mp->selectAndPlayPrivateAware(1));video.setOnErrorListener((mp,what,extra)->{Toast.makeText(this,"이 영상을 재생할 수 없습니다.",Toast.LENGTH_LONG).show();return true;});
    }
    private void handleIntent(Intent i, boolean first){
        if(i!=null&&i.getStringExtra(EXTRA_MIME)!=null)wantedMime=i.getStringExtra(EXTRA_MIME);
        mode="video/x-msvideo".equals(wantedMime)?"AVI":"MP4";
        pendingStep=i==null?0:i.getIntExtra("step",0);
        pendingControl=i==null?"open":i.getStringExtra("control"); if(pendingControl==null)pendingControl="open";
        if("stop".equals(pendingControl)){ stopAndClose(); return; }
        if(!first && "toggle".equals(pendingControl) && currentUri!=null){ toggle(); return; }
        // V1059: READ_MEDIA_VIDEO 전체권한/Movies 자동검색을 쓰지 않습니다.
        // 내부보관본이 있으면 재생하고, 없으면 사용자가 직접 필요한 파일을 고릅니다.
        selectAndPlayPrivateAware(pendingStep);
    }
    private boolean needsPermission(){return Build.VERSION.SDK_INT>=23&&checkSelfPermission(videoPermission())!=PackageManager.PERMISSION_GRANTED;}
    private String videoPermission(){return Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_EXTERNAL_STORAGE;}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_VIDEO&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)selectAndPlayPrivateAware(pendingStep);else{Toast.makeText(this,"동영상 권한을 허용해 주세요.",Toast.LENGTH_LONG).show();finish();}}
    private void toggle(){if(video==null||currentUri==null)return;try{if(video.isPlaying())video.pause();else video.start();}catch(Exception ignored){}updateVideoPlayingPref();updatePlayPauseLabel();}
    private void updatePlayPauseLabel(){if(playPause!=null&&video!=null)try{playPause.setText(video.isPlaying()?"⏸ 일시정지":"▶ 재생");}catch(Exception ignored){}}
    private void updateVideoPlayingPref(){boolean p=false;try{p=video!=null&&video.isPlaying();}catch(Exception ignored){}getSharedPreferences("overlay_control",MODE_PRIVATE).edit().putBoolean("video_playing",p).apply();}
    private void seekBy(int delta){if(video==null||currentUri==null)return;try{int d=video.getDuration(),p=Math.max(0,video.getCurrentPosition()+delta);if(d>0)p=Math.min(d,p);video.seekTo(p);}catch(Exception ignored){}}
    private void showControls(){if(!full||fullControls==null)return;fullControls.setVisibility(View.VISIBLE);updatePlayPauseLabel();handler.removeCallbacks(hideControls);handler.postDelayed(hideControls,4000);}
    private void applyScaling(){if(preparedPlayer==null)return;try{preparedPlayer.setVideoScalingMode(full?MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING:MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT);}catch(Exception ignored){}}
    private void stopAndClose(){
        try{ if(video!=null)video.stopPlayback(); }catch(Exception ignored){}
        getSharedPreferences("overlay_control",MODE_PRIVATE).edit().putBoolean("video_playing",false).apply();
        if(Build.VERSION.SDK_INT>=21)finishAndRemoveTask();else finish();
    }
    private void setFullscreen(boolean enable){
        int pos=video==null?0:video.getCurrentPosition();boolean was=video!=null&&video.isPlaying();full=enable;
        if(enable){try{startService(new Intent(this,OverlayControlService.class).setAction(OverlayControlService.ACTION_SUSPEND));}catch(Exception ignored){}setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);if(title!=null)title.setVisibility(View.GONE);if(fullscreen!=null)fullscreen.setVisibility(View.GONE);if(importVideo!=null)importVideo.setVisibility(View.GONE);showControls();}
        else{handler.removeCallbacks(hideControls);if(fullControls!=null)fullControls.setVisibility(View.GONE);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);getWindow().getDecorView().setSystemUiVisibility(0);if(title!=null)title.setVisibility(View.VISIBLE);if(fullscreen!=null){fullscreen.setText("⛶ 전체화면");fullscreen.setVisibility(View.VISIBLE);}if(importVideo!=null)importVideo.setVisibility(View.VISIBLE);try{startService(new Intent(this,OverlayControlService.class).setAction(OverlayControlService.ACTION_RESUME));}catch(Exception ignored){}}
        applyScaling();if(video!=null&&pos>0){final int p=pos;video.postDelayed(()->{try{video.seekTo(p);if(was)video.start();updateVideoPlayingPref();updatePlayPauseLabel();}catch(Exception ignored){}},250);}
    }
    @Override public void onBackPressed(){if(full){setFullscreen(false);return;}stopAndClose();}
    private List<VideoLibraryStore.Item> savedForMode(){
        List<VideoLibraryStore.Item> all=new VideoLibraryStore(this).read();
        ArrayList<VideoLibraryStore.Item> out=new ArrayList<>();
        for(VideoLibraryStore.Item x:all){
            String n=x.name==null?"":x.name.toLowerCase(java.util.Locale.ROOT);
            if(("MP4".equals(mode)&&n.endsWith(".mp4")) || ("AVI".equals(mode)&&n.endsWith(".avi"))) out.add(x);
        }
        return out;
    }
    private void selectAndPlayPrivateAware(int step){
        List<VideoLibraryStore.Item> saved=savedForMode();
        if(!saved.isEmpty()){ playPrivate(saved,step); return; }
        openVideoPicker();
    }
    private void openVideoPicker(){
        try{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("MP4".equals(mode)?"video/mp4":"video/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
                try{i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,Uri.parse("content://com.android.externalstorage.documents/document/primary%3AMovies"));}catch(Exception ignored){}
            }
            startActivityForResult(i,REQ_VIDEO_PICK);
        }catch(Exception e){Toast.makeText(this,"영상 선택 화면을 열지 못했습니다.",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQ_VIDEO_PICK)return;
        if(resultCode!=RESULT_OK||data==null){
            if(currentUri==null&&savedForMode().isEmpty())Toast.makeText(this,"불러올 영상을 선택하지 않았습니다.",Toast.LENGTH_SHORT).show();
            return;
        }
        final ArrayList<Uri> picked=new ArrayList<>();
        ClipData cd=data.getClipData();
        if(cd!=null){for(int k=0;k<cd.getItemCount();k++){Uri u=cd.getItemAt(k).getUri();if(u!=null)picked.add(u);}}
        if(data.getData()!=null)picked.add(data.getData());
        if(picked.isEmpty()){Toast.makeText(this,"선택한 영상이 없습니다.",Toast.LENGTH_SHORT).show();return;}
        try{
            final int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            for(Uri u:picked){try{getContentResolver().takePersistableUriPermission(u,flags&Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}}
        }catch(Exception ignored){}
        Toast.makeText(this,"선택한 "+mode+" "+picked.size()+"개를 앱 내부에 보관하는 중입니다.",Toast.LENGTH_SHORT).show();
        new Thread(()->{
            try{
                int added=new VideoLibraryStore(LocalMediaPickerActivity.this).append(picked);
                runOnUiThread(()->{
                    List<VideoLibraryStore.Item> now=savedForMode();
                    Toast.makeText(LocalMediaPickerActivity.this,mode+" 내부보관 완료 · 새로 "+added+"개",Toast.LENGTH_LONG).show();
                    if(!now.isEmpty())playPrivate(now,0);
                });
            }catch(Exception e){runOnUiThread(()->Toast.makeText(LocalMediaPickerActivity.this,"영상 내부보관에 실패했습니다. 원본은 변경되지 않았습니다.",Toast.LENGTH_LONG).show());}
        },"Manual-Video-PrivateCopy").start();
    }
    private void playPrivate(List<VideoLibraryStore.Item> list,int step){
        if(list==null||list.isEmpty()){openVideoPicker();return;}String key="video_private_index_"+mode;int idx=getSharedPreferences("overlay_control",MODE_PRIVATE).getInt(key,0);if(step!=0)idx=(idx+step+list.size())%list.size();if(idx<0||idx>=list.size())idx=0;VideoLibraryStore.Item x=list.get(idx);currentUri=Uri.fromFile(new File(x.path));getSharedPreferences("overlay_control",MODE_PRIVATE).edit().putInt(key,idx).putString("media_mode",mode).putString("media_title",x.name).apply();title.setText(mode+" · "+x.name);video.stopPlayback();preparedPlayer=null;video.setVideoPath(x.path);video.setOnPreparedListener(mp->{preparedPlayer=mp;mp.setLooping(false);applyScaling();updatePipParams();video.start();updateVideoPlayingPref();updatePlayPauseLabel();if(full)showControls();});
    }
    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        if(video!=null)video.stopPlayback();
        getSharedPreferences("overlay_control",MODE_PRIVATE).edit().putBoolean("video_playing",false).apply();
        try{ startService(new Intent(this,OverlayControlService.class).setAction(OverlayControlService.ACTION_RESUME)); }catch(Exception ignored){}
        super.onDestroy();
    }
}
