package com.baekhak.centralcontrol;

import android.app.Activity;
import android.content.Intent;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.ContentValues;
import android.content.ContentUris;
import android.content.ComponentName;
import android.content.pm.ResolveInfo;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.view.View;
import android.view.Gravity;
import android.view.TextureView;
import android.view.Surface;
import android.graphics.SurfaceTexture;
import android.graphics.Color;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Date;
import java.util.UUID;
import java.text.SimpleDateFormat;

public class MainActivity extends Activity {
    private WebView webView;
    private String pendingData, pendingName, pendingMime;

    private static final int UPDATE_PICKER = 4303;
    private static final int SAVE_PICKER = 4304;
    private static final int TEXT_PICKER = 4305;
    private static final int LEGACY_BACKUP_PICKER = 4306;
    private static final int MUSIC_PICKER = 4307;
    private static final int APK_UPDATE_PICKER = 4308;
    private static final int MUSIC_FOLDER_PICKER = 4309;
    private static final int MUSIC_MULTI_PICKER = 4311;
    public static final String EXTRA_OPEN_SAVED_MUSIC = "v3_open_saved_music_library";
    public static final String EXTRA_OPEN_UPDATE = "v3_open_update";
    private static final int AUDIO_LIBRARY_PERMISSION = 4312;
    private static final int AUTO_AUDIO_PERMISSION = 4313;

    private static final String UPDATE_FILE = "shipmate_v3_update.html";
    private static final String BASE_URL = "file:///android_asset/";
    private static final int CONTENT_BUILD = BuildConfig.VERSION_CODE;
    private static final String UPDATE_STATS_URL = "https://jyqkohpeowkhuaohlezc.supabase.co/functions/v1/app-update-heartbeat";
    private static final String UPDATE_STATS_APP_KEY = "bxuiC99t7w3AG6PtIe-b3ui3xiIqRsRh-OKw0LU26qk";
    private static final String UPDATE_TRACK_PREFS = "v3_update_tracking";
    private static final String SPECIAL_APPROVAL_PREFS = "v3_round_special_approval";
    private static final String APPROVAL_REQUEST_URL = "https://jyqkohpeowkhuaohlezc.supabase.co/functions/v1/approval-request";
    private static final String APPROVAL_STATUS_URL = "https://jyqkohpeowkhuaohlezc.supabase.co/functions/v1/approval-status";
    private static final int SPECIAL_APPROVAL_START_ROUND = 1243;

    private static final String MUSIC_PREFS = "v3_music_preferences";
    private static final String MUSIC_NAME = "music_name";
    private static final String MUSIC_ENABLED = "music_enabled";
    private static final String MUSIC_VOLUME = "music_volume";
    private static final String MUSIC_FILE = "v3_user_background_audio";
    private static final String MUSIC_DIR = "v3_music_playlist";
    private static final String MUSIC_TREE_URI = "music_tree_uri";
    private String pendingMusicLibraryMode = "multi";

    // V2 성적 화면의 축하음악 + 한국어 음성안내 계승
    private TextToSpeech scoreTts;
    private boolean scoreTtsReady = false;
    private String pendingScoreSpeech = null;
    private int pendingScoreRank = 0;
    private MediaPlayer scoreFanfarePlayer;
    private MediaPlayer launchSeaPlayer;
    private TextToSpeech launchTts;
    private FrameLayout rootLayout;
    private TextureView launchVideo;
    private MediaPlayer launchVideoPlayer;
    private MediaPlayer radioPlayer;
    private boolean radioPlaying = false;
    private String radioName = "";
    private String radioUrl = "";
    private Surface launchVideoSurface;
    private boolean launchVideoPrepared = false;
    private boolean launchVideoActive = false;
    private boolean launchTtsReady = false;
    private boolean launchSpeechRequested = false;
    private boolean launchIntroFinished = false;
    private boolean overlayUpdateScreenActive = false;
    private static final String LAUNCH_WELCOME_TEXT = "우리 항행의자유앱에 승선한 지인들께 알려드립니다. 희망의 배에 승선하신 것을 진심으로 환영합니다. 부디 즐거운 항해가 되시기를 기원합니다.";
    private final Handler scoreHandler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prepareBuildMigration();
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        startAlwaysOverlayExperiment();

        rootLayout = new FrameLayout(this);
        setContentView(rootLayout);

        webView = new WebView(this);
        webView.setVisibility(View.VISIBLE);
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        AndroidHostBridge nativeBridge = new AndroidHostBridge();
        webView.addJavascriptInterface(nativeBridge, "AndroidHost");
        webView.addJavascriptInterface(nativeBridge, "BaekhakNative");
        webView.setWebViewClient(new WebViewClient());
        configureAppWebView(webView);

        initScoreTts();
        // FIX9: saved playback intent is restored in onResume; never force music OFF.
        loadInstalledApp();
        handleSavedMusicIntent(getIntent());
        handleOverlayUpdateIntent(getIntent());
        if (getIntent() != null && getIntent().getBooleanExtra("v3_play_install_guide", false)) {
            getIntent().removeExtra("v3_play_install_guide");
            webView.postDelayed(() -> webView.evaluateJavascript("if(window.playInstallGuide){window.playInstallGuide();}", null), 1200);
        }
        requestMusicNotificationPermission();
        handleOverlayAudioPermissionRequest(getIntent());
        requestAutoAudioPermissionOnce();
        // V1059: 자동 전체 음악검색 금지. 사용자가 불러오기에서 직접 선택한 곡만 내부보관합니다.
        reportStoredNameUpdateCheckinAsync();
    }

    /** Flavor-specific connections; the distribution implementation contains no admin code. */
    protected void configureAppWebView(WebView view) { }

    // STAGE4.47: 기본 인트로는 MP4 원본에서 만든 animated WebP를 WebView에서 재생합니다.
    // 아래 네이티브 영상 루틴은 호출하지 않는 비상용 코드로만 남겨 둡니다.
    private void startNativeVoyageIntro() {
        launchIntroFinished = false;
        launchVideoActive = true;
        launchVideoPrepared = false;
        try {
            if (webView != null) webView.setVisibility(View.INVISIBLE);
            if (rootLayout != null) rootLayout.setBackgroundColor(Color.BLACK);
            releaseNativeVoyageMedia();
            if (launchVideo != null && rootLayout != null) {
                try { rootLayout.removeView(launchVideo); } catch (Exception ignored) {}
            }

            launchVideo = new TextureView(this);
            launchVideo.setOpaque(true);
            launchVideo.setBackgroundColor(Color.BLACK);
            FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT);
            vp.gravity = Gravity.CENTER;
            rootLayout.addView(launchVideo, vp);

            launchVideo.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
                @Override public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
                    prepareNativeVoyagePlayer(surfaceTexture);
                }
                @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int width, int height) {}
                @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                    try { if (launchVideoSurface != null) launchVideoSurface.release(); } catch (Exception ignored) {}
                    launchVideoSurface = null;
                    return true;
                }
                @Override public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {}
            });

            if (launchVideo.isAvailable() && launchVideo.getSurfaceTexture() != null) {
                prepareNativeVoyagePlayer(launchVideo.getSurfaceTexture());
            }

            scoreHandler.postDelayed(() -> {
                if (!launchVideoActive || launchVideoPrepared) return;
                try {
                    if (launchVideo != null && launchVideo.isAvailable() && launchVideo.getSurfaceTexture() != null) {
                        prepareNativeVoyagePlayer(launchVideo.getSurfaceTexture());
                    }
                } catch (Exception ignored) {}
            }, 1800);
            // 영상 완료 콜백이 누락되는 기기에서도 홈으로 반드시 복귀.
            scoreHandler.postDelayed(() -> {
                if (launchVideoActive) finishNativeVoyageVideo();
            }, 23000);
        } catch (Exception e) {
            finishNativeVoyageVideo();
        }
    }

    private void prepareNativeVoyagePlayer(SurfaceTexture surfaceTexture) {
        // STAGE4.53: 시작 동영상 삭제. 네이티브 영상 재생 비활성.
        finishNativeVoyageVideo();
    }

    private void releaseNativeVoyageMedia() {
        try {
            if (launchVideoPlayer != null) {
                try { if (launchVideoPlayer.isPlaying()) launchVideoPlayer.stop(); } catch (Exception ignored) {}
                try { launchVideoPlayer.reset(); } catch (Exception ignored) {}
                try { launchVideoPlayer.release(); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        launchVideoPlayer = null;
        try { if (launchVideoSurface != null) launchVideoSurface.release(); } catch (Exception ignored) {}
        launchVideoSurface = null;
    }

    private void finishNativeVoyageVideo() {
        if (!launchVideoActive) return;
        launchVideoActive = false;
        launchIntroFinished = true;
        launchVideoPrepared = false;
        releaseNativeVoyageMedia();
        try { if (launchTts != null) launchTts.stop(); } catch (Exception ignored) {}
        try { if (launchVideo != null && rootLayout != null) rootLayout.removeView(launchVideo); } catch (Exception ignored) {}
        launchVideo = null;
        if (webView != null) webView.setVisibility(View.VISIBLE);
    }


    private boolean isOverlayControlEnabled() {
        try { return getSharedPreferences("overlay_control", MODE_PRIVATE).getBoolean("enabled", true); }
        catch (Exception e) { return true; }
    }

    private void setOverlayControlEnabled(boolean enabled) {
        try { getSharedPreferences("overlay_control", MODE_PRIVATE).edit().putBoolean("enabled", enabled).apply(); }
        catch (Exception ignored) {}
        try {
            Intent service = new Intent(this, OverlayControlService.class)
                    .setAction(enabled ? OverlayControlService.ACTION_SHOW : OverlayControlService.ACTION_HIDE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
        } catch (Exception ignored) {}
        if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            try {
                Intent permission = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(permission);
            } catch (Exception ignored) {}
        }
    }

    // V3.1.04 항해사 전용 실험: 상시 음악/FM/AM 오버레이. 기존 onResume은 건드리지 않습니다.
    private void startAlwaysOverlayExperiment() {
        if (!isOverlayControlEnabled()) return;
        try {
            Intent service = new Intent(this, OverlayControlService.class).setAction(OverlayControlService.ACTION_SHOW);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
        } catch (Exception ignored) {}
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            try {
                Intent permission = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(permission);
                Toast.makeText(this, "상단 음악·FM·AM 미니바를 위해 '다른 앱 위에 표시'를 허용해 주세요.", Toast.LENGTH_LONG).show();
            } catch (Exception ignored) {}
        }
    }

    private void closeAppScreen() {
        stopBackgroundMusicForAppExit();
        try {
            launchVideoActive = false;
            launchIntroFinished = true;
            launchVideoPrepared = false;
            releaseNativeVoyageMedia();
            if (launchVideo != null && rootLayout != null) {
                try { rootLayout.removeView(launchVideo); } catch (Exception ignored) {}
            }
            launchVideo = null;
            try { if (launchTts != null) launchTts.stop(); } catch (Exception ignored) {}
            try { if (webView != null) { webView.setVisibility(View.INVISIBLE); webView.stopLoading(); webView.loadUrl("about:blank"); } } catch (Exception ignored) {}
        } catch (Exception ignored) {}
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) finishAndRemoveTask();
            else finish();
        } catch (Exception e) {
            try { finish(); } catch (Exception ignored) {}
        }
    }

    // STAGE4.40: 앱 실행 시 우리 배가 다가오는 동안 바다소리를 재생합니다.
    private void startLaunchSeaSound() {
        try {
            if (launchSeaPlayer != null) { launchSeaPlayer.release(); launchSeaPlayer = null; }
            launchSeaPlayer = MediaPlayer.create(this, R.raw.sea_intro);
            if (launchSeaPlayer != null) {
                launchSeaPlayer.setLooping(true);
                launchSeaPlayer.setVolume(0.42f, 0.42f);
                launchSeaPlayer.start();
            }
        } catch (Exception ignored) {}
    }

    private void finishLaunchIntroNative() {
        if (launchIntroFinished) return;
        launchIntroFinished = true;
        try {
            if (launchSeaPlayer != null) {
                if (launchSeaPlayer.isPlaying()) launchSeaPlayer.stop();
                launchSeaPlayer.release();
                launchSeaPlayer = null;
            }
        } catch (Exception ignored) { launchSeaPlayer = null; }
        try { if (launchTts != null) launchTts.stop(); } catch (Exception ignored) {}
    }

    // STAGE4.42: 20초 항해 인트로 동안 한국어 승무원 환영 멘트를 안내합니다.
    private void initLaunchTts() {
        try {
            launchTts = new TextToSpeech(getApplicationContext(), status -> {
                if (status != TextToSpeech.SUCCESS || launchTts == null) return;
                try {
                    int lang = launchTts.setLanguage(Locale.KOREA);
                    launchTtsReady = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED;
                    launchTts.setSpeechRate(0.86f);
                    launchTts.setPitch(1.18f);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        launchTts.setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build());
                        // 기기에 여성으로 표시된 한국어 음성이 있으면 우선 사용합니다.
                        try {
                            android.speech.tts.Voice fallback = null;
                            for (android.speech.tts.Voice v : launchTts.getVoices()) {
                                if (v == null || v.getLocale() == null) continue;
                                String language = v.getLocale().getLanguage();
                                if (!"ko".equalsIgnoreCase(language)) continue;
                                if (fallback == null) fallback = v;
                                String name = String.valueOf(v.getName()).toLowerCase(java.util.Locale.ROOT);
                                String features = String.valueOf(v.getFeatures()).toLowerCase(java.util.Locale.ROOT);
                                if (name.contains("female") || name.contains("woman") || features.contains("female")) {
                                    launchTts.setVoice(v);
                                    fallback = null;
                                    break;
                                }
                            }
                            if (fallback != null) launchTts.setVoice(fallback);
                        } catch (Exception ignored) {}
                    }
                    if (launchTtsReady && launchSpeechRequested && !launchIntroFinished) {
                        speakLaunchWelcomeNow();
                    }
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {
            launchTts = null;
            launchTtsReady = false;
        }
    }

    private void speakLaunchWelcome() {
        if (launchIntroFinished) return;
        launchSpeechRequested = true;
        if (launchTtsReady) speakLaunchWelcomeNow();
    }

    private void speakLaunchWelcomeNow() {
        if (launchIntroFinished || launchTts == null) return;
        launchSpeechRequested = false;
        try {
            if (launchSeaPlayer != null) launchSeaPlayer.setVolume(0.26f, 0.26f);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                android.os.Bundle ttsParams = new android.os.Bundle();
                ttsParams.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
                launchTts.speak(LAUNCH_WELCOME_TEXT, TextToSpeech.QUEUE_FLUSH, ttsParams, "V3_LAUNCH_WELCOME");
            } else {
                launchTts.speak(LAUNCH_WELCOME_TEXT, TextToSpeech.QUEUE_FLUSH, null);
            }
        } catch (Exception ignored) {}
    }

    // FIX9 preserves the previous song, position and explicit pause/stop choice.


    private String getOrCreateAnonymousInstallId() {
        SharedPreferences sp = getSharedPreferences(UPDATE_TRACK_PREFS, MODE_PRIVATE);
        String id = sp.getString("anonymous_install_id", "");
        if (id == null || id.trim().isEmpty()) {
            id = UUID.randomUUID().toString();
            sp.edit().putString("anonymous_install_id", id).apply();
        }
        return id;
    }

    private String currentVersionName() {
        try {
            android.content.pm.PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0);
            return p.versionName == null ? "V3" : p.versionName;
        } catch (Exception e) { return "V3"; }
    }

    private String postUpdateApi(JSONObject payload) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(UPDATE_STATS_URL).openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(7000);
        c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        c.setRequestProperty("x-app-key", UPDATE_STATS_APP_KEY);
        try (OutputStream out = c.getOutputStream()) {
            out.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String body = in == null ? "" : new String(readAll(in), StandardCharsets.UTF_8);
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
        return body;
    }

    // 같은 버전은 설치기기당 한 번만 서버에 보고합니다.
    private void reportUpdateCheckinAsync() {
        final long versionCode = getInstalledVersionCode();
        final SharedPreferences sp = getSharedPreferences(UPDATE_TRACK_PREFS, MODE_PRIVATE);
        if (sp.getLong("reported_version_code", -1L) == versionCode) return;
        new Thread(() -> {
            try {
                JSONObject p = new JSONObject();
                p.put("action", "checkin");
                p.put("install_id", getOrCreateAnonymousInstallId());
                p.put("version_name", currentVersionName());
                p.put("version_code", versionCode);
                String body = postUpdateApi(p);
                JSONObject r = new JSONObject(body);
                if (r.optBoolean("ok", false)) sp.edit().putLong("reported_version_code", versionCode).apply();
            } catch (Exception ignored) {}
        }, "V3-UpdateCheckin").start();
    }

    private void requestUpdateStatsAsync() {
        new Thread(() -> {
            String body;
            try {
                JSONObject p = new JSONObject(); p.put("action", "stats");
                body = postUpdateApi(p);
            } catch (Exception e) {
                try { JSONObject x = new JSONObject(); x.put("ok", false); x.put("error", "network"); body = x.toString(); }
                catch (Exception ignored) { body = "{\"ok\":false}"; }
            }
            final String result = body;
            if (webView != null) webView.post(() -> webView.evaluateJavascript("onUpdateStats(" + JSONObject.quote(result) + ");", null));
        }, "V3-UpdateStats").start();
    }
    private String postUpdateAdminApi(JSONObject payload) throws Exception {
        throw new Exception("admin_stats_disabled_in_distribution");
    }

    private String cleanUpdateDisplayName(String raw) {
        String n = raw == null ? "" : raw.trim().replaceAll("\\s+", " ");
        if (n.isEmpty() || n.length() > 40) return "";
        if (n.matches(".*\\d.*") || n.contains("@")) return "";
        return n;
    }

    private String getStoredUpdateDisplayName() {
        return getSharedPreferences(UPDATE_TRACK_PREFS, MODE_PRIVATE).getString("update_display_name", "");
    }

    private void reportStoredNameUpdateCheckinAsync() {
        final String name = cleanUpdateDisplayName(getStoredUpdateDisplayName());
        if (name.isEmpty()) return;
        reportNamedUpdateCheckinAsync(name);
    }

    private void reportNamedUpdateCheckinAsync(final String rawName) {
        final String name = cleanUpdateDisplayName(rawName);
        if (name.isEmpty()) return;
        final long versionCode = getInstalledVersionCode();
        final SharedPreferences sp = getSharedPreferences(UPDATE_TRACK_PREFS, MODE_PRIVATE);
        String lastName = sp.getString("reported_named_name", "");
        long lastCode = sp.getLong("reported_named_version_code", -1L);
        if (lastCode == versionCode && name.equals(lastName)) return;
        new Thread(() -> {
            try {
                JSONObject p = new JSONObject();
                p.put("action", "named_checkin");
                p.put("display_name", name);
                p.put("version_name", currentVersionName());
                p.put("version_code", versionCode);
                JSONObject r = new JSONObject(postUpdateApi(p));
                if (r.optBoolean("ok", false)) {
                    sp.edit()
                      .putString("update_display_name", name)
                      .putString("reported_named_name", name)
                      .putLong("reported_named_version_code", versionCode)
                      .apply();
                }
            } catch (Exception ignored) {}
        }, "V3-NamedUpdateCheckin").start();
    }

    private void setUpdateDisplayNameAndReportAsync(final String rawName) {
        final String name = cleanUpdateDisplayName(rawName);
        if (name.isEmpty()) {
            if (webView != null) webView.post(() -> webView.evaluateJavascript(
                "if(window.onUpdateNameSaved){onUpdateNameSaved(false,'이름만 입력해 주세요. 숫자·전화번호·이메일은 저장하지 않습니다.');}", null));
            return;
        }
        getSharedPreferences(UPDATE_TRACK_PREFS, MODE_PRIVATE).edit().putString("update_display_name", name).apply();
        reportNamedUpdateCheckinAsync(name);
        if (webView != null) webView.postDelayed(() -> webView.evaluateJavascript(
            "if(window.onUpdateNameSaved){onUpdateNameSaved(true," + JSONObject.quote(name) + ");}", null), 250);
    }

    private void requestNamedUpdateStatsAsync() {
        final String result = "{\"ok\":false,\"error\":\"admin_view_disabled_in_distribution\"}";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(
            "if(window.onNamedUpdateStats){onNamedUpdateStats(" + JSONObject.quote(result) + ");}", null));
    }

    private SharedPreferences specialApprovalPrefs() {
        return getSharedPreferences(SPECIAL_APPROVAL_PREFS, MODE_PRIVATE);
    }

    private String getOrCreateApprovalDeviceId() {
        SharedPreferences sp = specialApprovalPrefs();
        String id = sp.getString("device_id", "");
        if (id == null || !id.matches("\\d{6,20}")) {
            long base = System.currentTimeMillis();
            String tail = String.valueOf(Math.abs(UUID.randomUUID().hashCode()));
            if (tail.length() > 5) tail = tail.substring(tail.length() - 5);
            id = String.valueOf(base) + tail;
            if (id.length() > 20) id = id.substring(id.length() - 20);
            sp.edit().putString("device_id", id).apply();
        }
        return id;
    }

    private String postJson(String url, JSONObject payload) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(7000);
        c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        try (OutputStream out = c.getOutputStream()) {
            out.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String body = in == null ? "" : new String(readAll(in), StandardCharsets.UTF_8);
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + " " + body);
        return body;
    }

    private boolean isSpecialApprovedLocal() {
        return specialApprovalPrefs().getBoolean("approved", false);
    }

    private String specialApprovalSummaryJson() {
        try {
            SharedPreferences sp = specialApprovalPrefs();
            JSONObject j = new JSONObject();
            boolean approved = sp.getBoolean("approved", false);
            boolean hasRequest = !sp.getString("request_token", "").isEmpty();
            j.put("approved", approved);
            j.put("requested_round", sp.getInt("requested_round", SPECIAL_APPROVAL_START_ROUND));
            j.put("approval_code", sp.getString("approval_code", ""));
            j.put("has_request", hasRequest);
            j.put("applicant_name", sp.getString("applicant_name", ""));
            j.put("referrer_name", sp.getString("referrer_name", ""));
            j.put("status", approved ? "approved" : (hasRequest ? "pending" : "not_requested"));
            return j.toString();
        } catch (Exception e) { return "{\"approved\":false}"; }
    }

    private void sendSpecialApprovalState(String json) {
        final String payload = json == null ? "{}" : json;
        if (webView != null) webView.post(() -> webView.evaluateJavascript(
            "if(window.onSpecialApprovalState){onSpecialApprovalState(" + JSONObject.quote(payload) + ");}", null));
    }

    private void requestSpecialApprovalAsync(final int requestedRound, final String applicantRaw, final String referrerRaw) {
        if (requestedRound < SPECIAL_APPROVAL_START_ROUND) {
            sendSpecialApprovalState("{\"ok\":true,\"status\":\"approved\",\"round_policy_free\":true}");
            return;
        }
        final String applicant = applicantRaw == null ? "" : applicantRaw.trim();
        final String referrer = referrerRaw == null ? "" : referrerRaw.trim();
        if (applicant.isEmpty() || referrer.isEmpty()) { sendSpecialApprovalState("{\"ok\":false,\"error\":\"identity_required\"}"); return; }
        specialApprovalPrefs().edit().putString("applicant_name", applicant).putString("referrer_name", referrer).apply();
        new Thread(() -> {
            try {
                JSONObject p = new JSONObject();
                p.put("device_id", getOrCreateApprovalDeviceId());
                p.put("device_label", applicant + "||" + referrer);
                p.put("referrer_name", referrer);
                p.put("purpose_ack", true);
                p.put("requested_round", requestedRound);
                String body = postJson(APPROVAL_REQUEST_URL, p);
                JSONObject r = new JSONObject(body);
                SharedPreferences.Editor ed = specialApprovalPrefs().edit();
                if (r.has("request_token")) ed.putString("request_token", r.optString("request_token", ""));
                if (r.has("approval_code")) ed.putString("approval_code", r.optString("approval_code", ""));
                ed.putInt("requested_round", requestedRound);
                if ("approved".equalsIgnoreCase(r.optString("status", ""))) ed.putBoolean("approved", true);
                ed.apply();
                JSONObject merged = new JSONObject(body);
                String cachedCode = specialApprovalPrefs().getString("approval_code", "");
                if (!cachedCode.isEmpty() && !merged.has("approval_code")) merged.put("approval_code", cachedCode);
                if (!merged.has("has_request")) merged.put("has_request", !specialApprovalPrefs().getString("request_token", "").isEmpty());
                sendSpecialApprovalState(merged.toString());
            } catch (Exception e) {
                sendSpecialApprovalState("{\"ok\":false,\"error\":\"network\"}");
            }
        }, "V3-SpecialApprovalRequest").start();
    }

    private void checkSpecialApprovalAsync() {
        if (isSpecialApprovedLocal()) {
            try {
                JSONObject merged = new JSONObject(specialApprovalSummaryJson());
                merged.put("ok", true);
                merged.put("status", "approved");
                merged.put("special_approval", true);
                sendSpecialApprovalState(merged.toString());
            } catch (Exception e) {
                sendSpecialApprovalState(specialApprovalSummaryJson());
            }
            return;
        }
        final SharedPreferences sp = specialApprovalPrefs();
        final String token = sp.getString("request_token", "");
        if (token == null || token.isEmpty()) {
            sendSpecialApprovalState("{\"ok\":true,\"status\":\"not_requested\"}");
            return;
        }
        new Thread(() -> {
            try {
                JSONObject p = new JSONObject();
                p.put("request_token", token);
                p.put("device_id", getOrCreateApprovalDeviceId());
                String body = postJson(APPROVAL_STATUS_URL, p);
                JSONObject r = new JSONObject(body);
                if ("approved".equalsIgnoreCase(r.optString("status", ""))) {
                    sp.edit().putBoolean("approved", true).apply();
                }
                JSONObject merged = new JSONObject(body);
                String cachedCode = sp.getString("approval_code", "");
                if (!cachedCode.isEmpty() && !merged.has("approval_code")) merged.put("approval_code", cachedCode);
                if (!merged.has("has_request")) merged.put("has_request", !sp.getString("request_token", "").isEmpty());
                sendSpecialApprovalState(merged.toString());
            } catch (Exception e) {
                sendSpecialApprovalState("{\"ok\":false,\"error\":\"network\"}");
            }
        }, "V3-SpecialApprovalStatus").start();
    }

    // 새 빌드를 처음 설치/업데이트했을 때 이전 HTML 업데이트 잔재가
    // 새 내장 화면을 덮어쓰지 않도록 딱 한 번 정리합니다.
    private long getInstalledVersionCode() {
        try {
            android.content.pm.PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
        } catch (Exception e) {
            return CONTENT_BUILD;
        }
    }

    private void prepareBuildMigration() {
        // STAGE4.35부터는 APK에 내장된 화면만 공식 실행본으로 사용합니다.
        // 과거 HTML 내부 업데이트 파일은 보관하고 읽지 않아 구버전 화면이
        // 새 Java/브리지 기능을 덮어쓰는 현상을 원천 차단합니다.
        try {
            File f = new File(getFilesDir(), UPDATE_FILE);
            if (f.exists()) {
                File backup = new File(getFilesDir(), UPDATE_FILE + ".before_integrated");
                if (!backup.exists()) f.renameTo(backup);
            }
        } catch (Exception ignored) {}
        SharedPreferences sp = getSharedPreferences("v3_native_state", MODE_PRIVATE);
        sp.edit()
          .putLong("native_version_code", getInstalledVersionCode())
          .putInt("content_build", CONTENT_BUILD)
          .apply();
    }

    private void loadInstalledApp() {
        // 공식 화면은 항상 현재 APK의 assets/index.html에서 로드합니다.
        webView.loadUrl(BASE_URL + "index.html");
    }

    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private String readUri(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("open failed");
            return new String(readAll(in), StandardCharsets.UTF_8);
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    String n = c.getString(i);
                    if (n != null && !n.trim().isEmpty()) return n;
                }
            }
        } catch (Exception ignored) {}
        return "파일";
    }

    private boolean installUpdate(String html) {
        if (html == null || html.length() < 300 || !html.contains("SHIPMATE_V3_UPDATE")) return false;
        File tmp = new File(getFilesDir(), UPDATE_FILE + ".tmp");
        File dst = new File(getFilesDir(), UPDATE_FILE);
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(html.getBytes(StandardCharsets.UTF_8));
            out.flush();
        } catch (Exception e) { return false; }
        if (dst.exists() && !dst.delete()) { tmp.delete(); return false; }
        if (!tmp.renameTo(dst)) { tmp.delete(); return false; }
        runOnUiThread(() -> webView.loadDataWithBaseURL(BASE_URL, html, "text/html", "UTF-8", null));
        return true;
    }

    private void alert(String message) {
        final String q = JSONObject.quote(message == null ? "" : message);
        webView.post(() -> webView.evaluateJavascript("alert(" + q + ");", null));
    }

    private void createSave(String name, String mime, String data) {
        pendingName = name;
        pendingMime = mime;
        pendingData = data;
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_TITLE, name);
            try { startActivityForResult(i, SAVE_PICKER); }
            catch (Exception e) { pendingData = null; alert("저장창을 열 수 없습니다."); }
        });
    }

    // STAGE4.36: 전체 백업은 파일 선택창을 띄우지 않고
    // 내 파일 > 다운로드 > 항행의자유 폴더에 자동 저장합니다.
    private void saveBackupDirect(String data) {
        if (data == null || data.isEmpty()) return;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            createSave("항행의자유_V3_전체백업.json", "application/json", data);
            return;
        }
        new Thread(() -> {
            Uri uri = null;
            try {
                String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(new Date());
                String fileName = "항행의자유_V3_전체백업_" + stamp + ".json";
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/항행의자유");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("MediaStore insert failed");
                try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new Exception("openOutputStream failed");
                    out.write(data.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                alert("전체 백업 완료\n내 파일 > 다운로드 > 항행의자유\n" + fileName);
            } catch (Exception e) {
                try { if (uri != null) getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                alert("자동 백업 저장 실패. 저장 위치 선택창으로 전환합니다.");
                runOnUiThread(() -> createSave("항행의자유_V3_전체백업.json", "application/json", data));
            }
        }, "V3-Backup").start();
    }


    // STAGE4.37: 자동 백업을 동기식으로 처리하고 JS에 결과를 되돌려줍니다.
    // 성공 여부를 화면 모달과 Toast에서 모두 확인할 수 있게 합니다.
    private String saveBackupDirectSync(String data) {
        if (data == null || data.isEmpty()) return "ERR|백업 데이터가 비어 있습니다.";
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "ERR|Android 10 미만에서는 자동 저장을 사용할 수 없습니다.";
        Uri uri = null;
        try {
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(new Date());
            String fileName = "항행의자유_V3_전체백업_" + stamp + ".json";
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/항행의자유");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("MediaStore insert failed");
            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new Exception("openOutputStream failed");
                out.write(data.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            final String toastName = fileName;
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "전체 백업 완료: " + toastName, Toast.LENGTH_LONG).show());
            return "OK|" + fileName;
        } catch (Exception e) {
            try { if (uri != null) getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
            final String msg = e.getMessage() == null ? "자동 저장 실패" : e.getMessage();
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "전체 백업 실패: " + msg, Toast.LENGTH_LONG).show());
            return "ERR|" + msg;
        }
    }

    private void sendLegacyBackupToJs(final String name, final String text) {
        if (text == null) return;
        webView.post(() -> {
            webView.evaluateJavascript("legacyImportStart(" + JSONObject.quote(name == null ? "backup.json" : name) + ");", null);
            final int chunkSize = 12000;
            for (int i = 0; i < text.length(); i += chunkSize) {
                String chunk = text.substring(i, Math.min(text.length(), i + chunkSize));
                webView.evaluateJavascript("legacyImportChunk(" + JSONObject.quote(chunk) + ");", null);
            }
            webView.evaluateJavascript("legacyImportFinish();", null);
        });
    }

    // ---------------- Background music ----------------
    private SharedPreferences musicPrefs() {
        return getSharedPreferences(MUSIC_PREFS, MODE_PRIVATE);
    }

    private boolean musicEnabled() {
        return musicPrefs().getBoolean(MUSIC_ENABLED, false);
    }

    private int musicVolume() {
        int v = musicPrefs().getInt(MUSIC_VOLUME, 42);
        return Math.max(0, Math.min(100, v));
    }

    private String musicName() {
        try { String n=new JSONObject(MusicPlaybackService.snapshot(this)).optString("name", "");
            if(!n.isEmpty())return n; } catch(Exception ignored){}
        return musicPrefs().getString(MUSIC_NAME, "");
    }

    private void sendMusicCommand(String action) {
        try {
            Intent i = new Intent(this, MusicPlaybackService.class);
            i.setAction(action);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);
        } catch (Exception ignored) {}
    }

    private void requestMusicNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 4310);
                }
            } catch (Exception ignored) {}
        }
    }

    private void stopBackgroundMusic() {
        musicPrefs().edit().putBoolean(MUSIC_ENABLED, false).apply();
        sendMusicCommand(MusicPlaybackService.ACTION_STOP);
    }

    private void stopBackgroundMusicForAppExit() {
        // 앱 종료 시에는 선택한 곡/재생목록을 삭제하거나 OFF로 바꾸지 않습니다.
        sendMusicCommand(MusicPlaybackService.ACTION_APP_EXIT);
    }

    private void startBackgroundMusic() {
        if (!musicEnabled()) return;
        sendMusicCommand(MusicPlaybackService.ACTION_PLAY);
    }

    private void pauseBackgroundMusic() {
        sendMusicCommand(MusicPlaybackService.ACTION_PAUSE);
    }

    private void applyMusicVolume(int percent) {
        int p = Math.max(0, Math.min(100, percent));
        musicPrefs().edit().putInt(MUSIC_VOLUME, p).apply();
        try {
            Intent i = new Intent(this, MusicPlaybackService.class);
            i.setAction(MusicPlaybackService.ACTION_VOLUME);
            i.putExtra(MusicPlaybackService.EXTRA_VOLUME, p);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);
        } catch (Exception ignored) {}
    }

    private boolean toggleBackgroundMusic() {
        boolean enabled = !musicEnabled();
        musicPrefs().edit().putBoolean(MUSIC_ENABLED, enabled).apply();
        if (enabled) startBackgroundMusic(); else pauseBackgroundMusic();
        return enabled;
    }

    private boolean isBlockedPickerPackage(String pkg) {
        if (pkg == null) return false;
        String p = pkg.toLowerCase(java.util.Locale.US);
        return p.contains("androidide") || p.contains("m4coding") || p.contains("aide") || p.contains("codeassist");
    }

    private boolean tryExplicitDocumentsUi(Intent base, int requestCode) {
        // ACTION_OPEN_DOCUMENT / ACTION_OPEN_DOCUMENT_TREE 의 실제 시스템 구현은
        // DocumentsUI의 PickActivity 입니다. 이 Activity를 명시적으로 호출하면
        // AndroidIDE/A-IDE가 파일선택 Intent를 가로채지 못합니다.
        String[] packages = new String[]{"com.google.android.documentsui", "com.android.documentsui"};
        for (String pkg : packages) {
            try {
                Intent x = new Intent(base);
                x.setComponent(new ComponentName(pkg, "com.android.documentsui.picker.PickActivity"));
                startActivityForResult(x, requestCode);
                return true;
            } catch (Exception ignored) {}
        }
        return false;
    }

    private boolean tryResolvedSafePicker(Intent base, int requestCode) {
        try {
            List<ResolveInfo> list = getPackageManager().queryIntentActivities(base, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
            if (list != null) {
                // Samsung 내 파일 / 시스템 DocumentsUI 우선, 코딩 IDE는 제외합니다.
                String[] preferred = new String[]{
                        "com.sec.android.app.myfiles",
                        "com.google.android.documentsui",
                        "com.android.documentsui"
                };
                for (String want : preferred) {
                    for (ResolveInfo ri : list) {
                        if (ri == null || ri.activityInfo == null) continue;
                        String pkg = ri.activityInfo.packageName;
                        if (!want.equals(pkg) || isBlockedPickerPackage(pkg)) continue;
                        Intent x = new Intent(base);
                        x.setComponent(new ComponentName(pkg, ri.activityInfo.name));
                        startActivityForResult(x, requestCode);
                        return true;
                    }
                }
                for (ResolveInfo ri : list) {
                    if (ri == null || ri.activityInfo == null) continue;
                    String pkg = ri.activityInfo.packageName;
                    if (isBlockedPickerPackage(pkg)) continue;
                    Intent x = new Intent(base);
                    x.setComponent(new ComponentName(pkg, ri.activityInfo.name));
                    startActivityForResult(x, requestCode);
                    return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private boolean startPreferredFilesPicker(Intent base, int requestCode) {
        // 1) 시스템 DocumentsUI를 명시적으로 호출
        if (tryExplicitDocumentsUi(base, requestCode)) return true;
        // 2) 현재 기기에 등록된 안전한 파일선택기 중 A-IDE를 제외하고 선택
        if (tryResolvedSafePicker(base, requestCode)) return true;
        // 3) 마지막 수단: 패키지 미지정 표준 Intent
        try {
            startActivityForResult(new Intent(base), requestCode);
            return true;
        } catch (Exception ignored) {}

        Toast.makeText(this, "시스템 파일 선택 화면을 열지 못했습니다.", Toast.LENGTH_LONG).show();
        return false;
    }


    private void openSavedMusicLibraryChooser() {
        runOnUiThread(() -> {
            try {
                final java.util.List<MusicLibraryFiles.Track> list = new MusicLibraryStore(this).read();
                if (list == null || list.isEmpty()) {
                    chooseMultipleMusicFiles();
                    return;
                }

                String currentId = "";
                try {
                    JSONObject state = new JSONObject(MusicPlaybackService.snapshot(this));
                    currentId = state.optString("id", "");
                } catch (Exception ignored) {}

                CharSequence[] rows = new CharSequence[list.size()];
                int checked = -1;
                for (int i = 0; i < list.size(); i++) {
                    MusicLibraryFiles.Track t = list.get(i);
                    rows[i] = t.name;
                    if (t.id.equals(currentId)) checked = i;
                }

                final int initialChecked = checked;
                android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("저장된 MP3 · " + list.size() + "곡")
                        .setSingleChoiceItems(rows, initialChecked, null)
                        .setNegativeButton("닫기", null)
                        .setNeutralButton("음악폴더 다시 불러오기", null)
                        .setPositiveButton("선택곡 재생", null)
                        .create();

                dialog.setOnShowListener(x -> {
                    dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setText("MP3 추가 불러오기");
                    dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                        dialog.dismiss();
                        chooseMultipleMusicFiles();
                    });
                    dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                        int which = dialog.getListView().getCheckedItemPosition();
                        if (which < 0 || which >= list.size()) {
                            Toast.makeText(MainActivity.this, "재생할 곡을 선택해 주세요.", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        MusicLibraryFiles.Track t = list.get(which);
                        try {
                            musicPrefs().edit()
                                    .putBoolean("music_use_default", false)
                                    .putBoolean(MUSIC_ENABLED, true)
                                    .apply();
                            Intent play = new Intent(MainActivity.this, MusicPlaybackService.class)
                                    .setAction(MusicPlaybackService.ACTION_SELECT)
                                    .putExtra(MusicPlaybackService.EXTRA_TRACK, t.id);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(play);
                            else startService(play);
                            Toast.makeText(MainActivity.this, "재생: " + t.name, Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "선택한 음악을 재생하지 못했습니다.", Toast.LENGTH_LONG).show();
                        }
                    });
                });
                dialog.show();
            } catch (Exception e) {
                Toast.makeText(this, "저장된 음악목록을 열지 못했습니다.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void handleSavedMusicIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra("v3_force_local_music_folder", false)) {
            intent.removeExtra("v3_force_local_music_folder");
            openSavedMusicLibraryChooser();
            return;
        }
        if (intent == null || !intent.getBooleanExtra(EXTRA_OPEN_SAVED_MUSIC, false)) return;
        intent.removeExtra(EXTRA_OPEN_SAVED_MUSIC);
        openSavedMusicLibraryChooser();
    }

    private void handleOverlayUpdateIntent(Intent intent) {
        if (intent == null || !intent.getBooleanExtra(EXTRA_OPEN_UPDATE, false)) return;
        intent.removeExtra(EXTRA_OPEN_UPDATE);
        overlayUpdateScreenActive = true;
        suspendOverlayForUpdate();
        if (webView != null) {
            webView.postDelayed(() -> webView.evaluateJavascript(
                    "if(window.updatePage){window.updatePage();setTimeout(function(){var m=document.getElementById('modal');if(m){m.classList.add('updateFullScreen');m.style.position='fixed';m.style.left='0';m.style.top='0';m.style.right='0';m.style.bottom='0';m.style.width='100vw';m.style.height='100dvh';m.style.margin='0';m.style.zIndex='2147483000';m.style.display='block';}},30);}else if(window.openM){window.openM('update');}", null), 450);
        }
    }

    private void suspendOverlayForUpdate() {
        try {
            Intent s = new Intent(this, OverlayControlService.class).setAction(OverlayControlService.ACTION_SUSPEND);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        } catch (Exception ignored) {}
    }

    private void chooseMusicFile() {
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("audio/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try { i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                        Uri.parse("content://com.android.externalstorage.documents/document/primary%3AMusic")); }
                catch (Exception ignored) {}
            }
            startPreferredFilesPicker(i, MUSIC_PICKER);
        });
    }

    private void chooseMusicFolder() {
        // V1059: 자동 폴더/MediaStore 전체검색 금지. 필요한 MP3만 사용자가 직접 선택합니다.
        chooseMultipleMusicFiles();
    }

    private void autoLoadPhoneMusic(boolean openChooserAfter) {
        // V1059 compatibility shim: 과거 호출이 남아 있어도 전체 음악을 자동검색/복사하지 않습니다.
        // 항상 사용자가 직접 필요한 MP3를 고르는 파일 선택 화면으로 보냅니다.
        chooseMultipleMusicFiles();
    }
    private void refreshOurMusicFolder() {
        // V1059: 폴더 전체 가져오기 대신 직접 파일 선택만 허용합니다.
        chooseMultipleMusicFiles();
    }
    private void importMusicFolderAsync(Uri tree) {
        new Thread(()->{try{int count=saveMusicFolder(tree);musicImportResult(true,count,"");}
            catch(Exception e){musicImportResult(false,-1,e.getMessage());}},"V3-MusicFolderImport").start();
    }
    private void musicImportResult(boolean ok,int count,String error) {
        runOnUiThread(()->{
            Toast.makeText(this,ok?"우리 음악폴더 "+count+"곡 저장 완료":String.valueOf(error)+" · 기존 목록은 유지됩니다.",Toast.LENGTH_LONG).show();
            try{JSONObject j=new JSONObject();j.put("ok",ok);j.put("count",count);j.put("error",error);
                if(webView!=null)webView.evaluateJavascript("if(window.onMusicLibraryChanged)onMusicLibraryChanged("+j.toString()+");",null);
            }catch(Exception ignored){}
            if(ok && count>0) {
                // 폴더 저장 직후 곡목록을 보여 주고 사용자가 첫 재생곡을 직접 선택합니다.
                scoreHandler.postDelayed(this::openSavedMusicLibraryChooser, 250);
            }
        });
    }

    private void chooseMultipleMusicFiles() {
        runOnUiThread(() -> {
            // STAGE4.38: 앱 내부 MediaStore 목록이 아니라 Samsung '내 파일'을 직접 엽니다.
            // 사용자가 실제로 보관한 Music / melon 등의 폴더에서 곡을 고르게 합니다.
            try {
                Intent s = new Intent("com.sec.android.app.myfiles.PICK_DATA_MULTIPLE");
                s.setPackage("com.sec.android.app.myfiles");
                s.putExtra("CONTENT_TYPE", "audio/*");
                s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                s.putExtra("FOLDERPATH", "/storage/emulated/0/Music");
                s.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                s.addCategory(Intent.CATEGORY_DEFAULT);
                startActivityForResult(s, MUSIC_MULTI_PICKER);
                return;
            } catch (Exception ignored) {}

            // 일부 One UI 버전은 PICK_DATA_MULTIPLE 대신 PICK_DATA만 제공합니다.
            // 이 경우에도 내 파일을 우선 열고, 다중 선택 가능 여부는 내 파일 구현에 맡깁니다.
            try {
                Intent s = new Intent("com.sec.android.app.myfiles.PICK_DATA");
                s.setPackage("com.sec.android.app.myfiles");
                s.putExtra("CONTENT_TYPE", "audio/*");
                s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                s.putExtra("FOLDERPATH", "/storage/emulated/0/Music");
                s.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                s.addCategory(Intent.CATEGORY_DEFAULT);
                startActivityForResult(s, MUSIC_MULTI_PICKER);
                return;
            } catch (Exception ignored) {}

            // Samsung 내 파일 전용 선택 액션이 없는 기기에서만 Android 표준 파일 선택기로 대체합니다.
            String[] docPkgs = new String[]{"com.google.android.documentsui", "com.android.documentsui"};
            for (String pkg : docPkgs) {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.setPackage(pkg);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("audio/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        try { i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                                Uri.parse("content://com.android.externalstorage.documents/document/primary%3AMusic")); }
                        catch (Exception ignored) {}
                    }
                    startActivityForResult(i, MUSIC_MULTI_PICKER);
                    return;
                } catch (Exception ignored) {}
            }
            try {
                Intent fallback=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                fallback.addCategory(Intent.CATEGORY_OPENABLE);
                fallback.setType("audio/*");fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                if(Build.VERSION.SDK_INT>=26)fallback.putExtra(DocumentsContract.EXTRA_INITIAL_URI,Uri.parse("content://com.android.externalstorage.documents/document/primary%3AMusic"));
                startActivityForResult(fallback,MUSIC_MULTI_PICKER);return;
            }catch(Exception ignored){}
            Toast.makeText(this, "음악 선택 화면을 열지 못했습니다. 우리 음악폴더 연결을 사용해 주세요.", Toast.LENGTH_LONG).show();
        });
    }

    private int saveMultipleMusicFiles(Intent data) throws Exception {
        ArrayList<Uri> uris = new ArrayList<>();
        if(data.getClipData()!=null) for(int i=0;i<data.getClipData().getItemCount();i++) {
            Uri u=data.getClipData().getItemAt(i).getUri();if(u!=null)uris.add(u);
        }
        if(data.getData()!=null)uris.add(data.getData());
        // One UI can return paths in an extra rather than ClipData. Collect them too.
        if(data.getExtras()!=null) for(String key:new String[]{"SELECTED_FILES","selectedItems","selected_files","filePaths","uris"}) {
            Object value=data.getExtras().get(key);
            if(value instanceof java.util.Collection)for(Object v:(java.util.Collection<?>)value)addMusicResultUri(uris,v);
            else if(value instanceof Object[])for(Object v:(Object[])value)addMusicResultUri(uris,v);
        }
        int count=new MusicLibraryStore(this).appendUris(uris,data.getFlags());
        musicLibraryChanged(count);return count;
    }
    private void addMusicResultUri(ArrayList<Uri> uris,Object value) {
        if(value instanceof Uri)uris.add((Uri)value);
        else if(value instanceof String){String v=(String)value;if(v.startsWith("/"))uris.add(Uri.fromFile(new File(v)));else if(v.startsWith("content://")||v.startsWith("file://"))uris.add(Uri.parse(v));}
    }
    private void musicLibraryChanged(int count) {
        musicPrefs().edit().putString(MUSIC_NAME,"우리 음악폴더 · "+count+"곡").apply();
        if(musicEnabled()||MusicPlaybackService.isRunning())sendMusicCommand(MusicPlaybackService.ACTION_RELOAD);
    }







    private boolean looksLikeAudio(String name, String mime) {
        if (mime != null && mime.toLowerCase().startsWith("audio/")) return true;
        String n = name == null ? "" : name.toLowerCase();
        return n.endsWith(".mp3") || n.endsWith(".m4a") || n.endsWith(".aac") || n.endsWith(".wav") || n.endsWith(".ogg") || n.endsWith(".flac");
    }





    private int saveMusicFolder(Uri treeUri) throws Exception {
        int count=new MusicLibraryStore(this).appendFolder(treeUri);
        musicLibraryChanged(count);return count;
    }

    private int musicPlaylistCount() {
        try{return new MusicLibraryStore(this).read().size();}catch(Exception e){return -1;}
    }

    private void saveSelectedMusic(Uri uri, String name) throws Exception {
        ArrayList<Uri> uris=new ArrayList<>();uris.add(uri);
        int count=new MusicLibraryStore(this).appendUris(uris,Intent.FLAG_GRANT_READ_URI_PERMISSION);
        musicLibraryChanged(count);
    }

    private void clearSelectedMusic() {
        // '기본 음악으로' changes playback mode; it must NEVER erase a saved MP3 library.
        sendMusicCommand(MusicPlaybackService.ACTION_DEFAULT);
    }

    @Override protected void onResume() {
        super.onResume();
        if (overlayUpdateScreenActive) suspendOverlayForUpdate();
        if (musicEnabled()) startBackgroundMusic(); // Resume the same saved song; no reset.
        handleSavedMusicIntent(getIntent());
        handleOverlayUpdateIntent(getIntent());
        // STAGE4.51: V2·V3 공용 승인 서버 연동 유지. 특별승인 요청이 이미 있다면, 항해사 승인 후 앱으로 돌아오는 즉시
        // 서버 승인 상태를 다시 확인해 별도 버튼 없이 자동으로 잠금을 해제합니다.
        if (!isSpecialApprovedLocal()) {
            SharedPreferences sp = specialApprovalPrefs();
            String token = sp.getString("request_token", "");
            if (token != null && !token.isEmpty()) {
                checkSpecialApprovalAsync();
            }
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleOverlayAudioPermissionRequest(intent);
        handleSavedMusicIntent(intent);
        handleOverlayUpdateIntent(intent);
    }

    private void handleOverlayAudioPermissionRequest(Intent intent) {
        if (intent == null || !intent.getBooleanExtra("v3_request_audio_permission", false)) return;
        intent.removeExtra("v3_request_audio_permission");
        if (hasAudioLibraryPermission()) {
            Toast.makeText(this, "음악 권한이 이미 허용되어 있습니다. 이동아이콘의 MP3를 눌러 재생해 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{android.Manifest.permission.READ_MEDIA_AUDIO}, AUTO_AUDIO_PERMISSION);
            } else if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, AUTO_AUDIO_PERMISSION);
            }
        } catch (Exception e) {
            Toast.makeText(this, "설정에서 음악 및 오디오 권한을 허용해 주세요.", Toast.LENGTH_LONG).show();
        }
    }

    // V3.1.06: one-time permission for direct phone MP3 playback from the floating Music button.
    private void requestAutoAudioPermissionOnce() {
        if (Build.VERSION.SDK_INT < 23 || hasAudioLibraryPermission()) return;
        SharedPreferences p = getSharedPreferences("v3_music_preferences", MODE_PRIVATE);
        if (p.getBoolean("auto_audio_permission_asked", false)) return;
        p.edit().putBoolean("auto_audio_permission_asked", true).apply();
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{android.Manifest.permission.READ_MEDIA_AUDIO}, AUTO_AUDIO_PERMISSION);
            } else {
                requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, AUTO_AUDIO_PERMISSION);
            }
        } catch (Exception ignored) {}
    }

    // ---------------- Internal music library (no external picker) ----------------
    private boolean hasAudioLibraryPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission(android.Manifest.permission.READ_MEDIA_AUDIO)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestDeviceMusicLibrary(String mode) {
        pendingMusicLibraryMode = (mode == null || mode.trim().isEmpty()) ? "multi" : mode.trim();
        runOnUiThread(() -> {
            Toast.makeText(this, "휴대폰 음악목록을 불러오는 중입니다.", Toast.LENGTH_SHORT).show();
            if (hasAudioLibraryPermission()) {
                showNativeMusicMultiPicker();
                return;
            }
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(new String[]{android.Manifest.permission.READ_MEDIA_AUDIO}, AUDIO_LIBRARY_PERMISSION);
                } else {
                    requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, AUDIO_LIBRARY_PERMISSION);
                }
            } catch (Exception e) {
                deliverDeviceMusicLibraryError("음악 및 오디오 권한을 요청하지 못했습니다.");
            }
        });
    }

    private void showNativeMusicMultiPicker() {
        new Thread(() -> {
            try {
                final ArrayList<Long> ids = new ArrayList<>();
                final ArrayList<String> labels = new ArrayList<>();
                Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                String[] projection = new String[]{
                        MediaStore.Audio.Media._ID,
                        MediaStore.Audio.Media.DISPLAY_NAME,
                        MediaStore.Audio.Media.ARTIST,
                        MediaStore.Audio.Media.DURATION
                };
                String selection = null;
                if (Build.VERSION.SDK_INT >= 29) selection = MediaStore.Audio.Media.IS_MUSIC + "!=0";
                String sort = MediaStore.Audio.Media.DISPLAY_NAME + " COLLATE NOCASE ASC";
                try (Cursor c = getContentResolver().query(base, projection, selection, null, sort)) {
                    if (c != null) {
                        int idIx = c.getColumnIndex(MediaStore.Audio.Media._ID);
                        int nameIx = c.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME);
                        int artistIx = c.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                        while (c.moveToNext()) {
                            long id = idIx >= 0 ? c.getLong(idIx) : -1L;
                            if (id < 0) continue;
                            String name = nameIx >= 0 ? c.getString(nameIx) : ("track_" + id);
                            String artist = artistIx >= 0 ? c.getString(artistIx) : "";
                            if (name == null || name.trim().isEmpty()) name = "음악 " + (ids.size() + 1);
                            ids.add(id);
                            if (artist == null || artist.trim().isEmpty() || "<unknown>".equalsIgnoreCase(artist.trim())) labels.add(name);
                            else labels.add(name + "  ·  " + artist);
                        }
                    }
                }
                runOnUiThread(() -> {
                    if (ids.isEmpty()) {
                        Toast.makeText(this, "휴대폰에서 재생 가능한 음악을 찾지 못했습니다.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    final boolean[] checked = new boolean[ids.size()];
                    CharSequence[] rows = labels.toArray(new CharSequence[0]);
                    android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(MainActivity.this)
                            .setTitle("연속 재생 음악 선택")
                            .setMultiChoiceItems(rows, checked, (d, which, isChecked) -> checked[which] = isChecked)
                            .setNegativeButton("취소", null)
                            .setPositiveButton("선택 음악 재생", null)
                            .create();
                    dialog.setOnShowListener(x -> dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                        JSONArray picked = new JSONArray();
                        for (int i = 0; i < checked.length; i++) if (checked[i]) picked.put(ids.get(i));
                        if (picked.length() == 0) {
                            Toast.makeText(MainActivity.this, "음악을 한 곡 이상 선택해 주세요.", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "선택한 음악을 재생목록에 저장합니다.", Toast.LENGTH_SHORT).show();
                        saveDeviceMusicSelection(picked.toString());
                    }));
                    dialog.show();
                });
            } catch (Exception e) {
                deliverDeviceMusicLibraryError("휴대폰 음악목록을 읽지 못했습니다.");
            }
        }, "V3-NativeMusicPicker").start();
    }

    private JSONArray readDeviceMusicLibrary() throws Exception {
        JSONArray out = new JSONArray();
        Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        ArrayList<String> cols = new ArrayList<>();
        cols.add(MediaStore.Audio.Media._ID);
        cols.add(MediaStore.Audio.Media.DISPLAY_NAME);
        cols.add(MediaStore.Audio.Media.ARTIST);
        cols.add(MediaStore.Audio.Media.DURATION);
        if (Build.VERSION.SDK_INT >= 29) cols.add(MediaStore.Audio.Media.RELATIVE_PATH);
        String[] projection = cols.toArray(new String[0]);
        String sort = MediaStore.Audio.Media.DISPLAY_NAME + " COLLATE NOCASE ASC";
        try (Cursor c = getContentResolver().query(base, projection, null, null, sort)) {
            if (c == null) return out;
            int idIx = c.getColumnIndex(MediaStore.Audio.Media._ID);
            int nameIx = c.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME);
            int artistIx = c.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int durIx = c.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int pathIx = Build.VERSION.SDK_INT >= 29 ? c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH) : -1;
            while (c.moveToNext()) {
                long id = idIx >= 0 ? c.getLong(idIx) : -1L;
                if (id < 0) continue;
                String name = nameIx >= 0 ? c.getString(nameIx) : ("track_" + id);
                String artist = artistIx >= 0 ? c.getString(artistIx) : "";
                long duration = durIx >= 0 ? c.getLong(durIx) : 0L;
                String path = pathIx >= 0 ? c.getString(pathIx) : "Music/";
                if (name == null || name.trim().isEmpty()) name = "track_" + id;
                if (!looksLikeAudio(name, "audio/*")) continue;
                JSONObject x = new JSONObject();
                x.put("id", id);
                x.put("name", name);
                x.put("artist", artist == null ? "" : artist);
                x.put("duration", duration);
                x.put("path", path == null || path.trim().isEmpty() ? "Music/" : path);
                out.put(x);
            }
        }
        return out;
    }

    private void deliverDeviceMusicLibrary(String mode) {
        final String m = (mode == null || mode.trim().isEmpty()) ? "multi" : mode;
        new Thread(() -> {
            try {
                JSONObject payload = new JSONObject();
                payload.put("ok", true);
                payload.put("mode", m);
                payload.put("items", readDeviceMusicLibrary());
                final String json = payload.toString();
                webView.post(() -> webView.evaluateJavascript("onDeviceMusicLibrary(" + json + ");", null));
            } catch (Exception e) {
                deliverDeviceMusicLibraryError("휴대폰 음악 목록을 읽지 못했습니다.");
            }
        }, "V3-MusicLibrary").start();
    }

    private void deliverDeviceMusicLibraryError(String message) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("ok", false);
            payload.put("mode", pendingMusicLibraryMode);
            payload.put("error", message == null ? "음악 목록 오류" : message);
            final String json = payload.toString();
            webView.post(() -> webView.evaluateJavascript("onDeviceMusicLibrary(" + json + ");", null));
        } catch (Exception ignored) {}
    }

    private int copyMediaIdsToPlaylist(JSONArray ids) throws Exception {
        ArrayList<Uri> uris=new ArrayList<>();
        for(int i=0;i<ids.length();i++){long id=ids.optLong(i,-1);if(id>=0)uris.add(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id));}
        int count=new MusicLibraryStore(this).appendUris(uris,Intent.FLAG_GRANT_READ_URI_PERMISSION);
        musicLibraryChanged(count);return count;
    }

    private void saveDeviceMusicSelection(String idsJson) {
        new Thread(() -> {
            try {
                JSONArray ids = new JSONArray(idsJson == null ? "[]" : idsJson);
                int count = copyMediaIdsToPlaylist(ids);
                JSONObject r = new JSONObject(); r.put("ok", true); r.put("count", count);
                final String json = r.toString();
                webView.post(() -> webView.evaluateJavascript("onDeviceMusicPlaylistSaved(" + json + ");", null));
            } catch (Exception e) {
                try {
                    JSONObject r = new JSONObject(); r.put("ok", false); r.put("error", e.getMessage() == null ? "음악 저장 실패" : e.getMessage());
                    final String json = r.toString();
                    webView.post(() -> webView.evaluateJavascript("onDeviceMusicPlaylistSaved(" + json + ");", null));
                } catch (Exception ignored) {}
            }
        }, "V3-MusicSave").start();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUTO_AUDIO_PERMISSION) {
            boolean ok = grantResults != null && grantResults.length > 0
                    && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
            Toast.makeText(this,
                    ok ? "음악 및 오디오 권한이 허용되었습니다. 필요한 MP3를 직접 선택해 주세요."
                       : "MP3 파일 접근 권한을 허용해 주세요.",
                    Toast.LENGTH_LONG).show();
            if (ok) chooseMultipleMusicFiles();
            return;
        }
        if (requestCode == AUDIO_LIBRARY_PERMISSION) {
            boolean ok = grantResults != null && grantResults.length > 0
                    && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
            if (ok) showNativeMusicMultiPicker();
            else deliverDeviceMusicLibraryError("음악 및 오디오 권한이 필요합니다. 설정에서 권한을 허용해 주세요.");
        }
    }

    // 다른 앱으로 이동하거나 화면이 꺼져도 포그라운드 서비스가 음악을 계속 재생합니다.
    @Override protected void onPause() {
        super.onPause();
        // 업데이트 화면이 활성화된 동안에는 다른 앱/설치화면으로 이동해도 오버레이를 다시 띄우지 않는다.
        if (overlayUpdateScreenActive) suspendOverlayForUpdate();
    }

    @Override protected void onDestroy() {
        // Activity 재생성/종료만으로 배경음악 서비스는 끄지 않습니다.
        // 성적 안내용 TTS/축하음악과 실행 인트로 바다소리만 Activity 종료 시 정리합니다.
        stopScoreFanfare();
        try {
            if (scoreTts != null) {
                scoreTts.stop();
                scoreTts.shutdown();
                scoreTts = null;
            }
        } catch (Exception ignored) {}
        try {
            if (launchSeaPlayer != null) {
                launchSeaPlayer.release();
                launchSeaPlayer = null;
            }
        } catch (Exception ignored) {}
        try {
            releaseNativeVoyageMedia();
            if (launchVideo != null) {
                if (rootLayout != null) rootLayout.removeView(launchVideo);
                launchVideo = null;
            }
        } catch (Exception ignored) {}
        try {
            if (launchTts != null) {
                launchTts.stop();
                launchTts.shutdown();
                launchTts = null;
            }
        } catch (Exception ignored) {}
        try { stopRadioDirectInternal(); } catch (Exception ignored) {}
        super.onDestroy();
    }

    private void initScoreTts() {
        try {
            scoreTts = new TextToSpeech(getApplicationContext(), status -> {
                if (status == TextToSpeech.SUCCESS) {
                    try {
                        int lang = scoreTts.setLanguage(Locale.KOREAN);
                        scoreTtsReady = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            scoreTts.setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .build());
                        }
                        if (scoreTtsReady && pendingScoreSpeech != null && !pendingScoreSpeech.trim().isEmpty()) {
                            String text = pendingScoreSpeech;
                            int rank = pendingScoreRank;
                            pendingScoreSpeech = null;
                            pendingScoreRank = 0;
                            speakScoreNow(text, rank);
                        }
                    } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {
            scoreTtsReady = false;
        }
    }

    private void stopScoreFanfare() {
        try {
            if (scoreFanfarePlayer != null) {
                try { scoreFanfarePlayer.stop(); } catch (Exception ignored) {}
                try { scoreFanfarePlayer.release(); } catch (Exception ignored) {}
                scoreFanfarePlayer = null;
            }
        } catch (Exception ignored) {}
    }

    private void playScoreFanfare() {
        runOnUiThread(() -> {
            try {
                stopScoreFanfare();
                scoreFanfarePlayer = MediaPlayer.create(MainActivity.this, R.raw.v3_congrats_fanfare);
                if (scoreFanfarePlayer != null) {
                    scoreFanfarePlayer.setVolume(0.82f, 0.82f);
                    scoreFanfarePlayer.setOnCompletionListener(mp -> {
                        try { mp.release(); } catch (Exception ignored) {}
                        if (scoreFanfarePlayer == mp) scoreFanfarePlayer = null;
                    });
                    scoreFanfarePlayer.start();
                }
            } catch (Exception ignored) {}
        });
    }

    private void speakScoreNow(String text, int rankNo) {
        if (text == null || text.trim().isEmpty()) return;
        runOnUiThread(() -> {
            try {
                if (scoreTts == null || !scoreTtsReady) {
                    pendingScoreSpeech = text;
                    pendingScoreRank = rankNo;
                    return;
                }
                scoreTts.setSpeechRate(rankNo > 0 && rankNo <= 2 ? 0.90f : 0.96f);
                scoreTts.setPitch(rankNo > 0 ? 1.03f : 1.0f);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    scoreTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "v3_score_voice");
                } else {
                    scoreTts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                }
            } catch (Exception ignored) {}
        });
    }

    private void playCelebrationWithVoice(String text, int rankNo) {
        playScoreFanfare();
        scoreHandler.postDelayed(() -> speakScoreNow(text, rankNo), 650L);
    }

    private void speakConsolationVoice(String text) {
        stopScoreFanfare();
        scoreHandler.postDelayed(() -> speakScoreNow(text, 0), 180L);
    }

    private void setDownloadInitialUri(Intent i) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                        Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"));
            } catch (Exception ignored) {}
        }
    }

    private void chooseApkUpdateFile() {
        runOnUiThread(() -> {
            // STAGE4.35: 업데이트 경로는 Samsung 내 파일로만 고정합니다.
            // 시스템 ACTION_OPEN_DOCUMENT/GET_CONTENT는 사용하지 않으므로
            // AndroidIDE/A-IDE가 파일선택 요청을 가로챌 수 없습니다.
            try {
                Intent s = new Intent("com.sec.android.app.myfiles.PICK_DATA");
                s.setPackage("com.sec.android.app.myfiles");
                s.putExtra("CONTENT_TYPE", "*/*");
                s.putExtra("FOLDERPATH", "/storage/emulated/0/Download");
                s.addCategory(Intent.CATEGORY_DEFAULT);
                s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(s, APK_UPDATE_PICKER);
                Toast.makeText(this, "내 파일에서 업데이트 APK를 선택해 주세요.", Toast.LENGTH_SHORT).show();
                return;
            } catch (Exception ignored) {}

            // PICK_DATA를 지원하지 않는 Samsung 버전은 내 파일 앱 자체를 엽니다.
            // 사용자가 Download 폴더의 APK를 누르면 Android 설치 화면으로 이어집니다.
            try {
                Intent launch = getPackageManager().getLaunchIntentForPackage("com.sec.android.app.myfiles");
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    Toast.makeText(this, "내 파일의 Download 폴더에서 업데이트 APK를 눌러 설치해 주세요.", Toast.LENGTH_LONG).show();
                    return;
                }
            } catch (Exception ignored) {}

            Toast.makeText(this, "Samsung 내 파일 앱을 열지 못했습니다.", Toast.LENGTH_LONG).show();
        });
    }

    private void launchApkInstaller(Uri uri) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "APK 설치 화면을 열지 못했습니다.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == APK_UPDATE_PICKER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                String name = displayName(uri);
                String type = getContentResolver().getType(uri);
                boolean looksApk = (name != null && name.toLowerCase().endsWith(".apk"))
                        || "application/vnd.android.package-archive".equals(type)
                        || "application/octet-stream".equals(type);
                if (!looksApk) {
                    Toast.makeText(this, "APK 파일을 선택해 주세요.", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(this, "업데이트 APK 선택 완료", Toast.LENGTH_SHORT).show();
                launchApkInstaller(uri);
            }
            return;
        }

        if (requestCode == UPDATE_PICKER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try { alert(installUpdate(readUri(data.getData())) ? "V3 업데이트 적용 완료" : "업데이트 파일이 올바르지 않습니다."); }
                catch (Exception e) { alert("업데이트 적용 실패"); }
            }
            return;
        }

        if (requestCode == TEXT_PICKER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    Uri uri = data.getData();
                    String name = displayName(uri);
                    String text = readUri(uri);
                    String js = "receiveText(" + JSONObject.quote(name) + "," + JSONObject.quote(text) + ");";
                    webView.post(() -> webView.evaluateJavascript(js, null));
                } catch (Exception e) { alert("원문 TXT 불러오기 실패"); }
            }
            return;
        }

        if (requestCode == LEGACY_BACKUP_PICKER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    Uri uri = data.getData();
                    sendLegacyBackupToJs(displayName(uri), readUri(uri));
                } catch (Exception e) { alert("백업 JSON을 읽지 못했습니다."); }
            }
            return;
        }

        if(requestCode==MUSIC_PICKER || requestCode==MUSIC_MULTI_PICKER) {
            if(resultCode==RESULT_OK && data!=null) {
                final Intent picked=data;
                new Thread(()->{try{int count=saveMultipleMusicFiles(picked);musicImportResult(true,count,"");}
                    catch(Exception e){musicImportResult(false,-1,e.getMessage());}},"V3-MusicImport").start();
            }
            return; // Cancel never modifies playlist/position/selected folder.
        }
        if(requestCode==MUSIC_FOLDER_PICKER) {
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null) {
                Uri tree = data.getData();
                try {
                    final int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(tree, flags | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                musicPrefs().edit()
                        .putString("music_library_folder_uri", tree.toString())
                        .putString(MUSIC_TREE_URI, tree.toString())
                        .apply();
                importMusicFolderAsync(tree);
            }
            return;
        }

        if (requestCode == SAVE_PICKER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingData != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("save failed");
                    out.write(pendingData.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    alert("파일 저장 완료");
                } catch (Exception e) { alert("파일 저장 실패"); }
            }
            pendingData = null;
            pendingName = null;
            pendingMime = null;
        }
    }

    private String httpGet(String urlText) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlText);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setUseCaches(false);
            conn.setRequestProperty("Accept", "application/json, text/plain, */*");
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36");
            conn.setRequestProperty("X-Requested-With", "XMLHttpRequest");
            conn.setRequestProperty("Referer", "https://www.dhlottery.co.kr/lt645/result");
            int code = conn.getResponseCode();
            InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            if (in == null) throw new Exception("HTTP " + code);
            String body = new String(readAll(in), StandardCharsets.UTF_8);
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            return body;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private JSONObject parseWinningNewApi(int round, String body) throws Exception {
        JSONObject root = new JSONObject(body);
        JSONObject data = root.optJSONObject("data");
        JSONArray list = data == null ? null : data.optJSONArray("list");
        if (list == null || list.length() == 0) throw new Exception("당첨결과 없음");
        JSONObject rec = null;
        for (int i = 0; i < list.length(); i++) {
            JSONObject x = list.optJSONObject(i);
            if (x != null && x.optInt("ltEpsd", -1) == round) { rec = x; break; }
        }
        if (rec == null) rec = list.optJSONObject(0);
        if (rec == null || rec.optInt("ltEpsd", -1) != round) throw new Exception("회차 결과 없음");
        JSONArray nums = new JSONArray();
        for (int i = 1; i <= 6; i++) {
            int n = rec.optInt("tm" + i + "WnNo", 0);
            if (n < 1 || n > 45) throw new Exception("당첨번호 형식 오류");
            nums.put(n);
        }
        int bonus = rec.optInt("bnsWnNo", 0);
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("round", round);
        out.put("numbers", nums);
        out.put("bonus", bonus);
        out.put("date", rec.optString("ltRflYmd", ""));
        out.put("source", "동행복권");
        return out;
    }

    private JSONObject parseWinningLegacyApi(int round, String body) throws Exception {
        JSONObject j = new JSONObject(body);
        if (!"success".equalsIgnoreCase(j.optString("returnValue", ""))) throw new Exception("결과 없음");
        JSONArray nums = new JSONArray();
        for (int i = 1; i <= 6; i++) {
            int n = j.optInt("drwtNo" + i, 0);
            if (n < 1 || n > 45) throw new Exception("당첨번호 형식 오류");
            nums.put(n);
        }
        JSONObject out = new JSONObject();
        out.put("ok", true);
        out.put("round", round);
        out.put("numbers", nums);
        out.put("bonus", j.optInt("bnusNo", 0));
        out.put("date", j.optString("drwNoDate", ""));
        out.put("source", "동행복권");
        return out;
    }

    private void deliverWinningResult(JSONObject result) {
        final String json = result == null ? "{}" : result.toString();
        webView.post(() -> webView.evaluateJavascript(
                "(function(d){" +
                "try{if(window.__v3WinningResult)window.__v3WinningResult(d);}catch(e){}" +
                "try{var f=document.getElementById('engineFrame');if(f&&f.contentWindow&&f.contentWindow.__baekhakWinningResult)f.contentWindow.__baekhakWinningResult(d);}catch(e){}" +
                "})(" + json + ");", null));
    }

    private void fetchWinningNumbersAsync(final int round) {
        if (round < 1 || round > 9999) {
            try {
                JSONObject e = new JSONObject(); e.put("ok", false); e.put("round", round); e.put("error", "회차 번호가 올바르지 않습니다.");
                deliverWinningResult(e);
            } catch (Exception ignored) {}
            return;
        }
        new Thread(() -> {
            JSONObject result = null;
            String lastError = "당첨번호를 조회하지 못했습니다.";
            try {
                long ts = System.currentTimeMillis();
                String body = httpGet("https://www.dhlottery.co.kr/lt645/selectPstLt645Info.do?srchLtEpsd=" + round + "&_=" + ts);
                result = parseWinningNewApi(round, body);
            } catch (Exception e) {
                lastError = e.getMessage() == null ? lastError : e.getMessage();
                try {
                    String body = httpGet("https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=" + round);
                    result = parseWinningLegacyApi(round, body);
                } catch (Exception e2) {
                    if (e2.getMessage() != null) lastError = e2.getMessage();
                }
            }
            if (result == null) {
                try {
                    result = new JSONObject();
                    result.put("ok", false);
                    result.put("round", round);
                    result.put("error", "제" + round + "회 당첨번호가 아직 발표되지 않았거나 네트워크 조회에 실패했습니다. (" + lastError + ")");
                } catch (Exception ignored) {}
            }
            deliverWinningResult(result);
        }, "V3-WinningLookup").start();
    }

    private String handleMusicAction(String action) {
        String a = action == null ? "" : action.trim().toLowerCase(java.util.Locale.ROOT);
        try {
            if ("folder".equals(a)) { chooseMusicFolder(); return "필요한 MP3를 직접 선택합니다."; }
            if ("refreshfolder".equals(a)) { refreshOurMusicFolder(); return "필요한 MP3를 추가로 직접 선택합니다."; }
            if ("library".equals(a)) { sendMusicCommand(MusicPlaybackService.ACTION_LIBRARY); return "저장된 음악을 이어 재생합니다."; }
            if ("multi".equals(a)) { chooseMultipleMusicFiles(); return "내 파일에서 연속곡을 선택합니다."; }
            if ("single".equals(a)) { chooseMusicFile(); return "한 곡 선택 화면을 엽니다."; }
            if ("prev".equals(a)) { sendMusicCommand(MusicPlaybackService.ACTION_PREV); return "이전 곡으로 이동했습니다."; }
            if ("play".equals(a)) { musicPrefs().edit().putBoolean(MUSIC_ENABLED, true).apply(); sendMusicCommand(MusicPlaybackService.ACTION_PLAY); return "선택한 음악 재생을 시작했습니다."; }
            if ("pause".equals(a)) { musicPrefs().edit().putBoolean(MUSIC_ENABLED, false).apply(); sendMusicCommand(MusicPlaybackService.ACTION_PAUSE); return "일시정지했습니다."; }
            if ("next".equals(a)) { sendMusicCommand(MusicPlaybackService.ACTION_NEXT); return "다음 곡으로 이동했습니다."; }
            if ("toggle".equals(a)) { return toggleBackgroundMusic() ? "재생을 시작했습니다." : "일시정지했습니다."; }
            if ("stop".equals(a)) { stopBackgroundMusic(); return "음악을 종료했습니다."; }
            if ("reset".equals(a)) { clearSelectedMusic(); return "기본 음악으로 전환했습니다. 우리 음악폴더의 곡은 보존됩니다."; }
            return "알 수 없는 음악 명령입니다.";
        } catch (Exception e) {
            return "음악 기능 처리 중 오류가 발생했습니다.";
        }
    }


    private void stopRadioDirectInternal() {
        radioPlaying = false;
        radioName = "";
        radioUrl = "";
        try {
            if (radioPlayer != null) {
                try { radioPlayer.setOnPreparedListener(null); } catch (Exception ignored) {}
                try { radioPlayer.setOnErrorListener(null); } catch (Exception ignored) {}
                try { radioPlayer.stop(); } catch (Exception ignored) {}
                try { radioPlayer.reset(); } catch (Exception ignored) {}
                try { radioPlayer.release(); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        radioPlayer = null;
    }

    private void stopRadioDirect() {
        runOnUiThread(this::stopRadioDirectInternal);
    }

    private void playRadioDirect(String url, String name) {
        final String u = url == null ? "" : url.trim();
        final String n = name == null ? "FM 라디오" : name.trim();
        if (!(u.startsWith("https://") || u.startsWith("http://"))) return;
        runOnUiThread(() -> {
            stopRadioDirectInternal();
            try {
                // Local music and radio should not overlap.
                try { stopBackgroundMusic(); } catch (Exception ignored) {}
                MediaPlayer mp = new MediaPlayer();
                radioPlayer = mp;
                radioUrl = u;
                radioName = n.isEmpty() ? "FM 라디오" : n;
                mp.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build());
                mp.setDataSource(u);
                mp.setOnPreparedListener(done -> {
                    if (radioPlayer != done) return;
                    try {
                        done.start();
                        radioPlaying = true;
                    } catch (Exception e) {
                        stopRadioDirectInternal();
                    }
                });
                mp.setOnErrorListener((bad, what, extra) -> {
                    if (radioPlayer == bad) stopRadioDirectInternal();
                    return true;
                });
                mp.prepareAsync();
            } catch (Exception e) {
                stopRadioDirectInternal();
            }
        });
    }

    private String radioStateJson() {
        JSONObject j = new JSONObject();
        try {
            boolean p = radioPlaying;
            try { p = p && radioPlayer != null && radioPlayer.isPlaying(); } catch (Exception ignored) {}
            j.put("playing", p);
            j.put("name", radioName == null ? "" : radioName);
            j.put("url", radioUrl == null ? "" : radioUrl);
        } catch (Exception ignored) {}
        return j.toString();
    }

    public final class AndroidHostBridge {
        @JavascriptInterface public void launchIntroDone() { runOnUiThread(() -> finishLaunchIntroNative()); }
        @JavascriptInterface public void requestUpdateStats() { requestUpdateStatsAsync(); }
        @JavascriptInterface public void requestNamedUpdateStats() { requestNamedUpdateStatsAsync(); }
        @JavascriptInterface public String getUpdateDisplayName() { return getStoredUpdateDisplayName(); }
        @JavascriptInterface public void setUpdateDisplayNameAndReport(String name) { setUpdateDisplayNameAndReportAsync(name); }
        @JavascriptInterface public boolean isSpecialApproved() { return isSpecialApprovedLocal(); }
        @JavascriptInterface public String getSpecialApprovalSummary() { return specialApprovalSummaryJson(); }
        @JavascriptInterface public void requestSpecialApproval(int round, String applicantName, String referrerName) { requestSpecialApprovalAsync(round, applicantName, referrerName); }
        @JavascriptInterface public String getApprovalApplicantName() { return specialApprovalPrefs().getString("applicant_name", ""); }
        @JavascriptInterface public String getApprovalReferrerName() { return specialApprovalPrefs().getString("referrer_name", ""); }
        @JavascriptInterface public void checkSpecialApproval() { checkSpecialApprovalAsync(); }
        @JavascriptInterface public String musicAction(String action) { return handleMusicAction(action); }
        @JavascriptInterface public void playRadioDirect(String url, String name) { MainActivity.this.playRadioDirect(url, name); }
        @JavascriptInterface public void stopRadioDirect() { MainActivity.this.stopRadioDirect(); }
        @JavascriptInterface public String getRadioDirectState() { return MainActivity.this.radioStateJson(); }
        @JavascriptInterface public boolean isOverlayIconEnabled() { return MainActivity.this.isOverlayControlEnabled(); }
        @JavascriptInterface public void setOverlayIconEnabled(boolean enabled) {
            runOnUiThread(() -> MainActivity.this.setOverlayControlEnabled(enabled));
        }

        @JavascriptInterface public void openRadioPage(String url) {
            final String u = url == null ? "" : url.trim();
            if (!(u.startsWith("https://") || u.startsWith("http://"))) return;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "라디오 페이지를 열지 못했습니다.", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface public void playCelebrationWithVoice(String text, int rankNo) { MainActivity.this.playCelebrationWithVoice(text, rankNo); }
        @JavascriptInterface public void speakCelebration(String text, int rankNo) { MainActivity.this.speakScoreNow(text, rankNo); }
        @JavascriptInterface public void speakConsolation(String text) { MainActivity.this.speakConsolationVoice(text); }
        @JavascriptInterface public void stopScoreVoice() {
            runOnUiThread(() -> {
                try { if (scoreTts != null) scoreTts.stop(); } catch (Exception ignored) {}
                stopScoreFanfare();
            });
        }
        @JavascriptInterface public void exitApp() {
            runOnUiThread(() -> closeAppScreen());
        }

        @JavascriptInterface public void chooseUpdate() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/html", "text/plain", "application/octet-stream"});
                setDownloadInitialUri(i);
                try { startActivityForResult(i, UPDATE_PICKER); }
                catch (Exception e) { alert("HTML 업데이트 파일 선택기를 열 수 없습니다."); }
            });
        }
        @JavascriptInterface public void chooseApkUpdate() { chooseApkUpdateFile(); }
        @JavascriptInterface public String getNativeVersion() {
            try {
                android.content.pm.PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0);
                String name = p.versionName == null ? "V3 native" : p.versionName;
                long code = android.os.Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
                return name + " (" + code + ")";
            } catch (Exception e) {
                return "V3 native";
            }
        }

        @JavascriptInterface public void chooseText() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/plain");
                try { startActivityForResult(i, TEXT_PICKER); }
                catch (Exception e) { alert("TXT 선택기를 열 수 없습니다."); }
            });
        }

        @JavascriptInterface public void chooseLegacyBackup() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                try { startActivityForResult(i, LEGACY_BACKUP_PICKER); }
                catch (Exception e) { alert("백업 JSON 선택기를 열 수 없습니다."); }
            });
        }

        @JavascriptInterface public boolean applyUpdateHtml(String html) { return installUpdate(html); }

        @JavascriptInterface public String backupJsonV37(String json) {
            return saveBackupDirectSync(json);
        }

        @JavascriptInterface public void backupJson(String json) {
            if (json != null && !json.isEmpty()) saveBackupDirect(json);
        }

        @JavascriptInterface public void saveText(String name, String text) {
            if (text != null) createSave(name == null ? "항행의자유_V3_기록.txt" : name, "text/plain", text);
        }

        @JavascriptInterface public void copyText(String text) {
            if (text == null) return;
            runOnUiThread(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Final5", text));
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public boolean clearInstalledUpdate() {
            File f = new File(getFilesDir(), UPDATE_FILE);
            return !f.exists() || f.delete();
        }

        // V1 방식 계승: 휴대폰 음원을 선택하면 앱 내부에 복사해 보존합니다.
        @JavascriptInterface public void fetchWinningNumbers(int round) { fetchWinningNumbersAsync(round); }
        @JavascriptInterface public String getMusicState() { return MusicPlaybackService.snapshot(MainActivity.this); }
        @JavascriptInterface public String getSavedMusicLibrary() { return new MusicLibraryStore(MainActivity.this).asJson(); }
        @JavascriptInterface public void playSavedMusic(String id) {
            runOnUiThread(()->{
                try{Intent i=new Intent(MainActivity.this,MusicPlaybackService.class).setAction(MusicPlaybackService.ACTION_SELECT).putExtra(MusicPlaybackService.EXTRA_TRACK,id);
                    if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
                }catch(Exception e){Toast.makeText(MainActivity.this,"음악 재생을 시작하지 못했습니다.",Toast.LENGTH_LONG).show();}
            });
        }
        @JavascriptInterface public void openOurMusicFolder() { chooseMusicFolder(); }
        @JavascriptInterface public void openDeviceMusicLibrary(String mode) { chooseMultipleMusicFiles(); }
        @JavascriptInterface public void saveDeviceMusicSelection(String idsJson) { MainActivity.this.saveDeviceMusicSelection(idsJson); }
        @JavascriptInterface public void chooseMusic() { chooseMusicFile(); }
        @JavascriptInterface public void chooseMusicFolder() { chooseMusicFolder(); }
        @JavascriptInterface public void chooseMultipleMusic() { chooseMultipleMusicFiles(); }
        @JavascriptInterface public void musicNext() { sendMusicCommand(MusicPlaybackService.ACTION_NEXT); }
        @JavascriptInterface public void musicPrev() { sendMusicCommand(MusicPlaybackService.ACTION_PREV); }
        @JavascriptInterface public void stopMusic() { stopBackgroundMusic(); }
        @JavascriptInterface public int getMusicPlaylistCount() { return musicPlaylistCount(); }
        @JavascriptInterface public String getMusicName() { return musicName(); }
        @JavascriptInterface public boolean isMusicEnabled() { return musicEnabled(); }
        @JavascriptInterface public int getMusicVolume() { return musicVolume(); }
        @JavascriptInterface public boolean toggleMusic() { return toggleBackgroundMusic(); }
        @JavascriptInterface public void setMusicVolume(int percent) { applyMusicVolume(percent); }
        @JavascriptInterface public void clearMusic() { clearSelectedMusic(); }
        @JavascriptInterface public void finishOverlayUpdateScreen() {
            runOnUiThread(() -> { overlayUpdateScreenActive = false; restoreOverlayAfterUpdate(); });
        }
    }


    private void restoreOverlayAfterUpdate() {
        try {
            Intent s = new Intent(this, OverlayControlService.class).setAction(OverlayControlService.ACTION_RESUME);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        } catch (Exception ignored) {}
    }

    @Override public void onBackPressed() {
        overlayUpdateScreenActive = false;
        restoreOverlayAfterUpdate();
        if (launchVideoActive) { closeAppScreen(); return; }
        if (webView != null && webView.canGoBack()) webView.goBack();
        else {
            // 뒤로가기/종료로 앱 화면을 닫아도 배경음악 서비스는 별도로 유지됩니다.
            closeAppScreen();
        }
    }
}
