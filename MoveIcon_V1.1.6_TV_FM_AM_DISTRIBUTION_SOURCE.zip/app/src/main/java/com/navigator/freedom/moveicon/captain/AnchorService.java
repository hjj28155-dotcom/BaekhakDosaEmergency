package com.navigator.freedom.moveicon.captain;

import android.app.*;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** One anchor at the top of the scrollable panel. NO independent square floating anchor. */
public class AnchorService extends Service {
  private static final int ID = 1703;
  private final Handler handler = new Handler(Looper.getMainLooper());
  private WindowManager wm;
  private FrameLayout menu, panelContent;
  private ScrollView scroller;
  private WindowManager.LayoutParams panelParams;
  private android.content.SharedPreferences prefs;
  private int screenW, screenH, contentHeight, headerHeight, panelWidth;
  private boolean expanded;
  private int dp(float n){return Ui.dp(this,n);}
  private int cap(int v,int min,int max){return Math.max(min,Math.min(v,Math.max(min,max)));}

  @Override public void onCreate(){
    super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);
    prefs=getSharedPreferences("anchor",MODE_PRIVATE);readScreenSize();startPersistent();openPanel();
  }
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    if(menu==null)openPanel();return START_STICKY;
  }
  private void readScreenSize(){
    android.util.DisplayMetrics m=new android.util.DisplayMetrics();
    wm.getDefaultDisplay().getRealMetrics(m);screenW=m.widthPixels;screenH=m.heightPixels;
  }
  private WindowManager.LayoutParams params(int w,int h){
    WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,android.graphics.PixelFormat.TRANSLUCENT);
    p.gravity=Gravity.TOP|Gravity.LEFT;return p;
  }
  private void startPersistent(){
    String channel="anchor_one_20261022";
    NotificationChannel ch=new NotificationChannel(channel,"이동아이콘 메뉴 복구",NotificationManager.IMPORTANCE_LOW);
    ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    Intent back=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent pi=PendingIntent.getActivity(this,0,back,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Notification n=new Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_compass)
      .setContentTitle("항행의자유 이동아이콘")
      .setContentText("세로 메뉴가 숨겨졌다면 여기를 눌러 다시 여세요")
      .setContentIntent(pi).setOngoing(true).build();
    if(Build.VERSION.SDK_INT>=34)startForeground(ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
    else startForeground(ID,n);
  }
  private void toast(String msg){Toast.makeText(this,msg,Toast.LENGTH_LONG).show();}
  private void closePanel(){
    if(menu!=null){try{wm.removeView(menu);}catch(Exception ignored){}}
    menu=null;panelContent=null;scroller=null;panelParams=null;expanded=false;
  }
  private void resizePanel(){
    if(menu==null || panelParams==null)return;
    readScreenSize();
    int minimum=Math.min(contentHeight,Math.max(headerHeight+dp(76),dp(123)));
    int maxTop=Math.max(dp(8),screenH-minimum-dp(30));
    panelParams.y=cap(panelParams.y,dp(8),maxTop);
    panelParams.x=cap(panelParams.x,0,Math.max(0,screenW-panelParams.width));
    panelParams.height=Math.min(contentHeight,Math.max(minimum,screenH-panelParams.y-dp(30)));
    try{wm.updateViewLayout(menu,panelParams);}catch(Exception ignored){}
  }
  private Bitmap asset(String name){
    try(java.io.InputStream in=getAssets().open(name)){
      Bitmap b=BitmapFactory.decodeStream(in);
      if(b!=null)return b;
    }catch(Exception ignored){}
    return null;
  }
  private void openPanel(){
    if(menu!=null)return;
    readScreenSize();
    panelWidth=Math.min(dp(142),Math.max(dp(108),screenW-dp(28)));
    // 140px fixed, draggable gold anchor; expanded 2-column scrollable panel with 7 rows.
    final float scale=panelWidth/434f;
    headerHeight=Math.round(140*scale);
    contentHeight=Math.round(1650*scale);
    int bodyHeight=contentHeight-headerHeight;
    menu=new FrameLayout(this);
    LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
    ImageView header=new ImageView(this);
    Bitmap original=asset("approved_panel.jpg");
    if(original==null){menu=null;toast("승인된 메뉴 그림을 불러오지 못했습니다");return;}
    Bitmap top=Bitmap.createBitmap(original,0,0,original.getWidth(),Math.round(original.getHeight()*140f/1158f));
    original.recycle();header.setImageBitmap(top);header.setScaleType(ImageView.ScaleType.FIT_XY);
    header.setContentDescription("상단 금색 닻: 상하좌우 이동, 짧게 터치하면 숨김");
    panel.addView(header,new LinearLayout.LayoutParams(panelWidth,headerHeight));

    scroller=new ScrollView(this);scroller.setFillViewport(false);
    scroller.setVerticalScrollBarEnabled(true);scroller.setScrollbarFadingEnabled(false);
    scroller.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
    panelContent=new FrameLayout(this);
    panelContent.setBackgroundColor(0xff07172e);
    ImageView background=new ImageView(this);background.setScaleType(ImageView.ScaleType.FIT_XY);
    Bitmap bg=asset("menu_background.jpg");
    if(bg!=null){Bitmap body=Bitmap.createBitmap(bg,0,Math.round(bg.getWidth()*140f/434f),bg.getWidth(),bg.getHeight()-Math.round(bg.getWidth()*140f/434f));bg.recycle();background.setImageBitmap(body);}
    panelContent.addView(background,new FrameLayout.LayoutParams(panelWidth,Math.round(1510*scale)));

    // The captain requested Distribution at the absolute top-left of the scrollable tile area.
    tile("distribution","항행의자유\n배포용",116,204,"ico_distribution.png",this::openDistribution);
    tile("tv","실시간 TV",315,204,"ico_tv.png",()->broadcast("TV"));
    tile("fm","FM 라디오",116,407,"ico_fm.png",()->broadcast("FM"));
    tile("am","AM 라디오",315,407,"ico_am.png",()->broadcast("AM"));
    tile("player","MP4 플레이어",116,610,"ico_player.png",()->player("MP4"));
    tile("mp3","내 파일 MP3",315,610,"ico_mp3.png",()->library("MP3"));
    tile("mp4","내 파일 MP4",116,813,"ico_mp4.png",()->library("MP4"));
    tile("kakao","카카오톡",315,813,"ico_kakao.png",this::kakao);
    tile("v7","항행의자유 V7",116,1016,"ico_v7.png",()->chooseApp("V7","항행의자유 V7 선택"));
    tile("youtube","유튜브",315,1016,"ico_youtube.png",()->openWebsite("https://www.youtube.com/"));
    tile("settings","설정",116,1219,"ico_settings.png",()->newActivity(new Intent(this,MainActivity.class)));
    tile("hide","숨김",315,1219,"ico_hide.png",this::closePanel);
    tile("update","업데이트",116,1422,"ico_update.png",this::openUpdates);
    tile("stop","전체 중지",315,1422,"ico_stop.png",this::stopSelf);

    scroller.addView(panelContent,new ScrollView.LayoutParams(panelWidth,bodyHeight));
    panel.addView(scroller,new LinearLayout.LayoutParams(panelWidth,0,1));
    menu.addView(panel,new FrameLayout.LayoutParams(-1,-1));

    int minimum=Math.min(contentHeight,Math.max(headerHeight+dp(76),dp(123)));
    int maxTop=Math.max(dp(8),screenH-minimum-dp(30));
    int y=cap(prefs.getInt("panelY",dp(24)),dp(8),maxTop);
    int h=Math.min(contentHeight,Math.max(minimum,screenH-y-dp(30)));
    panelParams=params(panelWidth,h);
    panelParams.x=cap(prefs.getInt("panelX",(screenW-panelWidth)/2),0,Math.max(0,screenW-panelWidth));
    panelParams.y=y;
    // Only the GOLD ANCHOR moves the entire panel. Individual icons: long-press then drag.
    header.setOnTouchListener(new View.OnTouchListener(){
      float startRawX,startRawY;int startX,startY;boolean moved;
      @Override public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:
          startRawX=e.getRawX();startRawY=e.getRawY();startX=panelParams.x;startY=panelParams.y;moved=false;return true;
        case MotionEvent.ACTION_MOVE:
          int dx=Math.round(e.getRawX()-startRawX),dy=Math.round(e.getRawY()-startRawY);
          if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5))moved=true;
          if(moved){panelParams.x=startX+dx;panelParams.y=startY+dy;resizePanel();}return true;
        case MotionEvent.ACTION_UP:
          if(moved)prefs.edit().putInt("panelX",panelParams.x).putInt("panelY",panelParams.y).apply();
          else {closePanel();toast("숨김 완료 · 앱 아이콘 또는 알림에서 메뉴를 다시 여세요");}
          return true;
        case MotionEvent.ACTION_CANCEL:return true;
        default:return true;
      }}
    });
    try{wm.addView(menu,panelParams);expanded=true;}
    catch(Exception ex){menu=null;panelContent=null;panelParams=null;toast("메뉴 표시 오류: 다른 앱 위에 표시 권한 확인");}
  }
  private void tile(String id,String title,int x,int y,String picture,Runnable click){
    final float s=panelWidth/434f;
    final int tileW=Math.round(182*s), tileH=Math.round(191*s), iconSize=Math.round(139*s);
    LinearLayout container=new LinearLayout(this);container.setGravity(Gravity.CENTER_HORIZONTAL);
    container.setOrientation(LinearLayout.VERTICAL);container.setPadding(0,0,0,0);
    ImageView icon=new ImageView(this);icon.setImageBitmap(asset(picture));icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
    container.addView(icon,new LinearLayout.LayoutParams(iconSize,iconSize));
    TextView label=new TextView(this);label.setText(title);label.setTextColor(0xffffffff);
    label.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,Math.max(9,Math.min(12,12*s*3f)));
    label.setGravity(Gravity.CENTER);label.setTypeface(null,android.graphics.Typeface.BOLD);
    label.setMaxLines(2);container.addView(label,new LinearLayout.LayoutParams(tileW,tileH-iconSize));
    int initLeft=Math.round((x-91)*s),initTop=Math.round((y-70-140)*s);
    // Existing drag positions are saved relative to the approved 434x1158 panel graphic.
    int left=Math.round(prefs.getInt("tile_"+id+"_x",x-91)*s);
    int top=Math.round((prefs.getInt("tile_"+id+"_y",y-70)-140)*s);
    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(tileW,tileH);
    lp.leftMargin=cap(left,0,Math.max(0,panelWidth-tileW));
    lp.topMargin=cap(top,0,Math.max(0,Math.round(1510*s)-tileH));
    panelContent.addView(container,lp);
    container.setContentDescription(title+" · 길게 눌러 개별 위치 이동, 짧게 눌러 실행");
    container.setOnTouchListener(new View.OnTouchListener(){
      private float downX,downY;private int left0,top0;private boolean drag,scrolled;
      private final Runnable arm=()->{drag=true;container.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);};
      @Override public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:
          downX=e.getRawX();downY=e.getRawY();
          FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)container.getLayoutParams();
          left0=p.leftMargin;top0=p.topMargin;drag=false;scrolled=false;
          container.getParent().requestDisallowInterceptTouchEvent(true);
          handler.postDelayed(arm,430);return true;
        case MotionEvent.ACTION_MOVE:
          int dx=Math.round(e.getRawX()-downX),dy=Math.round(e.getRawY()-downY);
          if(drag){
            FrameLayout.LayoutParams at=(FrameLayout.LayoutParams)container.getLayoutParams();
            at.leftMargin=cap(left0+dx,0,Math.max(0,panelWidth-tileW));
            at.topMargin=cap(top0+dy,0,Math.max(0,Math.round(1510*s)-tileH));
            container.setLayoutParams(at);
            return true;
          }
          if(Math.abs(dx)>dp(10)||Math.abs(dy)>dp(10)){
            scrolled=true;handler.removeCallbacks(arm);
            container.getParent().requestDisallowInterceptTouchEvent(false);
          }
          return true;
        case MotionEvent.ACTION_UP:
          handler.removeCallbacks(arm);
          if(drag){
            FrameLayout.LayoutParams end=(FrameLayout.LayoutParams)container.getLayoutParams();
            prefs.edit().putInt("tile_"+id+"_x",Math.round(end.leftMargin/s))
              .putInt("tile_"+id+"_y",Math.round(end.topMargin/s)+140).apply();
          }else if(!scrolled)click.run();return true;
        case MotionEvent.ACTION_CANCEL:handler.removeCallbacks(arm);return true;
        default:return true;
      }}
    });
  }
  private void newActivity(Intent i){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);closePanel();}
  private void library(String kind){newActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind));}
  private void player(String kind){
    if("MP4".equals(kind)){
      if(VideoOpener.openFirst(this)){closePanel();return;}
      newActivity(new Intent(this,LibraryActivity.class).putExtra("kind","MP4"));return;
    }
    newActivity(new Intent(this,PlayerActivity.class).putExtra("kind",kind));
  }
  private void broadcast(String kind){
    newActivity(new Intent(this,BroadcastActivity.class).putExtra("kind",kind));
  }
  private void openWebsite(String url){
    Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
    try{newActivity(i);}catch(Exception ex){toast("연결할 수 없습니다. 인터넷과 브라우저를 확인해 주세요.");}
  }
  private void openDistribution(){
    // Legacy MoveIcon V1.0.84 official distribution shortcut, preserved unchanged.
    openWebsite("https://hjj28155-dotcom.github.io/BaekhakDosaEmergency/");
  }
  private void kakao(){Intent i=getPackageManager().getLaunchIntentForPackage("com.kakao.talk");if(i!=null)newActivity(i);else toast("카카오톡을 설치해 주세요");}
  private void openUpdates(){
    Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://hjj28155-dotcom.github.io/BaekhakDosaEmergency/moveicon.html"));
    try{newActivity(i);}catch(Exception ex){toast("업데이트 페이지를 열 수 없습니다");}
  }
  private void chooseApp(String key,String title){
    String p=prefs.getString("app_"+key,"");
    Intent launch=p.isEmpty()?null:getPackageManager().getLaunchIntentForPackage(p);
    if(launch!=null)newActivity(launch);
    else newActivity(new Intent(this,ChooserActivity.class).putExtra("key",key).putExtra("heading",title));
  }
  @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);readScreenSize();resizePanel();}
  @Override public void onDestroy(){closePanel();handler.removeCallbacksAndMessages(null);super.onDestroy();}
  @Override public IBinder onBind(Intent intent){return null;}
}
