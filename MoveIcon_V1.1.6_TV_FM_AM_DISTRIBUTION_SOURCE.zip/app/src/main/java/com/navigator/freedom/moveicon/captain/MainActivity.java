package com.navigator.freedom.moveicon.captain;
import android.Manifest;import android.app.Activity;import android.content.Intent;import android.net.Uri;
import android.os.Build;import android.os.Bundle;import android.provider.Settings;import android.widget.LinearLayout;import android.widget.TextView;
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b);render();}
  private void render(){
    LinearLayout l=Ui.column(this);setContentView(l);
    l.addView(Ui.title(this,"⚓ 항행의자유 이동아이콘 · 별도 새 앱"));
    TextView hint=new TextView(this);hint.setText("기존 V1.0.97-NEW 앱과 자료는 그대로 유지됩니다. 새 앱은 새 보관함을 사용하며 MP3·MP4를 '내 파일'에서 직접 선택하여 등록합니다.");hint.setTextColor(Ui.WHITE);hint.setTextSize(15);hint.setPadding(8,8,8,22);l.addView(hint);
    Ui.addButton(l,"⚓ 플로팅 이동아이콘 켜기",v->startOverlay());
    Ui.addButton(l,"🎵 MP3 내 파일 / 보관함",v->library("MP3"));
    Ui.addButton(l,"🎬 MP4 내 파일 / 보관함",v->library("MP4"));
    Ui.addButton(l,"▶ MP4 플레이어",v->{if(!VideoOpener.openFirst(this))library("MP4");});
    Ui.addButton(l,"🌊 항행의자유 배포용",v->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://hjj28155-dotcom.github.io/BaekhakDosaEmergency/"))));
    Ui.addButton(l,"📺 실시간 TV 방송국",v->startActivity(new Intent(this,BroadcastActivity.class).putExtra("kind","TV")));
    Ui.addButton(l,"📻 FM 라디오",v->startActivity(new Intent(this,BroadcastActivity.class).putExtra("kind","FM")));
    Ui.addButton(l,"📡 AM 라디오",v->startActivity(new Intent(this,BroadcastActivity.class).putExtra("kind","AM")));
  }
  private void library(String kind){startActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind));}
  private void startOverlay(){
    if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){
      startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
      android.widget.Toast.makeText(this,"다른 앱 위에 표시 허용 후 돌아와 다시 눌러주세요",1).show();return;
    }
    if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},32);
    Intent service=new Intent(this,AnchorService.class);
    if(Build.VERSION.SDK_INT>=26)startForegroundService(service);else startService(service);
    moveTaskToBack(true);
  }
}
