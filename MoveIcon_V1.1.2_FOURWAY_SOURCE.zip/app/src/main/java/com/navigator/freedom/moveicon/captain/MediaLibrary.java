package com.navigator.freedom.moveicon.captain;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
public final class MediaLibrary {
  static final class Item {final String uri,title,kind;Item(String u,String t,String k){uri=u;title=t;kind=k;}}
  static String name(Context c,Uri u){
    try(Cursor cursor=c.getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
      if(cursor!=null && cursor.moveToFirst())return cursor.getString(0);
    }catch(Exception ignored){}return u.getLastPathSegment()==null?"파일":u.getLastPathSegment();
  }
  static String shortName(String n){
    // Leave original filename intact in storage. Display only removes typical download UUID suffixes.
    String s=n.replaceAll("(?i)(?:__[a-f0-9]{8,}[-_a-f0-9]*)(?=\\.(mp3|mp4)$)", "");
    return s.length()>90?s.substring(0,87)+"…":s;
  }
  static List<Item> list(Context c,String kind){ArrayList<Item> out=new ArrayList<>();
    try{JSONArray a=new JSONArray(c.getSharedPreferences("media",0).getString(kind,"[]"));
      for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);out.add(new Item(x.getString("uri"),x.getString("name"),kind));}
    }catch(Exception ignored){}return out;
  }
  static int add(Context c,Intent data,String kind){
    if(data==null)return 0;
    List<Item> all=list(c,kind);int count=0;
    ArrayList<Uri> chosen=new ArrayList<>();
    if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)chosen.add(data.getClipData().getItemAt(i).getUri());}
    else if(data.getData()!=null)chosen.add(data.getData());
    for(Uri uri:chosen){try{
      // ACTION_OPEN_DOCUMENT grants a persisted read permission when possible.
      int flags=data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
      if(flags!=0)c.getContentResolver().takePersistableUriPermission(uri,flags);
      boolean exists=false;for(Item entry:all)if(entry.uri.equals(uri.toString())){exists=true;break;}
      if(!exists){all.add(new Item(uri.toString(),name(c,uri),kind));count++;}
    }catch(Exception ex){/* When persistable permission is unsupported, still register current access. */
      boolean exists=false;for(Item entry:all)if(entry.uri.equals(uri.toString())){exists=true;break;}
      if(!exists){all.add(new Item(uri.toString(),name(c,uri),kind));count++;}
    }}
    save(c,kind,all);return count;
  }
  static void save(Context c,String kind,List<Item> list){JSONArray a=new JSONArray();for(Item it:list){JSONObject x=new JSONObject();try{x.put("uri",it.uri);x.put("name",it.title);}catch(Exception ignored){}a.put(x);}
    c.getSharedPreferences("media",0).edit().putString(kind,a.toString()).apply();
  }
}
