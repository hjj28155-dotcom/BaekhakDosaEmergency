package com.navigator.freedom.moveicon.captain;
import android.app.*;import android.content.*;import android.graphics.PixelFormat;import android.os.*;import android.provider.Settings;
import android.view.*;import android.widget.*;
import android.graphics.Bitmap;import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.content.res.Configuration;
import android.net.Uri;import java.util.*;
public class AnchorService extends Service {
  private static final int ID=1701;private WindowManager wm;private ImageView anchor;private FrameLayout menu, panelContent;private ScrollView scroller;private WindowManager.LayoutParams anchorParams,panelParams;
  private int screenW,screenH,contentHeight,headerHeight;private boolean expanded=false;private android.content.SharedPreferences prefs;
  private int dp(float n){return Ui.dp(this,n);}
  @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);prefs=getSharedPreferences("anchor",0);android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);screenW=m.widthPixels;screenH=m.heightPixels;
    startPersistent();createAnchor();}
  private int overlayType(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}
  private WindowManager.LayoutParams params(int w,int h){WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,overlayType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;return p;}
  private void startPersistent(){String channel="anchor_20261021";
    if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(channel,"이동아이콘 동작",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);}
    Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification n=new Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("항행의자유 이동아이콘").setContentText("닻 아이콘을 눌러 메뉴 열기").setContentIntent(pi).setOngoing(true).build();
    if(Build.VERSION.SDK_INT>=34)startForeground(ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(ID,n);
  }
  private void createAnchor(){anchor=new ImageView(this);anchor.setImageResource(R.drawable.overlay_anchor_icon);anchor.setContentDescription("닻 이동아이콘 · 누르면 메뉴 열기, 드래그로 이동");anchor.setScaleType(ImageView.ScaleType.FIT_CENTER);
    anchorParams=params(dp(53),dp(53));anchorParams.x=prefs.getInt("x",screenW-dp(80));anchorParams.y=prefs.getInt("y",screenH-dp(185));wm.addView(anchor,anchorParams);
    anchor.setOnTouchListener(new View.OnTouchListener(){float downRawX,downRawY;int origX,origY;boolean moved=false;
      @Override public boolean onTouch(View view,android.view.MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:downRawX=e.getRawX();downRawY=e.getRawY();origX=anchorParams.x;origY=anchorParams.y;moved=false;return true;
        case MotionEvent.ACTION_MOVE:int dx=(int)(e.getRawX()-downRawX),dy=(int)(e.getRawY()-downRawY);
          if(Math.abs(dx)>dp(6)||Math.abs(dy)>dp(6))moved=true;
          if(moved){anchorParams.x=Math.max(0,Math.min(screenW-dp(53),origX+dx));anchorParams.y=Math.max(0,Math.min(screenH-dp(80),origY+dy));wm.updateViewLayout(anchor,anchorParams);if(menu!=null&&panelParams!=null){resizePanel();}}return true;
        case MotionEvent.ACTION_UP:if(moved){prefs.edit().putInt("x",anchorParams.x).putInt("y",anchorParams.y).apply();}else toggle();return true;
      }return false;}
    });
  }
  private int cap(int v,int min,int max){return Math.max(min,Math.min(v,Math.max(min,max)));}
  private void readScreenSize(){android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);screenW=m.widthPixels;screenH=m.heightPixels;}
  // Keep an accessible drag header even after the menu body has been scrolled to the bottom.
  // As the panel moves down, shorten only its scrollable viewport; never hide the header.
  private void resizePanel(){
    if(menu==null||panelParams==null)return;
    int minimumHeight=Math.min(contentHeight,Math.max(headerHeight+dp(68),dp(118)));
    int maxTop=Math.max(dp(8),screenH-minimumHeight-dp(30));
    panelParams.y=cap(panelParams.y,dp(8),maxTop);
    panelParams.x=cap(panelParams.x,0,Math.max(0,screenW-panelParams.width));
    panelParams.height=Math.min(contentHeight,Math.max(minimumHeight,screenH-panelParams.y-dp(30)));
    try{wm.updateViewLayout(menu,panelParams);}catch(Exception ignored){}
  }
  private void toggle(){if(expanded)closePanel();else openPanel();}
  private void closePanel(){if(menu!=null){try{wm.removeView(menu);}catch(Exception ignored){}menu=null;panelContent=null;scroller=null;panelParams=null;}expanded=false;}
  private void openPanel(){if(menu!=null)return;
    readScreenSize();
    // Preserve the existing approved 2-column artwork and the slim 142dp panel width.
    int width=Math.min(dp(142),Math.max(dp(110),screenW-dp(36)));
    contentHeight=Math.round(width*(1158f/434f));
    final int cropY=140; // Bottom of existing golden anchor header in approved 434x1158 image.
    headerHeight=Math.round(width*(cropY/434f));
    int bodyHeight=contentHeight-headerHeight;
    menu=new FrameLayout(this);
    LinearLayout columns=new LinearLayout(this);columns.setOrientation(LinearLayout.VERTICAL);
    Bitmap full;
    try(java.io.InputStream input=getAssets().open("approved_panel.jpg")){
      full=BitmapFactory.decodeStream(input);
      if(full==null)throw new IllegalStateException("approved_panel.jpg");
    }catch(Exception ex){menu=null;toast("메뉴 배경 불러오기 오류");return;}
    final int cut=Math.round(full.getHeight()*(cropY/1158f));
    Bitmap headerArt=Bitmap.createBitmap(full,0,0,full.getWidth(),cut);
    Bitmap bodyArt=Bitmap.createBitmap(full,0,cut,full.getWidth(),full.getHeight()-cut);
    full.recycle();
    // Pinned header: crop from APPROVED artwork (not a new icon or new menu).
    ImageView header=new ImageView(this);
    header.setImageBitmap(headerArt);header.setScaleType(ImageView.ScaleType.FIT_XY);
    header.setContentDescription("금색 닻 부분을 잡아 상하좌우 이동 · 짧게 누르면 닫기");
    columns.addView(header,new LinearLayout.LayoutParams(width,headerHeight));
    scroller=new ScrollView(this);
    scroller.setFillViewport(false);scroller.setVerticalScrollBarEnabled(true);
    scroller.setScrollbarFadingEnabled(false);
    scroller.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
    panelContent=new FrameLayout(this);
    ImageView art=new ImageView(this);
    art.setImageBitmap(bodyArt);art.setScaleType(ImageView.ScaleType.FIT_XY);
    panelContent.addView(art,new FrameLayout.LayoutParams(width,bodyHeight));
    // The hitboxes use the SAME original positions, offset by the cropped, fixed header.
    hotspot(width,contentHeight,cropY,115,203,125,122,"TV 실시간",()->chooseApp("TV","실시간 TV 앱 선택"));
    hotspot(width,contentHeight,cropY,316,203,125,122,"MP4 플레이어",()->startPlayer("MP4"));
    hotspot(width,contentHeight,cropY,116,405,125,124,"MP3 내 파일",()->library("MP3"));
    hotspot(width,contentHeight,cropY,315,405,125,124,"MP4 내 파일",()->library("MP4"));
    hotspot(width,contentHeight,cropY,115,629,125,123,"카카오톡",this::kakao);
    hotspot(width,contentHeight,cropY,317,629,125,123,"항행의자유 V7",()->chooseApp("V7","항행의자유 V7 앱 선택"));
    hotspot(width,contentHeight,cropY,114,831,124,122,"설정",this::settingsDialog);
    hotspot(width,contentHeight,cropY,318,831,125,122,"숨김",this::closePanel);
    hotspot(width,contentHeight,cropY,217,1030,124,130,"전체 중지",this::stopSelf);
    scroller.addView(panelContent,new ScrollView.LayoutParams(width,bodyHeight));
    columns.addView(scroller,new LinearLayout.LayoutParams(width,0,1));
    menu.addView(columns,new FrameLayout.LayoutParams(-1,-1));
    int top=cap(prefs.getInt("panelY",dp(24)),dp(8),Math.max(dp(8),screenH-dp(160)));
    int minHeight=Math.min(contentHeight,Math.max(headerHeight+dp(68),dp(118)));
    int maxTop=Math.max(dp(8),screenH-minHeight-dp(30));
    top=cap(top,dp(8),maxTop);
    int viewport=Math.min(contentHeight,Math.max(minHeight,screenH-top-dp(30)));
    panelParams=params(width,viewport);
    int centerX=Math.max(0,(screenW-width)/2);
    panelParams.x=cap(prefs.getInt("panelX",centerX),0,Math.max(0,screenW-width));
    panelParams.y=top;
    // Finger movement on the pinned header drives the entire overlay in BOTH axes.
    // Scroll gestures on the body do not move the overlay.
    header.setOnTouchListener(new View.OnTouchListener(){
      float startRawX,startRawY;int startX,startY;boolean moving;
      @Override public boolean onTouch(View v,MotionEvent e){
        switch(e.getActionMasked()){
          case MotionEvent.ACTION_DOWN:
            startRawX=e.getRawX();startRawY=e.getRawY();
            startX=panelParams.x;startY=panelParams.y;moving=false;return true;
          case MotionEvent.ACTION_MOVE:
            int dx=Math.round(e.getRawX()-startRawX);
            int dy=Math.round(e.getRawY()-startRawY);
            if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5))moving=true;
            if(moving){panelParams.x=startX+dx;panelParams.y=startY+dy;resizePanel();}
            return true;
          case MotionEvent.ACTION_UP:
            if(moving){prefs.edit().putInt("panelX",panelParams.x).putInt("panelY",panelParams.y).apply();}
            else closePanel();return true;
          case MotionEvent.ACTION_CANCEL:
            if(moving){prefs.edit().putInt("panelX",panelParams.x).putInt("panelY",panelParams.y).apply();}
            return true;
          default:return true;
        }
      }
    });
    try{wm.addView(menu,panelParams);expanded=true;}
    catch(Exception ex){menu=null;panelContent=null;scroller=null;panelParams=null;expanded=false;toast("메뉴 표시 오류");}
  }
  private void hotspot(int w,int fullH,int cropY,float x,float y,float hitW,float hitH,String desc,Runnable run){
    TextView touch=new TextView(this);touch.setContentDescription(desc);touch.setClickable(true);
    touch.setOnClickListener(v->run.run());
    int tw=Math.round(w*hitW/434f),th=Math.round(fullH*hitH/1158f);
    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(tw,th);
    lp.leftMargin=Math.round(w*(x-hitW/2)/434f);
    lp.topMargin=Math.round(fullH*(y-hitH/2-cropY)/1158f);
    panelContent.addView(touch,lp);
  }
  @Override public void onConfigurationChanged(Configuration newConfig){
    super.onConfigurationChanged(newConfig);
    if(wm==null)return;
    readScreenSize();
    if(anchor!=null&&anchorParams!=null){
      anchorParams.x=cap(anchorParams.x,0,Math.max(0,screenW-dp(53)));
      anchorParams.y=cap(anchorParams.y,0,Math.max(0,screenH-dp(80)));
      try{wm.updateViewLayout(anchor,anchorParams);}catch(Exception ignored){}
    }
    resizePanel();
  }
  private void newActivity(Intent i){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);closePanel();}
  private void library(String kind){newActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind));}
  private void startPlayer(String kind){newActivity(new Intent(this,PlayerActivity.class).putExtra("kind",kind));}
  private void kakao(){Intent i=getPackageManager().getLaunchIntentForPackage("com.kakao.talk");if(i!=null)newActivity(i);else toast("카카오톡을 설치해 주세요");}
  private void toast(String t){Toast.makeText(this,t,Toast.LENGTH_LONG).show();}
  private void settingsDialog(){Intent i=new Intent(this,MainActivity.class);newActivity(i);}
  private void chooseApp(String key,String title){
    String saved=prefs.getString("app_"+key,"");Intent known=saved.isEmpty()?null:getPackageManager().getLaunchIntentForPackage(saved);
    if(known!=null){newActivity(known);return;}
    android.content.pm.PackageManager pm=getPackageManager();Intent filter=new Intent(Intent.ACTION_MAIN);filter.addCategory(Intent.CATEGORY_LAUNCHER);
    java.util.List<android.content.pm.ResolveInfo> apps=pm.queryIntentActivities(filter,0);
    apps.sort((a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
    CharSequence[] labels=new CharSequence[apps.size()];for(int j=0;j<apps.size();j++)labels[j]=apps.get(j).loadLabel(pm);
    Intent act=new Intent(this,ChooserActivity.class); // Safe app picker in an activity, since overlay cannot show Activity dialog directly.
    act.putExtra("key",key).putExtra("heading",title);newActivity(act);
  }
  @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
  @Override public void onDestroy(){closePanel();if(anchor!=null){try{wm.removeView(anchor);}catch(Exception ignored){}anchor=null;}super.onDestroy();}
  @Override public android.os.IBinder onBind(Intent i){return null;}
}
