package com.navigator.freedom.moveicon.captain;
import android.app.Activity;import android.content.Intent;import android.content.pm.PackageManager;import android.content.pm.ResolveInfo;import android.os.Bundle;
import android.widget.LinearLayout;import android.widget.ScrollView;import java.util.List;
public class ChooserActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b);String key=getIntent().getStringExtra("key");if(key==null)key="TV";final String pref=key;
    PackageManager pm=getPackageManager();Intent filter=new Intent(Intent.ACTION_MAIN);filter.addCategory(Intent.CATEGORY_LAUNCHER);
    List<ResolveInfo> list=pm.queryIntentActivities(filter,0);list.sort((a,c)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(c.loadLabel(pm))));
    LinearLayout base=Ui.column(this);setContentView(base);base.addView(Ui.title(this,getIntent().getStringExtra("heading")));
    ScrollView sv=new ScrollView(this);LinearLayout contents=new LinearLayout(this);contents.setOrientation(1);sv.addView(contents);base.addView(sv);
    for(ResolveInfo item:list){String label=String.valueOf(item.loadLabel(pm));Ui.addButton(contents,label,v->{String pkg=item.activityInfo.packageName;
      getSharedPreferences("anchor",0).edit().putString("app_"+pref,pkg).apply();Intent open=pm.getLaunchIntentForPackage(pkg);if(open!=null)startActivity(open);finish();});}
  }
}
