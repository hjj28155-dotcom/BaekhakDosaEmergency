package com.navigator.freedom.moveicon.captain;
import android.Manifest;import android.app.Activity;import android.content.Intent;import android.net.Uri;
import android.os.Build;import android.os.Bundle;import android.provider.Settings;import android.widget.LinearLayout;import android.widget.TextView;
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b);render();}
  private void render(){
    LinearLayout l=Ui.column(this);setContentView(l);
    l.addView(Ui.title(this,"⚓ 항행의자유 이동아이콘 · 별도 새 앱"));
    TextView hint=new TextView(this);hint.setText("기존 V1.0.97-NEW 앱과 자료는 그대로 유지됩니다. 새 앱은 새 보관함을 사용하며 MP3·MP4를 '내 파일'에서 직접 선택하여 등록합니다.");hint.setTextColor(Ui.WHITE);hint.setTextSize(15);hint.setPadding(8,8,8,22);l.addView(hint);
    Ui.addButton(l,"⚓ 플로팅 이동아이콘 켜기",v->startOverlay());
    Ui.addButton(l,"🎵 MP3 내 파일 / 보관함",v->library("MP3"));
    Ui.addButton(l,"🎬 MP4 내 파일 / 보관함",v->library("MP4"));
    Ui.addButton(l,"▶ MP4 플레이어",v->startActivity(new Intent(this,PlayerActivity.class).putExtra("kind","MP4")));
    Ui.addButton(l,"⚙ TV·V7 실행 앱 설정",v->new android.app.AlertDialog.Builder(this).setMessage("메뉴에서 TV·V7을 처음 실행할 때 사용할 앱을 선택할 수 있습니다.").setPositiveButton("확인",null).show());
  }
  private void library(String kind){startActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind));}
  private void startOverlay(){
    if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){
      startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
      android.widget.Toast.makeText(this,"다른 앱 위에 표시 허용 후 돌아와 다시 눌러주세요",1).show();return;
    }
    if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},32);
    Intent service=new Intent(this,AnchorService.class);
    if(Build.VERSION.SDK_INT>=26)startForegroundService(service);else startService(service);
    moveTaskToBack(true);
  }
}
