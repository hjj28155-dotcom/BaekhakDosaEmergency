package com.navigator.freedom.moveicon.captain;
import android.app.Activity;import android.app.PictureInPictureParams;import android.content.Intent;import android.os.Build;import android.os.Bundle;import android.util.Rational;
import android.view.Gravity;import android.view.View;import android.widget.LinearLayout;import android.widget.TextView;import android.widget.Toast;
import androidx.media3.common.MediaItem;import androidx.media3.common.Player;import androidx.media3.exoplayer.ExoPlayer;import androidx.media3.ui.PlayerView;
import android.net.Uri;import java.util.List;
public class PlayerActivity extends Activity {
  private ExoPlayer player;private PlayerView playerView;String kind;TextView title;
  @Override public void onCreate(Bundle b){super.onCreate(b);kind=getIntent().getStringExtra("kind");if(!"MP3".equals(kind))kind="MP4";
    LinearLayout l=Ui.column(this);setContentView(l);
    title=Ui.title(this,"🎬 "+kind+" 플레이어");l.addView(title);
    playerView=new PlayerView(this);playerView.setUseController(true);playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);playerView.setKeepScreenOn(true);
    l.addView(playerView,new LinearLayout.LayoutParams(-1,0,1));
    Ui.addButton(l,"⛶ 작은 화면(PiP)",v->{if(Build.VERSION.SDK_INT>=26){try{enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(16,9)).build());}catch(Exception e){Toast.makeText(this,"이 기기에서는 작은 화면 사용 불가",1).show();}}});
    Ui.addButton(l,"📁 보관함 / 내 파일",v->startActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind)));
    player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);player.setRepeatMode(Player.REPEAT_MODE_ALL);
    List<MediaLibrary.Item> list=MediaLibrary.list(this,kind);for(MediaLibrary.Item it:list)player.addMediaItem(MediaItem.fromUri(Uri.parse(it.uri)));
    if(!list.isEmpty()){int index=Math.max(0,Math.min(getIntent().getIntExtra("index",0),list.size()-1));player.seekTo(index,0);player.prepare();player.play();title.setText(MediaLibrary.shortName(list.get(index).title));}
    else{title.setText(kind+" 파일이 없습니다. 보관함에서 추가해 주세요.");}
    player.addListener(new Player.Listener(){@Override public void onMediaItemTransition(MediaItem mediaItem,int reason){int n=player.getCurrentMediaItemIndex();if(n>=0 && n<list.size())title.setText(MediaLibrary.shortName(list.get(n).title));}});
  }
  @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);}
  @Override public void onPictureInPictureModeChanged(boolean pip,android.content.res.Configuration config){super.onPictureInPictureModeChanged(pip,config);title.setVisibility(pip?View.GONE:View.VISIBLE);}
  @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
