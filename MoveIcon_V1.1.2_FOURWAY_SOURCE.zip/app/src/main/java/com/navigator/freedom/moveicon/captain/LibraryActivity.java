package com.navigator.freedom.moveicon.captain;
import android.app.Activity;import android.content.Intent;import android.net.Uri;import android.os.Bundle;import android.view.Gravity;
import android.widget.CheckBox;import android.widget.LinearLayout;import android.widget.ScrollView;import android.widget.TextView;import android.widget.Toast;
import java.util.ArrayList;import java.util.List;
public class LibraryActivity extends Activity {
  static final int REQUEST_PICK=301;String kind;LinearLayout root,rows;ArrayList<CheckBox> checks=new ArrayList<>();
  @Override public void onCreate(Bundle b){super.onCreate(b);kind=getIntent().getStringExtra("kind");if(!"MP3".equals(kind))kind="MP4";show();}
  private void show(){root=Ui.column(this);setContentView(root);root.addView(Ui.title(this,kind+" 보관함 · 여러 파일 선택"));
    Ui.addButton(root,"📁 내 파일에서 "+kind+" 추가",v->pick());
    Ui.addButton(root,"▶ 선택한 항목부터 재생",v->playSelected());
    Ui.addButton(root,"▶ 전체 연속 재생",v->play(0));
    TextView hint=new TextView(this);hint.setText("원본을 삭제·이동하지 않습니다. 파일 접근 권한을 보관하여 재생 목록에 등록합니다. 원본 파일을 삭제하거나 옮기면 재생할 수 없습니다.");hint.setTextColor(0xffcad9e7);hint.setTextSize(13);root.addView(hint);
    ScrollView scroll=new ScrollView(this);rows=new LinearLayout(this);rows.setOrientation(1);scroll.addView(rows);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));renderList();
  }
  private void renderList(){checks.clear();rows.removeAllViews();List<MediaLibrary.Item> items=MediaLibrary.list(this,kind);
    TextView label=Ui.title(this,kind+" · "+items.size()+"개");rows.addView(label);
    for(int i=0;i<items.size();i++){final int idx=i;MediaLibrary.Item it=items.get(i);
      LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
      CheckBox c=new CheckBox(this);c.setText(""+(i+1));c.setTextColor(Ui.GOLD);checks.add(c);line.addView(c);
      TextView name=new TextView(this);name.setText(MediaLibrary.shortName(it.title));name.setTextColor(Ui.WHITE);name.setTextSize(15);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setPadding(8,9,8,9);
      line.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(this,64),1));name.setOnClickListener(v->play(idx));
      rows.addView(line);}
  }
  private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("MP3".equals(kind)?"audio/*":"video/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,REQUEST_PICK);}
  @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==REQUEST_PICK&&c==RESULT_OK){int n=MediaLibrary.add(this,d,kind);Toast.makeText(this,n+"개 등록 완료",Toast.LENGTH_LONG).show();renderList();}}
  private void playSelected(){int first=0;for(int i=0;i<checks.size();i++)if(checks.get(i).isChecked()){first=i;break;}play(first);}
  private void play(int first){List<MediaLibrary.Item> list=MediaLibrary.list(this,kind);if(list.size()==0){Toast.makeText(this,"먼저 내 파일에서 등록해 주세요",Toast.LENGTH_SHORT).show();return;}
    startActivity(new Intent(this,PlayerActivity.class).putExtra("kind",kind).putExtra("index",Math.min(first,list.size()-1)));}
}
