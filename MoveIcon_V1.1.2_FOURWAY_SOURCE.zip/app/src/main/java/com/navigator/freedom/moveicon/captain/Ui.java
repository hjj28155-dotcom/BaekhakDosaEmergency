package com.navigator.freedom.moveicon.captain;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
public final class Ui {
  static final int NAVY=0xff06192f, BLUE=0xff0b2b4c, GOLD=0xffeac777, WHITE=0xfff9fbff;
  static int dp(Context c,float n){return (int)(c.getResources().getDisplayMetrics().density*n+0.5f);}
  static GradientDrawable bg(Context c,int fill){GradientDrawable x=new GradientDrawable();x.setColor(fill);x.setCornerRadius(dp(c,14));x.setStroke(dp(c,1),GOLD);return x;}
  static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(1);l.setPadding(dp(c,14),dp(c,14),dp(c,14),dp(c,14));l.setBackgroundColor(NAVY);return l;}
  static Button button(Context c,String name){Button b=new Button(c);b.setAllCaps(false);b.setText(name);b.setTextColor(WHITE);b.setTextSize(15);b.setBackground(bg(c,BLUE));return b;}
  static TextView title(Context c,String name){TextView v=new TextView(c);v.setText(name);v.setTextColor(GOLD);v.setTextSize(21);v.setPadding(dp(c,6),dp(c,6),dp(c,6),dp(c,12));return v;}
  static void addButton(LinearLayout col,String label,View.OnClickListener click){Button b=button(col.getContext(),label);col.addView(b,new LinearLayout.LayoutParams(-1,dp(col.getContext(),52)));b.setOnClickListener(click);}
}
