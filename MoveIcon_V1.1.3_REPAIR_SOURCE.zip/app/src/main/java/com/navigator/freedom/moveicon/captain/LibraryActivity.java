package com.navigator.freedom.moveicon.captain;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public class LibraryActivity extends Activity {
  private static final int PICK_SAMSUNG=301, PICK_ANDROID=302;
  private final ExecutorService executor=Executors.newSingleThreadExecutor();
  private String kind;private LinearLayout root,rows;
  private final ArrayList<CheckBox> checks=new ArrayList<>();
  private TextView feedback;
  private boolean busy;
  @Override public void onCreate(Bundle b){super.onCreate(b);kind=getIntent().getStringExtra("kind");if(!"MP3".equals(kind))kind="MP4";show();}
  private void show(){
    root=Ui.column(this);setContentView(root);
    root.addView(Ui.title(this,kind+" 보관함 · 여러 파일 선택"));
    Ui.addButton(root,"📁 삼성 내 파일에서 "+kind+" 선택",v->pickSamsung());
    Ui.addButton(root,"📂 내부 저장공간 / 다운로드 선택",v->pickAndroid());
    Ui.addButton(root,"▶ 선택한 영상·음악 재생",v->playSelected());
    Ui.addButton(root,"▶ 전체 연속 재생",v->play(0));
    feedback=new TextView(this);feedback.setText("삼성 내 파일을 먼저 열어봅니다. 지원하지 않으면 내부 저장공간 선택창으로 전환합니다. 원본은 그대로 두고 앱 보관함으로 복사합니다. 복사 중에는 기다려 주세요.");
    feedback.setTextColor(0xffcad9e7);feedback.setTextSize(12);root.addView(feedback);
    ScrollView scroll=new ScrollView(this);rows=new LinearLayout(this);rows.setOrientation(1);scroll.addView(rows);
    root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));renderList();
  }
  private void renderList(){
    checks.clear();rows.removeAllViews();List<MediaLibrary.Item> items=MediaLibrary.list(this,kind);
    rows.addView(Ui.title(this,kind+" · "+items.size()+"개"));
    for(int i=0;i<items.size();i++){
      final int index=i;MediaLibrary.Item it=items.get(i);
      LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
      CheckBox c=new CheckBox(this);c.setText(""+(i+1));c.setTextColor(Ui.GOLD);checks.add(c);line.addView(c);
      TextView name=new TextView(this);name.setText(MediaLibrary.shortName(it.title));name.setTextColor(Ui.WHITE);
      name.setTextSize(14);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);name.setPadding(8,9,8,9);
      line.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));
      name.setOnClickListener(v->play(index));rows.addView(line);
    }
  }
  // Samsung uses an undocumented picker action on some Galaxy versions.
  // Launch with result; if it is unavailable/blocked, fall back to a documented Android SAF picker.
  private void pickSamsung(){
    if(busy)return;
    Intent samsung=new Intent("com.sec.android.app.myfiles.PICK_DATA");
    samsung.setPackage("com.sec.android.app.myfiles");
    samsung.addCategory(Intent.CATEGORY_DEFAULT);
    samsung.putExtra("CONTENT_TYPE","MP3".equals(kind)?"audio/*":"video/*");
    samsung.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
    samsung.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    try{startActivityForResult(samsung,PICK_SAMSUNG);}
    catch(ActivityNotFoundException|SecurityException error){
      Toast.makeText(this,"삼성 내 파일 선택을 지원하지 않아 내부 저장공간을 엽니다",Toast.LENGTH_LONG).show();pickAndroid();
    }
  }
  private void pickAndroid(){
    if(busy)return;
    Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.addCategory(Intent.CATEGORY_OPENABLE);
    in.setType("MP3".equals(kind)?"audio/*":"video/*");
    in.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
    in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    // Start in Download instead of the empty Recent files page on supported Android DocumentsUI.
    in.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
      Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"));
    try{startActivityForResult(in,PICK_ANDROID);}catch(Exception e){
      new android.app.AlertDialog.Builder(this).setMessage("파일 선택창을 열지 못했습니다: "+e.getMessage()).setPositiveButton("확인",null).show();
    }
  }
  @Override protected void onActivityResult(int request,int result,Intent data){
    super.onActivityResult(request,result,data);
    if((request!=PICK_SAMSUNG&&request!=PICK_ANDROID)||result!=RESULT_OK)return;
    if(data==null||(data.getData()==null&&data.getClipData()==null)){
      Toast.makeText(this,"선택된 파일이 없습니다. 다른 선택 방식으로 다시 시도해 주세요",Toast.LENGTH_LONG).show();return;
    }
    busy=true;feedback.setText("선택한 "+kind+" 파일을 복사하고 있습니다… (기존 파일 보존)");
    final Intent fileData=data;final String type=kind;
    executor.execute(()->{
      MediaLibrary.CopyResult r=MediaLibrary.addCopies(getApplicationContext(),fileData,type);
      runOnUiThread(()->{
        if(isFinishing()||isDestroyed())return;
        busy=false;String msg=r.count+"개 보관 완료"+(r.failed>0?", "+r.failed+"개 실패: "+r.lastError:"");
        feedback.setText(msg+" · 기존 원본은 변경하지 않았습니다.");
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show();renderList();
      });
    });
  }
  private void playSelected(){
    int idx=0;for(int i=0;i<checks.size();i++)if(checks.get(i).isChecked()){idx=i;break;}play(idx);
  }
  private void play(int idx){
    if(busy){Toast.makeText(this,"복사가 끝날 때까지 기다려 주세요",Toast.LENGTH_SHORT).show();return;}
    List<MediaLibrary.Item> items=MediaLibrary.list(this,kind);
    if(items.isEmpty()){Toast.makeText(this,"내 파일에서 "+kind+"를 먼저 불러와 주세요",Toast.LENGTH_LONG).show();return;}
    startActivity(new Intent(this,PlayerActivity.class).putExtra("kind",kind).putExtra("index",Math.min(idx,items.size()-1)));
  }
  @Override protected void onDestroy(){executor.shutdown();super.onDestroy();}
}
