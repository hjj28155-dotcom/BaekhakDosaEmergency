package com.navigator.freedom.moveicon.captain;
import android.app.*;import android.content.*;import android.graphics.PixelFormat;import android.os.*;import android.provider.Settings;
import android.view.*;import android.widget.*;import android.graphics.drawable.GradientDrawable;import android.net.Uri;import java.util.*;
public class AnchorService extends Service {
  private static final int ID=1701;private WindowManager wm;private ImageView anchor;private FrameLayout menu;private WindowManager.LayoutParams anchorParams,panelParams;
  private int screenW,screenH;private boolean expanded=false;private android.content.SharedPreferences prefs;
  private int dp(float n){return Ui.dp(this,n);}
  @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);prefs=getSharedPreferences("anchor",0);android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);screenW=m.widthPixels;screenH=m.heightPixels;
    startPersistent();createAnchor();}
  private int overlayType(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}
  private WindowManager.LayoutParams params(int w,int h){WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,overlayType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;return p;}
  private void startPersistent(){String channel="anchor_20261021";
    if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(channel,"이동아이콘 동작",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);}
    Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification n=new Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("항행의자유 이동아이콘").setContentText("닻 아이콘을 눌러 메뉴 열기").setContentIntent(pi).setOngoing(true).build();
    if(Build.VERSION.SDK_INT>=34)startForeground(ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(ID,n);
  }
  private void createAnchor(){anchor=new ImageView(this);anchor.setImageResource(R.drawable.overlay_anchor_icon);anchor.setContentDescription("닻 이동아이콘 · 누르면 메뉴 열기, 드래그로 이동");anchor.setScaleType(ImageView.ScaleType.FIT_CENTER);
    anchorParams=params(dp(53),dp(53));anchorParams.x=prefs.getInt("x",screenW-dp(80));anchorParams.y=prefs.getInt("y",screenH-dp(185));wm.addView(anchor,anchorParams);
    anchor.setOnTouchListener(new View.OnTouchListener(){float downRawX,downRawY;int origX,origY;boolean moved=false;
      @Override public boolean onTouch(View view,android.view.MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:downRawX=e.getRawX();downRawY=e.getRawY();origX=anchorParams.x;origY=anchorParams.y;moved=false;return true;
        case MotionEvent.ACTION_MOVE:int dx=(int)(e.getRawX()-downRawX),dy=(int)(e.getRawY()-downRawY);
          if(Math.abs(dx)>dp(6)||Math.abs(dy)>dp(6))moved=true;
          if(moved){anchorParams.x=Math.max(0,Math.min(screenW-dp(53),origX+dx));anchorParams.y=Math.max(0,Math.min(screenH-dp(80),origY+dy));wm.updateViewLayout(anchor,anchorParams);}return true;
        case MotionEvent.ACTION_UP:if(moved){prefs.edit().putInt("x",anchorParams.x).putInt("y",anchorParams.y).apply();}else toggle();return true;
      }return false;}
    });
  }
  private void toggle(){if(expanded)closePanel();else openPanel();}
  private void closePanel(){if(menu!=null){try{wm.removeView(menu);}catch(Exception ignored){}menu=null;}expanded=false;}
  private void openPanel(){if(menu!=null)return;
    // Approved 2026-10-21 portrait panel: original artwork and all icon positions are preserved.
    int width=Math.max(dp(165),Math.min(dp(255),(int)(screenW*0.43f)));int height=(int)(width*(1158f/434f));
    height=Math.min(height,screenH-dp(120));width=(int)(height*(434f/1158f));
    menu=new FrameLayout(this);ImageView art=new ImageView(this);
    try{art.setImageDrawable(android.graphics.drawable.Drawable.createFromStream(getAssets().open("approved_panel.jpg"),null));}catch(Exception ignored){}
    art.setScaleType(ImageView.ScaleType.FIT_XY);menu.addView(art,new FrameLayout.LayoutParams(-1,-1));
    // Pixel coordinates inside 434x1158 image; transparent button hitboxes on the approved image.
    hotspot(width,height,214,66,110,120,"접기",()->closePanel());
    hotspot(width,height,115,203,125,122,"TV 실시간",()->chooseApp("TV","실시간 TV 앱 선택"));
    hotspot(width,height,316,203,125,122,"MP4 플레이어",()->startPlayer("MP4"));
    hotspot(width,height,116,405,125,124,"MP3 내 파일",()->library("MP3"));
    hotspot(width,height,315,405,125,124,"MP4 내 파일",()->library("MP4"));
    hotspot(width,height,115,629,125,123,"카카오톡",this::kakao);
    hotspot(width,height,317,629,125,123,"항행의자유 V7",()->chooseApp("V7","항행의자유 V7 앱 선택"));
    hotspot(width,height,114,831,124,122,"설정",this::settingsDialog);
    hotspot(width,height,318,831,125,122,"숨김",this::closePanel);
    hotspot(width,height,217,1030,124,130,"전체 중지",this::stopSelf);
    panelParams=params(width,height);panelParams.x=Math.max(0,(screenW-width)/2);panelParams.y=Math.max(dp(40),Math.min(screenH-height-dp(32),dp(100)));
    wm.addView(menu,panelParams);expanded=true;
  }
  private void hotspot(int w,int h,float x,float y,float hitW,float hitH,String desc,Runnable run){
    TextView touch=new TextView(this);touch.setContentDescription(desc);touch.setClickable(true);
    touch.setOnClickListener(v->run.run());
    int tw=(int)(w*hitW/434),th=(int)(h*hitH/1158);
    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(tw,th);lp.leftMargin=(int)(w*(x-hitW/2)/434);lp.topMargin=(int)(h*(y-hitH/2)/1158);menu.addView(touch,lp);
  }
  private void newActivity(Intent i){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);closePanel();}
  private void library(String kind){newActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind));}
  private void startPlayer(String kind){newActivity(new Intent(this,PlayerActivity.class).putExtra("kind",kind));}
  private void kakao(){Intent i=getPackageManager().getLaunchIntentForPackage("com.kakao.talk");if(i!=null)newActivity(i);else toast("카카오톡을 설치해 주세요");}
  private void toast(String t){Toast.makeText(this,t,Toast.LENGTH_LONG).show();}
  private void settingsDialog(){Intent i=new Intent(this,MainActivity.class);newActivity(i);}
  private void chooseApp(String key,String title){
    String saved=prefs.getString("app_"+key,"");Intent known=saved.isEmpty()?null:getPackageManager().getLaunchIntentForPackage(saved);
    if(known!=null){newActivity(known);return;}
    android.content.pm.PackageManager pm=getPackageManager();Intent filter=new Intent(Intent.ACTION_MAIN);filter.addCategory(Intent.CATEGORY_LAUNCHER);
    java.util.List<android.content.pm.ResolveInfo> apps=pm.queryIntentActivities(filter,0);
    apps.sort((a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
    CharSequence[] labels=new CharSequence[apps.size()];for(int j=0;j<apps.size();j++)labels[j]=apps.get(j).loadLabel(pm);
    Intent act=new Intent(this,ChooserActivity.class); // Safe app picker in an activity, since overlay cannot show Activity dialog directly.
    act.putExtra("key",key).putExtra("heading",title);newActivity(act);
  }
  @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
  @Override public void onDestroy(){closePanel();if(anchor!=null){try{wm.removeView(anchor);}catch(Exception ignored){}anchor=null;}super.onDestroy();}
  @Override public android.os.IBinder onBind(Intent i){return null;}
}
