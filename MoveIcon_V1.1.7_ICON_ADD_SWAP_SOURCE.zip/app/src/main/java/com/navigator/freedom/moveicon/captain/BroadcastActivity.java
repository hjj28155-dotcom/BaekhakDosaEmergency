package com.navigator.freedom.moveicon.captain;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import android.view.View;

/** Original station-based TV/FM/AM menus, not installed-app lists. */
public class BroadcastActivity extends Activity {
  private LinearLayout list;
  @Override public void onCreate(Bundle b){super.onCreate(b);
    String kind=getIntent().getStringExtra("kind");
    if(!"FM".equals(kind)&&!"AM".equals(kind))kind="TV";
    LinearLayout frame=Ui.column(this);setContentView(frame);
    frame.addView(Ui.title(this,kind+" · 방송국 선택"));
    TextView note=new TextView(this);
    note.setText("TV·라디오 방송국을 선택하세요. 공식 사이트로 연결하며, 로그인·재생 가능 여부는 각 방송사 정책에 따릅니다.");
    note.setTextSize(13);note.setTextColor(Ui.WHITE);note.setPadding(8,3,8,12);frame.addView(note);
    LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);
    for(String tab:new String[]{"TV","FM","AM"}){
      Button t=Ui.button(this,tab);tabs.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
      t.setOnClickListener(v->showStations(tab));
    }
    frame.addView(tabs);ScrollView scroll=new ScrollView(this);
    list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
    scroll.addView(list);frame.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    showStations(kind);
  }
  private void showStations(String kind){
    list.removeAllViews();list.addView(Ui.title(this,kind+" 방송국"));
    if("TV".equals(kind)){
      station("KBS 1TV 실시간", "https://onair.kbs.co.kr/index.html?ch_code=11&ch_type=globalList&sname=onair&stype=live");
      station("KBS 온에어 · 채널 선택", "https://onair.kbs.co.kr/");
      station("MBC 실시간 TV", "https://onair.imbc.com/");
      station("SBS 실시간 TV · 공식 사이트", "https://www.sbs.co.kr/");
    } else if("FM".equals(kind)){
      station("KBS Cool FM · Classic FM", "https://radio.kbs.co.kr/");
      station("MBC FM4U · mini", "https://miniwebapp.imbc.com/");
      station("CBS 음악FM", "https://www2.cbs.co.kr/radio/");
    } else {
      station("KBS 1라디오 · AM / FM", "https://radio.kbs.co.kr/");
      station("KBS 2라디오 · AM / FM", "https://radio.kbs.co.kr/");
      station("MBC 표준FM · AM 계열", "https://miniwebapp.imbc.com/");
    }
  }
  private void station(String name,String url){
    Ui.addButton(list,name,v->{
      Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
      try{startActivity(i);}catch(Exception e){Toast.makeText(this,"브라우저에서 열 수 없습니다",Toast.LENGTH_LONG).show();}
    });
  }
}
