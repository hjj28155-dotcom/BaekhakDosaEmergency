package com.navigator.freedom.moveicon.captain;

import android.app.Activity;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.graphics.drawable.Drawable;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Pick a real installed launcher app; saved packages are unique. */
public class AddIconActivity extends Activity {
  private final LinkedHashMap<String,ResolveInfo> candidates=new LinkedHashMap<>();
  private LinearLayout rows;
  private PackageManager pm;
  private final ArrayList<String> already=new ArrayList<>();
  @Override public void onCreate(Bundle saved){super.onCreate(saved);pm=getPackageManager();
    String existing=getSharedPreferences("anchor",0).getString("added_packages","");
    for(String pkg:existing.split("\\|"))if(!pkg.isEmpty()&&!already.contains(pkg))already.add(pkg);
    Intent query=new Intent(Intent.ACTION_MAIN);query.addCategory(Intent.CATEGORY_LAUNCHER);
    for(ResolveInfo item:pm.queryIntentActivities(query,0)){
      if(item.activityInfo!=null && item.activityInfo.packageName!=null){
        String pkg=item.activityInfo.packageName;
        if(!pkg.equals(getPackageName())&&!candidates.containsKey(pkg))candidates.put(pkg,item);
      }
    }
    LinearLayout root=Ui.column(this);setContentView(root);
    root.addView(Ui.title(this,"＋ 설치된 앱 아이콘 추가"));
    TextView info=new TextView(this);info.setText("추가할 앱을 선택하면 세로 메뉴 끝에 아이콘이 생깁니다. 같은 앱은 중복 추가하지 않습니다.");
    info.setTextColor(Ui.WHITE);info.setTextSize(14);root.addView(info);
    EditText search=new EditText(this);search.setSingleLine(true);search.setHint("앱 이름 검색");search.setHintTextColor(0xffb0bacb);search.setTextColor(Ui.WHITE);
    root.addView(search);
    ScrollView scroll=new ScrollView(this);rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
    scroll.addView(rows);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    search.addTextChangedListener(new TextWatcher(){
      public void beforeTextChanged(CharSequence s,int st,int c,int a){}
      public void onTextChanged(CharSequence s,int st,int before,int count){showApps(s.toString());}
      public void afterTextChanged(Editable e){}
    });showApps("");
  }
  private void showApps(String needle){
    rows.removeAllViews();ArrayList<Map.Entry<String,ResolveInfo>> list=new ArrayList<>(candidates.entrySet());
    list.sort((a,b)->String.valueOf(a.getValue().loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.getValue().loadLabel(pm))));
    int count=0;for(Map.Entry<String,ResolveInfo> entry:list){
      String pkg=entry.getKey();ResolveInfo res=entry.getValue();String title=String.valueOf(res.loadLabel(pm));
      if(!title.toLowerCase(Locale.ROOT).contains(needle.toLowerCase(Locale.ROOT)))continue;
      LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
      line.setPadding(Ui.dp(this,8),Ui.dp(this,6),Ui.dp(this,8),Ui.dp(this,6));
      try{ImageView image=new ImageView(this);image.setImageDrawable(res.loadIcon(pm));line.addView(image,new LinearLayout.LayoutParams(Ui.dp(this,42),Ui.dp(this,42)));}catch(Exception ignored){}
      TextView label=new TextView(this);label.setText(title+(already.contains(pkg)?" · 추가됨":""));label.setTextColor(Ui.WHITE);label.setTextSize(16);
      label.setPadding(Ui.dp(this,12),0,0,0);line.addView(label,new LinearLayout.LayoutParams(0,Ui.dp(this,54),1));
      if(already.contains(pkg))label.setAlpha(0.6f);
      line.setOnClickListener(v->select(pkg,title));rows.addView(line);count++;
    }
    if(count==0){TextView empty=Ui.title(this,"검색 결과가 없습니다");rows.addView(empty);}
  }
  private void select(String pkg,String title){
    if(already.contains(pkg)){Toast.makeText(this,"이미 추가한 앱입니다",Toast.LENGTH_SHORT).show();return;}
    if(pm.getLaunchIntentForPackage(pkg)==null){Toast.makeText(this,"실행할 수 없는 앱입니다",Toast.LENGTH_SHORT).show();return;}
    already.add(pkg);
    android.content.SharedPreferences prefs=getSharedPreferences("anchor",MODE_PRIVATE);
    prefs.edit().putString("added_packages",android.text.TextUtils.join("|",already)).apply();
    Intent service=new Intent(this,AnchorService.class).setAction("refresh");
    if(Build.VERSION.SDK_INT>=26)startForegroundService(service);else startService(service);
    Toast.makeText(this,"추가 완료: "+title,Toast.LENGTH_SHORT).show();finish();
  }
}
