package com.navigator.freedom.moveicon.captain;

import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.util.List;

/**
 * Open a copied MP4 using the phone's regular video player instead of a bespoke
 * in-app playback screen. Grants temporary read access to our private media file.
 */
public final class VideoOpener {
  private VideoOpener() {}

  public static boolean open(Context context, MediaLibrary.Item item) {
    if(item == null) return false;
    try {
      Uri stored=Uri.parse(item.uri);
      Uri playable;
      if("file".equalsIgnoreCase(stored.getScheme())) {
        File file=new File(stored.getPath());
        if(!file.isFile()) throw new java.io.FileNotFoundException("보관된 동영상 파일이 없습니다");
        playable=FileProvider.getUriForFile(context,
          context.getPackageName()+".fileprovider", file);
      } else if("content".equalsIgnoreCase(stored.getScheme())) {
        playable=stored;
      } else {
        throw new IllegalArgumentException("지원하지 않는 동영상 주소");
      }
      Intent view=new Intent(Intent.ACTION_VIEW);
      view.setDataAndType(playable,"video/mp4");
      view.addCategory(Intent.CATEGORY_DEFAULT);
      view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      view.setClipData(ClipData.newRawUri(item.title,playable));
      if(!(context instanceof android.app.Activity))view.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      // Android selects a saved default player, or presents the installed player choices.
      // No undocumented Samsung package name or arbitrary activity component is forced.
      context.startActivity(view);
      return true;
    } catch(ActivityNotFoundException e) {
      Toast.makeText(context,"동영상 플레이어가 없습니다. 휴대전화에서 영상 플레이어를 설치해 주세요",Toast.LENGTH_LONG).show();
    } catch(Exception e) {
      Toast.makeText(context,"동영상을 열지 못했습니다: "+e.getMessage(),Toast.LENGTH_LONG).show();
    }
    return false;
  }

  public static boolean openFirst(Context context) {
    List<MediaLibrary.Item> items=MediaLibrary.list(context,"MP4");
    if(items.isEmpty())return false;
    return open(context,items.get(0));
  }
}
