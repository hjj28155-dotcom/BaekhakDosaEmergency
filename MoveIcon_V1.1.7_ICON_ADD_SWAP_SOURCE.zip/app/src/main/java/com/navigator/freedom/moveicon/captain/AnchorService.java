package com.navigator.freedom.moveicon.captain;

import android.app.*;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** One anchor at the top of the scrollable panel. NO independent square floating anchor. */
public class AnchorService extends Service {
  private static final int ID = 1703;
  private final Handler handler = new Handler(Looper.getMainLooper());
  private WindowManager wm;
  private FrameLayout menu, panelContent;
  private ScrollView scroller;
  private WindowManager.LayoutParams panelParams;
  private android.content.SharedPreferences prefs;
  private int screenW, screenH, contentHeight, headerHeight, panelWidth;
  private boolean expanded;
  private final ArrayList<String> tileOrder=new ArrayList<>();
  private final LinkedHashMap<String,FrameLayout> tileViews=new LinkedHashMap<>();
  private float tileScale;
  private int tileBodyHeight;
  private static final String[] DEFAULT_IDS={"distribution","tv","fm","am","player","mp3","mp4","kakao","v7","youtube","settings","hide","update","stop"};
  private static final String ORDER_KEY="tile_order_v117";

  private int dp(float n){return Ui.dp(this,n);}
  private int cap(int v,int min,int max){return Math.max(min,Math.min(v,Math.max(min,max)));}

  @Override public void onCreate(){
    super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);
    prefs=getSharedPreferences("anchor",MODE_PRIVATE);readScreenSize();startPersistent();openPanel();
  }
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    if(intent!=null && "refresh".equals(intent.getAction())){closePanel();openPanel();}
    else if(menu==null)openPanel();return START_STICKY;
  }
  private void readScreenSize(){
    android.util.DisplayMetrics m=new android.util.DisplayMetrics();
    wm.getDefaultDisplay().getRealMetrics(m);screenW=m.widthPixels;screenH=m.heightPixels;
  }
  private WindowManager.LayoutParams params(int w,int h){
    WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,android.graphics.PixelFormat.TRANSLUCENT);
    p.gravity=Gravity.TOP|Gravity.LEFT;return p;
  }
  private void startPersistent(){
    String channel="anchor_one_20261022";
    NotificationChannel ch=new NotificationChannel(channel,"이동아이콘 메뉴 복구",NotificationManager.IMPORTANCE_LOW);
    ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    Intent back=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent pi=PendingIntent.getActivity(this,0,back,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Notification n=new Notification.Builder(this,channel).setSmallIcon(android.R.drawable.ic_menu_compass)
      .setContentTitle("항행의자유 이동아이콘")
      .setContentText("세로 메뉴가 숨겨졌다면 여기를 눌러 다시 여세요")
      .setContentIntent(pi).setOngoing(true).build();
    if(Build.VERSION.SDK_INT>=34)startForeground(ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
    else startForeground(ID,n);
  }
  private void toast(String msg){Toast.makeText(this,msg,Toast.LENGTH_LONG).show();}
  private void closePanel(){
    if(menu!=null){try{wm.removeView(menu);}catch(Exception ignored){}}
    menu=null;panelContent=null;scroller=null;panelParams=null;expanded=false;tileViews.clear();
  }
  private void resizePanel(){
    if(menu==null || panelParams==null)return;
    readScreenSize();
    int minimum=Math.min(contentHeight,Math.max(headerHeight+dp(76),dp(123)));
    int maxTop=Math.max(dp(8),screenH-minimum-dp(30));
    panelParams.y=cap(panelParams.y,dp(8),maxTop);
    panelParams.x=cap(panelParams.x,0,Math.max(0,screenW-panelParams.width));
    panelParams.height=Math.min(contentHeight,Math.max(minimum,screenH-panelParams.y-dp(30)));
    try{wm.updateViewLayout(menu,panelParams);}catch(Exception ignored){}
  }
  private Bitmap asset(String name){
    try(java.io.InputStream in=getAssets().open(name)){
      Bitmap b=BitmapFactory.decodeStream(in);
      if(b!=null)return b;
    }catch(Exception ignored){}
    return null;
  }
  private void openPanel(){
    if(menu!=null)return;
    readScreenSize();
    panelWidth=Math.min(dp(142),Math.max(dp(108),screenW-dp(28)));
    // Keep the approved artwork, narrow width and anchored header.
    tileScale=panelWidth/434f;
    headerHeight=Math.round(140*tileScale);
    loadOrder();
    int rows=(tileOrder.size()+1)/2;
    tileBodyHeight=Math.max(Math.round(203*tileScale),Math.round(rows*203*tileScale));
    contentHeight=headerHeight+tileBodyHeight;
    menu=new FrameLayout(this);
    LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
    ImageView header=new ImageView(this);
    Bitmap original=asset("approved_panel.jpg");
    if(original==null){menu=null;toast("승인된 메뉴 그림을 불러오지 못했습니다");return;}
    Bitmap top=Bitmap.createBitmap(original,0,0,original.getWidth(),Math.round(original.getHeight()*140f/1158f));
    original.recycle();header.setImageBitmap(top);header.setScaleType(ImageView.ScaleType.FIT_XY);
    header.setContentDescription("상단 금색 닻: 상하좌우 이동, 짧게 터치하면 숨김");
    panel.addView(header,new LinearLayout.LayoutParams(panelWidth,headerHeight));
    scroller=new ScrollView(this);scroller.setFillViewport(false);
    scroller.setVerticalScrollBarEnabled(true);scroller.setScrollbarFadingEnabled(false);
    scroller.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
    panelContent=new FrameLayout(this);panelContent.setBackgroundColor(0xff07172e);
    ImageView background=new ImageView(this);background.setScaleType(ImageView.ScaleType.FIT_XY);
    Bitmap bg=asset("menu_background.jpg");
    if(bg!=null){
      int cut=Math.min(bg.getHeight()-1,Math.round(bg.getWidth()*140f/434f));
      Bitmap body=Bitmap.createBitmap(bg,0,cut,bg.getWidth(),bg.getHeight()-cut);
      bg.recycle();background.setImageBitmap(body);
    }
    panelContent.addView(background,new FrameLayout.LayoutParams(panelWidth,tileBodyHeight));
    for(String id:tileOrder)addTile(id);
    layoutTiles();
    scroller.addView(panelContent,new ScrollView.LayoutParams(panelWidth,tileBodyHeight));
    panel.addView(scroller,new LinearLayout.LayoutParams(panelWidth,0,1));
    menu.addView(panel,new FrameLayout.LayoutParams(-1,-1));

    int minimum=Math.min(contentHeight,Math.max(headerHeight+dp(76),dp(123)));
    int maxTop=Math.max(dp(8),screenH-minimum-dp(30));
    int y=cap(prefs.getInt("panelY",dp(24)),dp(8),maxTop);
    int h=Math.min(contentHeight,Math.max(minimum,screenH-y-dp(30)));
    panelParams=params(panelWidth,h);
    panelParams.x=cap(prefs.getInt("panelX",(screenW-panelWidth)/2),0,Math.max(0,screenW-panelWidth));
    panelParams.y=y;
    // Only the GOLD ANCHOR moves the entire panel. Individual icons: long-press then drag.
    header.setOnTouchListener(new View.OnTouchListener(){
      float startRawX,startRawY;int startX,startY;boolean moved;
      @Override public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:
          startRawX=e.getRawX();startRawY=e.getRawY();startX=panelParams.x;startY=panelParams.y;moved=false;return true;
        case MotionEvent.ACTION_MOVE:
          int dx=Math.round(e.getRawX()-startRawX),dy=Math.round(e.getRawY()-startRawY);
          if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5))moved=true;
          if(moved){panelParams.x=startX+dx;panelParams.y=startY+dy;resizePanel();}return true;
        case MotionEvent.ACTION_UP:
          if(moved)prefs.edit().putInt("panelX",panelParams.x).putInt("panelY",panelParams.y).apply();
          else {closePanel();toast("숨김 완료 · 앱 아이콘 또는 알림에서 메뉴를 다시 여세요");}
          return true;
        case MotionEvent.ACTION_CANCEL:return true;
        default:return true;
      }}
    });
    try{wm.addView(menu,panelParams);expanded=true;}
    catch(Exception ex){menu=null;panelContent=null;panelParams=null;toast("메뉴 표시 오류: 다른 앱 위에 표시 권한 확인");}
  }
  // Only one object per ID: swapping exchanges slots in a persisted ordered list,
  // rather than copying one icon over the other.
  private void loadOrder(){
    tileOrder.clear();
    LinkedHashSet<String> permitted=new LinkedHashSet<>(Arrays.asList(DEFAULT_IDS));
    String apps=prefs.getString("added_packages","");
    for(String pkg:apps.split("\\|")){
      if(!pkg.isEmpty()&&getPackageManager().getLaunchIntentForPackage(pkg)!=null)
        permitted.add("app:"+pkg);
    }
    permitted.add("add");
    for(String id:prefs.getString(ORDER_KEY,"").split(",")){
      if(permitted.remove(id))tileOrder.add(id);
    }
    tileOrder.addAll(permitted);
    if(!tileOrder.contains("distribution"))tileOrder.add(0,"distribution");
    if(!tileOrder.contains("mp3"))tileOrder.add("mp3");
    // The + entry stays at the bottom even after another application was added.
    tileOrder.remove("add");tileOrder.add("add");
    saveOrder();
  }
  private void saveOrder(){prefs.edit().putString(ORDER_KEY,android.text.TextUtils.join(",",tileOrder)).apply();}
  private String titleOf(String id){
    switch(id){
      case "distribution":return "항행의자유\n배포용";
      case "tv":return "실시간 TV";
      case "fm":return "FM 라디오";
      case "am":return "AM 라디오";
      case "player":return "MP4 플레이어";
      case "mp3":return "내 파일 MP3";
      case "mp4":return "내 파일 MP4";
      case "kakao":return "카카오톡";
      case "v7":return "항행의자유 V7";
      case "youtube":return "유튜브";
      case "settings":return "설정";
      case "hide":return "숨김";
      case "update":return "업데이트";
      case "stop":return "전체 중지";
      case "add":return "아이콘 추가";
      default:
        if(id.startsWith("app:")){
          try{PackageManager pm=getPackageManager();return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(id.substring(4),0)));}
          catch(Exception ignored){return "추가 앱";}
        }
        return "아이콘";
    }
  }
  private String pictureOf(String id){
    switch(id){
      case "distribution":return "ico_distribution.png";
      case "tv":return "ico_tv.png";
      case "fm":return "ico_fm.png";
      case "am":return "ico_am.png";
      case "player":return "ico_player.png";
      case "mp3":return "ico_mp3.png";
      case "mp4":return "ico_mp4.png";
      case "kakao":return "ico_kakao.png";
      case "v7":return "ico_v7.png";
      case "youtube":return "ico_youtube.png";
      case "settings":return "ico_settings.png";
      case "hide":return "ico_hide.png";
      case "update":return "ico_update.png";
      case "stop":return "ico_stop.png";
      default:return null;
    }
  }
  private void activate(String id){
    switch(id){
      case "distribution":openDistribution();break;
      case "tv":broadcast("TV");break;
      case "fm":broadcast("FM");break;
      case "am":broadcast("AM");break;
      case "player":player("MP4");break;
      case "mp3":library("MP3");break;
      case "mp4":library("MP4");break;
      case "kakao":kakao();break;
      case "v7":chooseApp("V7","항행의자유 V7 선택");break;
      case "youtube":openWebsite("https://www.youtube.com/");break;
      case "settings":newActivity(new Intent(this,MainActivity.class).putExtra("show_settings",true));break;
      case "hide":closePanel();break;
      case "update":openUpdates();break;
      case "stop":stopSelf();break;
      case "add":newActivity(new Intent(this,AddIconActivity.class));break;
      default:
        if(id.startsWith("app:")){
          Intent launch=getPackageManager().getLaunchIntentForPackage(id.substring(4));
          if(launch!=null)newActivity(launch);
          else toast("앱이 설치되어 있지 않습니다");
        }
    }
  }
  private void addTile(String id){
    final float s=tileScale;
    final int tileW=Math.round(182*s),tileH=Math.round(191*s),iconSize=Math.round(139*s);
    FrameLayout container=new FrameLayout(this);
    LinearLayout inside=new LinearLayout(this);inside.setGravity(Gravity.CENTER_HORIZONTAL);
    inside.setOrientation(LinearLayout.VERTICAL);
    ImageView icon=new ImageView(this);
    String picture=pictureOf(id);
    if(picture!=null)icon.setImageBitmap(asset(picture));
    else if(id.startsWith("app:")){
      try{icon.setImageDrawable(getPackageManager().getApplicationIcon(id.substring(4)));}
      catch(Exception ignored){icon.setImageResource(android.R.drawable.sym_def_app_icon);}
    }else{
      TextView plus=new TextView(this);plus.setText("+");plus.setTextSize(42);plus.setTextColor(Ui.GOLD);
      plus.setGravity(Gravity.CENTER);plus.setBackground(Ui.bg(this,Ui.BLUE));
      inside.addView(plus,new LinearLayout.LayoutParams(iconSize,iconSize));
    }
    icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
    if(!"add".equals(id))inside.addView(icon,new LinearLayout.LayoutParams(iconSize,iconSize));
    TextView label=new TextView(this);label.setText(titleOf(id));label.setTextColor(0xffffffff);
    label.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,Math.max(9,Math.min(12,12*s*3f)));
    label.setGravity(Gravity.CENTER);label.setTypeface(null,android.graphics.Typeface.BOLD);
    label.setMaxLines(2);label.setIncludeFontPadding(false);
    inside.addView(label,new LinearLayout.LayoutParams(tileW,tileH-iconSize));
    container.addView(inside,new FrameLayout.LayoutParams(tileW,tileH));
    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(tileW,tileH);
    panelContent.addView(container,lp);tileViews.put(id,container);
    container.setContentDescription(titleOf(id)+" · 길게 누르면 아이콘 자리를 교환, 짧게 누르면 실행");
    container.setOnTouchListener(new View.OnTouchListener(){
      private float downX,downY;private int left0,top0;private boolean drag,scrolled;
      private final Runnable arm=()->{drag=true;container.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);container.bringToFront();
         if(scroller!=null)scroller.requestDisallowInterceptTouchEvent(true);};
      @Override public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:
          downX=e.getRawX();downY=e.getRawY();
          FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)container.getLayoutParams();
          left0=p.leftMargin;top0=p.topMargin;drag=false;scrolled=false;
          if(scroller!=null)scroller.requestDisallowInterceptTouchEvent(true);
          handler.postDelayed(arm,480);return true;
        case MotionEvent.ACTION_MOVE:
          int dx=Math.round(e.getRawX()-downX),dy=Math.round(e.getRawY()-downY);
          if(drag){
            FrameLayout.LayoutParams at=(FrameLayout.LayoutParams)container.getLayoutParams();
            at.leftMargin=cap(left0+dx,0,Math.max(0,panelWidth-tileW));
            at.topMargin=cap(top0+dy,0,Math.max(0,tileBodyHeight-tileH));
            container.setLayoutParams(at);
            return true;
          }
          if(Math.abs(dx)>dp(10)||Math.abs(dy)>dp(10)){
            scrolled=true;handler.removeCallbacks(arm);
            if(scroller!=null)scroller.requestDisallowInterceptTouchEvent(false);
          }
          return true;
        case MotionEvent.ACTION_UP:
          handler.removeCallbacks(arm);
          if(drag){
            FrameLayout.LayoutParams target=(FrameLayout.LayoutParams)container.getLayoutParams();
            int col=target.leftMargin+tileW/2>=panelWidth/2?1:0;
            int row=cap(Math.round((target.topMargin)/(203*s)),0,(tileOrder.size()-1)/2);
            int from=tileOrder.indexOf(id),to=cap(row*2+col,0,tileOrder.size()-1);
            if(from>=0&&to!=from){Collections.swap(tileOrder,from,to);saveOrder();}
            layoutTiles();
          }else if(!scrolled)activate(id);
          if(scroller!=null)scroller.requestDisallowInterceptTouchEvent(false);
          return true;
        case MotionEvent.ACTION_CANCEL:
          handler.removeCallbacks(arm);layoutTiles();
          if(scroller!=null)scroller.requestDisallowInterceptTouchEvent(false);
          return true;
        default:return true;
      }}
    });
  }
  private void layoutTiles(){
    for(int index=0;index<tileOrder.size();index++){
      View v=tileViews.get(tileOrder.get(index));if(v==null)continue;
      FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();
      lp.leftMargin=Math.round(((index%2==0)?25:224)*tileScale);
      lp.topMargin=Math.round((index/2)*203*tileScale);
      v.setLayoutParams(lp);
    }
  }
  private void newActivity(Intent i){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);closePanel();}
  private void library(String kind){newActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind));}
  private void player(String kind){
    if("MP4".equals(kind)){
      if(VideoOpener.openFirst(this)){closePanel();return;}
      newActivity(new Intent(this,LibraryActivity.class).putExtra("kind","MP4"));return;
    }
    newActivity(new Intent(this,PlayerActivity.class).putExtra("kind",kind));
  }
  private void broadcast(String kind){
    newActivity(new Intent(this,BroadcastActivity.class).putExtra("kind",kind));
  }
  private void openWebsite(String url){
    Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
    try{newActivity(i);}catch(Exception ex){toast("연결할 수 없습니다. 인터넷과 브라우저를 확인해 주세요.");}
  }
  private void openDistribution(){
    // Legacy MoveIcon V1.0.84 official distribution shortcut, preserved unchanged.
    openWebsite("https://hjj28155-dotcom.github.io/BaekhakDosaEmergency/");
  }
  private void kakao(){Intent i=getPackageManager().getLaunchIntentForPackage("com.kakao.talk");if(i!=null)newActivity(i);else toast("카카오톡을 설치해 주세요");}
  private void openUpdates(){
    Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://hjj28155-dotcom.github.io/BaekhakDosaEmergency/moveicon.html"));
    try{newActivity(i);}catch(Exception ex){toast("업데이트 페이지를 열 수 없습니다");}
  }
  private void chooseApp(String key,String title){
    String p=prefs.getString("app_"+key,"");
    Intent launch=p.isEmpty()?null:getPackageManager().getLaunchIntentForPackage(p);
    if(launch!=null)newActivity(launch);
    else newActivity(new Intent(this,ChooserActivity.class).putExtra("key",key).putExtra("heading",title));
  }
  @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);readScreenSize();resizePanel();}
  @Override public void onDestroy(){closePanel();handler.removeCallbacksAndMessages(null);super.onDestroy();}
  @Override public IBinder onBind(Intent intent){return null;}
}
