⚓ MoveIcon V1.1.5 NATIVE VIDEO TEST

Changes from V1.1.4:
- MP4 launches the phone's familiar ACTION_VIEW video player (Samsung/default/installed choice).
- FileProvider grants temporary read permission to MP4 copies in app private and app external-files directories.
- MP3 retains its in-app Media3 music player.
- The approved panel, anchor interactions, scroll, icon position and folder importing code remain unchanged.
- Chosen external players may not support automatic playlist continuation; multiple selected MP4s open the first selection.
- It is a separate test package, not an update over the installed V1.0.97-NEW or V1.1.4.
- Device install/playback is not verified. Never delete installed original or MP3/MP4 data.
