package com.navigator.freedom.moveicon.captain;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.content.ContentUris;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

/** Real on-device media folders. Does not pretend to be Samsung My Files. */
public class PhoneFilesActivity extends Activity {
  private static final int PERM=440;
  private final ExecutorService pool=Executors.newSingleThreadExecutor();
  private final LinkedHashSet<String> selected=new LinkedHashSet<>();
  private final LinkedHashMap<String,List<Entry>> folders=new LinkedHashMap<>();
  private String kind="MP4",folder=null;
  private LinearLayout root,body;
  private TextView status;
  private Button importButton;
  private boolean importing=false;
  static final class Entry {
    final Uri uri;final String name;
    Entry(Uri uri,String name){this.uri=uri;this.name=name;}
  }
  @Override public void onCreate(Bundle state){super.onCreate(state);
    kind="MP3".equals(getIntent().getStringExtra("kind"))?"MP3":"MP4";
    build();checkPermissionAndLoad();
  }
  private void build(){
    root=Ui.column(this);setContentView(root);
    root.addView(Ui.title(this,"내 휴대전화 폴더 · "+kind));
    status=new TextView(this);status.setTextColor(Ui.WHITE);status.setTextSize(13);
    status.setPadding(Ui.dp(this,8),Ui.dp(this,6),Ui.dp(this,8),Ui.dp(this,10));
    root.addView(status);
    LinearLayout controls=new LinearLayout(this);root.addView(controls);
    Button goBack=Ui.button(this,"← 폴더 목록");
    controls.addView(goBack,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
    goBack.setOnClickListener(v->{folder=null;showFolder();});
    Button refresh=Ui.button(this,"⟳ 다시 검색");
    controls.addView(refresh,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
    refresh.setOnClickListener(v->checkPermissionAndLoad());
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
    body=new LinearLayout(this);body.setOrientation(1);scroll.addView(body);
    root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout selectionBar=new LinearLayout(this);
    root.addView(selectionBar);
    Button selectFolder=Ui.button(this,"현재 폴더 전체선택");
    selectionBar.addView(selectFolder,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));
    selectFolder.setOnClickListener(v->selectAll(false));
    Button selectAll=Ui.button(this,"모든 폴더 전체선택");
    selectionBar.addView(selectAll,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));
    selectAll.setOnClickListener(v->selectAll(true));
    Ui.addButton(root,"☐ 선택해제 · 다시 고르기",v->{selected.clear();showFolder();});
    importButton=Ui.button(this,"선택한 파일 보관 (0개)");
    root.addView(importButton,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));
    importButton.setOnClickListener(v->importSelection());
    Ui.addButton(root,"기타 위치 · 안드로이드 파일 선택",v->{
      Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
      i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("MP3".equals(kind)?"audio/*":"video/*");
      i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
      i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      startActivityForResult(i,441);
    });
  }
  private String permission(){
    if(Build.VERSION.SDK_INT>=33) return "MP3".equals(kind)?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_MEDIA_VIDEO;
    return Manifest.permission.READ_EXTERNAL_STORAGE;
  }
  private void checkPermissionAndLoad(){
    String p=permission();
    if(checkSelfPermission(p)!=PackageManager.PERMISSION_GRANTED){
      status.setText("휴대전화의 "+kind+" 파일을 찾으려면 음악·동영상 접근을 허용해 주세요.");
      requestPermissions(new String[]{p},PERM);return;
    }
    loadMedia();
  }
  @Override public void onRequestPermissionsResult(int code,String[] perms,int[] grants){
    super.onRequestPermissionsResult(code,perms,grants);
    if(code==PERM){
      if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)loadMedia();
      else status.setText("접근 권한이 없습니다. 아래 ‘안드로이드 파일 선택’으로도 가져올 수 있습니다.");
    }
  }
  private void loadMedia(){
    status.setText("휴대전화 저장공간을 검색 중입니다…");
    pool.execute(()->{
      LinkedHashMap<String,List<Entry>> got=new LinkedHashMap<>();String error="";
      Uri base="MP3".equals(kind)?MediaStore.Audio.Media.EXTERNAL_CONTENT_URI:MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
      String[] projection=Build.VERSION.SDK_INT>=29?
        new String[]{MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.RELATIVE_PATH}:
        new String[]{MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.DATA};
      try(Cursor cursor=getContentResolver().query(base,projection,null,null,MediaStore.MediaColumns.DISPLAY_NAME+" COLLATE NOCASE ASC")){
        if(cursor!=null){int id=cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
          int name=cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
          int dir=cursor.getColumnIndexOrThrow(Build.VERSION.SDK_INT>=29?MediaStore.MediaColumns.RELATIVE_PATH:MediaStore.MediaColumns.DATA);
          while(cursor.moveToNext()){
            String file=cursor.getString(name);if(file==null)continue;
            if(!file.toLowerCase(Locale.ROOT).endsWith("MP3".equals(kind)?".mp3":".mp4"))continue;
            String path=cursor.getString(dir);
            if(path==null||path.trim().isEmpty())path="기타 폴더";
            if(Build.VERSION.SDK_INT<29){int pos=path.lastIndexOf('/');path=pos<0?"기타 폴더":path.substring(0,pos);}
            while(path.endsWith("/"))path=path.substring(0,path.length()-1);
            if(path.isEmpty())path="내부 저장공간";
            Uri item=ContentUris.withAppendedId(base,cursor.getLong(id));
            if(!got.containsKey(path))got.put(path,new ArrayList<>());
            got.get(path).add(new Entry(item,file));
          }
        }
      }catch(Exception e){error=e.getMessage()==null?"저장공간 조회 실패":e.getMessage();}
      String err=error;
      runOnUiThread(()->{if(isFinishing()||isDestroyed())return;
        folders.clear();List<String> keys=new ArrayList<>(got.keySet());Collections.sort(keys,String.CASE_INSENSITIVE_ORDER);
        for(String k:keys)folders.put(k,got.get(k));
        if(folder!=null&&!folders.containsKey(folder))folder=null;
        showFolder();if(!err.isEmpty())status.setText("파일 검색 문제: "+err+". 다른 선택 방법도 사용할 수 있습니다.");
      });
    });
  }
  private void showFolder(){
    if(body==null)return;body.removeAllViews();int total=0;for(List<Entry> e:folders.values())total+=e.size();
    status.setText("내부 저장공간 · "+folders.size()+"개 폴더, "+total+"개 "+kind+" 파일"+(folder==null?"":"\n현재 폴더: "+folder));
    if(folder==null){
      if(folders.isEmpty()) {TextView empty=Ui.title(this,"검색된 파일이 없습니다. 아래의 다른 파일 선택 방법도 이용할 수 있습니다.");empty.setTextSize(15);body.addView(empty);}
      for(Map.Entry<String,List<Entry>> p:folders.entrySet()){
        Button b=Ui.button(this,"📁 "+p.getKey()+"   ("+p.getValue().size()+"개)");
        b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,Ui.dp(this,60));lp.bottomMargin=Ui.dp(this,5);body.addView(b,lp);
        b.setOnClickListener(v->{folder=p.getKey();showFolder();});
      }
    }else{
      for(Entry item:folders.get(folder)){
        CheckBox c=new CheckBox(this);c.setText(item.name);c.setTextColor(Ui.WHITE);c.setTextSize(14);
        c.setPadding(Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5),Ui.dp(this,5));
        c.setChecked(selected.contains(item.uri.toString()));
        c.setOnCheckedChangeListener((button,checked)->{
          if(checked)selected.add(item.uri.toString());else selected.remove(item.uri.toString());
          importButton.setText("선택한 파일 보관 ("+selected.size()+"개)");
        });body.addView(c,new LinearLayout.LayoutParams(-1,Ui.dp(this,62)));
      }
    }
    importButton.setText("선택한 파일 보관 ("+selected.size()+"개)");
    // Keep selection count visible while browsing other folders.
    status.append("\n선택된 파일: "+selected.size()+"개 · 전체선택/선택해제 가능");
  }
  private void selectAll(boolean allFolders){
    if(importing)return;
    if(folders.isEmpty()){
      Toast.makeText(this,"먼저 MP3·MP4 폴더를 불러와 주세요",Toast.LENGTH_SHORT).show();return;
    }
    if(allFolders || folder==null){
      for(List<Entry> entries:folders.values())for(Entry entry:entries)selected.add(entry.uri.toString());
    }else{
      List<Entry> entries=folders.get(folder);
      if(entries!=null)for(Entry entry:entries)selected.add(entry.uri.toString());
    }
    showFolder();
    Toast.makeText(this,selected.size()+"개 파일 선택됨",Toast.LENGTH_SHORT).show();
  }
  private void importSelection(){
    if(importing)return;
    if(selected.isEmpty()){Toast.makeText(this,"보관할 "+kind+" 파일을 먼저 선택해 주세요",Toast.LENGTH_SHORT).show();return;}
    ArrayList<Uri> picked=new ArrayList<>();for(String v:selected)picked.add(Uri.parse(v));
    importing=true;importButton.setEnabled(false);status.setText(picked.size()+"개 파일을 복사하고 있습니다. 원본은 그대로 둡니다.");
    pool.execute(()->{
      MediaLibrary.CopyResult result=MediaLibrary.addUris(getApplicationContext(),picked,kind);
      runOnUiThread(()->{if(isFinishing()||isDestroyed())return;
        importing=false;importButton.setEnabled(true);selected.clear();showFolder();
        String message=result.count+"개 보관 완료"+(result.failed>0?", "+result.failed+"개 실패: "+result.lastError:"");
        status.setText(message+"\n원본 파일은 삭제하지 않았습니다.");
        Toast.makeText(this,message,Toast.LENGTH_LONG).show();
      });
    });
  }
  @Override protected void onActivityResult(int request,int result,Intent data){
    super.onActivityResult(request,result,data);
    if(request!=441||result!=RESULT_OK||data==null)return;
    // Fallback picker result is forwarded to library for durable copy.
    // Copy while the temporary picker read permission is valid.
    ArrayList<Uri> uris=new ArrayList<>();
    if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)uris.add(data.getClipData().getItemAt(i).getUri());}
    else if(data.getData()!=null)uris.add(data.getData());
    if(uris.isEmpty())return;
    importing=true;importButton.setEnabled(false);status.setText("선택한 파일을 복사 중입니다…");
    pool.execute(()->{MediaLibrary.CopyResult r=MediaLibrary.addUris(getApplicationContext(),uris,kind);
      runOnUiThread(()->{if(isFinishing()||isDestroyed())return;importing=false;importButton.setEnabled(true);
        status.setText(r.count+"개 보관 완료"+(r.failed>0?" ("+r.failed+"개 실패)":""));
        Toast.makeText(this,r.count+"개 보관 완료",Toast.LENGTH_LONG).show();});
    });
  }
  @Override protected void onDestroy(){pool.shutdown();super.onDestroy();}
}
