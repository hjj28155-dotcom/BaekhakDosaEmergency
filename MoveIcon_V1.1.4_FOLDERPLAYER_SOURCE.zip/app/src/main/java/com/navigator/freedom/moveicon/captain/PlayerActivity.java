package com.navigator.freedom.moveicon.captain;

import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.*;
import android.util.Rational;
import android.view.*;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.util.*;

/** Separate MP3 and MP4 UX, playlist navigation and error messages. */
public class PlayerActivity extends Activity {
  private ExoPlayer player;
  private PlayerView playerView;
  private String kind;
  private TextView title,count;
  private Button playPause;
  private List<MediaLibrary.Item> items=new ArrayList<>();
  private boolean landscape=false;
  private boolean selectionPlaylist=false;
  private int lastListSize=-1;
  @Override public void onCreate(Bundle state){super.onCreate(state);
    kind=getIntent().getStringExtra("kind");if(!"MP3".equals(kind))kind="MP4";
    items=MediaLibrary.list(this,kind);
    ArrayList<Integer> wanted=getIntent().getIntegerArrayListExtra("selectedIndices");
    if(wanted!=null&&!wanted.isEmpty()){
      ArrayList<MediaLibrary.Item> selection=new ArrayList<>();
      for(Integer n:wanted)if(n!=null&&n>=0&&n<items.size())selection.add(items.get(n));
      if(!selection.isEmpty()){items=selection;selectionPlaylist=true;}
    }
    if(items.isEmpty()){
      Toast.makeText(this,"먼저 내 파일에서 "+kind+" 파일을 불러오세요",Toast.LENGTH_LONG).show();
      startActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind));finish();return;
    }
    render();createPlayer(getIntent().getIntExtra("index",0));
  }
  private void render(){
    LinearLayout root=Ui.column(this);setContentView(root);
    title=Ui.title(this,("MP3".equals(kind)?"🎵 ":"🎬 ")+kind+" 플레이어");title.setSingleLine(true);
    title.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
    root.addView(title);
    count=new TextView(this);count.setTextColor(Ui.GOLD);count.setTextSize(13);count.setGravity(Gravity.CENTER);
    root.addView(count);
    if("MP4".equals(kind)){
      playerView=new PlayerView(this);playerView.setUseController(true);
      playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
      playerView.setKeepScreenOn(true);
      root.addView(playerView,new LinearLayout.LayoutParams(-1,0,1));
    }else{
      LinearLayout album=new LinearLayout(this);album.setGravity(Gravity.CENTER);album.setOrientation(1);
      album.setBackground(Ui.bg(this,Ui.BLUE));
      TextView art=new TextView(this);art.setText("♫");art.setTextColor(Ui.GOLD);art.setTextSize(90);art.setGravity(Gravity.CENTER);
      album.addView(art);TextView hint=new TextView(this);
      hint.setText("음악 연속 재생 · 이전곡 / 다음곡 / 속도 변경");
      hint.setGravity(Gravity.CENTER);hint.setTextColor(Ui.WHITE);hint.setTextSize(14);album.addView(hint);
      root.addView(album,new LinearLayout.LayoutParams(-1,0,1));
    }
    LinearLayout transport=new LinearLayout(this);transport.setGravity(Gravity.CENTER);
    root.addView(transport);
    makeButton(transport,"◀ 이전",()->previous());
    playPause=Ui.button(this,"⏸ 일시정지");
    transport.addView(playPause,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));
    playPause.setOnClickListener(v->{if(player==null)return;if(player.isPlaying())player.pause();else player.play();refresh();});
    makeButton(transport,"다음 ▶",()->next());
    LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER);root.addView(tools);
    makeButton(tools,"속도",this::speedDialog);
    makeButton(tools,"반복",this::repeatToggle);
    makeButton(tools,"파일 추가",()->startActivity(new Intent(this,LibraryActivity.class).putExtra("kind",kind)));
    if("MP4".equals(kind)){
      LinearLayout videoTools=new LinearLayout(this);root.addView(videoTools);
      makeButton(videoTools,"⛶ 전체화면",this::toggleFullScreen);
      makeButton(videoTools,"▣ 작은 화면",this::pip);
    }
  }
  private void makeButton(LinearLayout parent,String text,Runnable task){
    Button button=Ui.button(this,text);
    button.setTextSize(12);button.setPadding(0,0,0,0);
    parent.addView(button,new LinearLayout.LayoutParams(0,Ui.dp(this,49),1));
    button.setOnClickListener(v->task.run());
  }
  private void createPlayer(int index){
    player=new ExoPlayer.Builder(this).build();
    player.setHandleAudioBecomingNoisy(true);
    player.setAudioAttributes(androidx.media3.common.AudioAttributes.DEFAULT,true);
    if(playerView!=null)playerView.setPlayer(player);
    List<MediaItem> queue=new ArrayList<>();
    for(MediaLibrary.Item it:items)queue.add(MediaItem.fromUri(Uri.parse(it.uri)));
    player.setMediaItems(queue,Math.max(0,Math.min(index,items.size()-1)),0);
    player.setRepeatMode(Player.REPEAT_MODE_ALL);
    player.addListener(new Player.Listener(){
      @Override public void onMediaItemTransition(MediaItem item,int reason){refresh();}
      @Override public void onIsPlayingChanged(boolean playing){refresh();}
      @Override public void onPlayerError(PlaybackException e){
        Toast.makeText(PlayerActivity.this,"재생할 수 없는 파일입니다. 내 파일에서 다시 가져와 주세요. ("+e.getErrorCodeName()+")",Toast.LENGTH_LONG).show();
        refresh();
      }
    });
    lastListSize=items.size();player.prepare();player.play();refresh();
  }
  private void refresh(){
    if(player==null||title==null)return;
    int n=player.getCurrentMediaItemIndex();
    if(n>=0&&n<items.size())title.setText(MediaLibrary.shortName(items.get(n).title));
    if(count!=null)count.setText((Math.max(n,0)+1)+" / "+items.size()+"    ·    "+("MP3".equals(kind)?"음악":"영상"));
    if(playPause!=null)playPause.setText(player.isPlaying()?"⏸ 일시정지":"▶ 재생");
  }
  private void previous(){if(player==null)return;if(player.hasPreviousMediaItem())player.seekToPreviousMediaItem();else player.seekTo(0,0);player.play();refresh();}
  private void next(){if(player==null)return;if(player.hasNextMediaItem())player.seekToNextMediaItem();else player.seekTo(0,0);player.play();refresh();}
  private void repeatToggle(){if(player==null)return;
    int mode=player.getRepeatMode()==Player.REPEAT_MODE_ONE?Player.REPEAT_MODE_ALL:Player.REPEAT_MODE_ONE;
    player.setRepeatMode(mode);Toast.makeText(this,mode==Player.REPEAT_MODE_ONE?"현재 파일 반복":"전체 파일 연속 반복",Toast.LENGTH_SHORT).show();
  }
  private void speedDialog(){if(player==null)return;
    final float[] speeds={.75f,1f,1.25f,1.5f,2f};
    new AlertDialog.Builder(this).setTitle("재생 속도").setItems(new String[]{"0.75배","1배 (기본)","1.25배","1.5배","2배"},
      (dialog,which)->player.setPlaybackParameters(new PlaybackParameters(speeds[which]))).show();
  }
  private void toggleFullScreen(){
    landscape=!landscape;setRequestedOrientation(landscape?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    if(landscape)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    else getWindow().getDecorView().setSystemUiVisibility(0);
  }
  private void pip(){
    if(Build.VERSION.SDK_INT>=26){try{
      enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(16,9)).build());
    }catch(Exception e){Toast.makeText(this,"이 휴대전화에서는 작은 화면을 사용할 수 없습니다",Toast.LENGTH_SHORT).show();}}
  }
  @Override protected void onResume(){super.onResume();
    if(player!=null && !selectionPlaylist){
      List<MediaLibrary.Item> refreshed=MediaLibrary.list(this,kind);
      if(refreshed.size()!=lastListSize){
        int old=player.getCurrentMediaItemIndex();long pos=player.getCurrentPosition();
        items=refreshed;List<MediaItem> queue=new ArrayList<>();
        for(MediaLibrary.Item it:items)queue.add(MediaItem.fromUri(Uri.parse(it.uri)));
        if(!queue.isEmpty()){
          player.setMediaItems(queue,Math.max(0,Math.min(old,queue.size()-1)),Math.max(0,pos));
          player.prepare();player.play();
        }lastListSize=items.size();refresh();
      }
    }
  }
  @Override public void onPictureInPictureModeChanged(boolean isInPip,Configuration config){
    super.onPictureInPictureModeChanged(isInPip,config);
    if(title!=null)title.setVisibility(isInPip?View.GONE:View.VISIBLE);
    if(count!=null)count.setVisibility(isInPip?View.GONE:View.VISIBLE);
  }
  @Override protected void onDestroy(){if(playerView!=null)playerView.setPlayer(null);
    if(player!=null){player.release();player=null;}super.onDestroy();}
}
