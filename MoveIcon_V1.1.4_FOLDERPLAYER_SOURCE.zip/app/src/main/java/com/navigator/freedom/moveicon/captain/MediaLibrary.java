package com.navigator.freedom.moveicon.captain;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.util.*;

/** Copy instead of merely recording an ephemeral Samsung picker URI. Original is never deleted. */
public final class MediaLibrary {
  static final class Item {final String uri,title,kind;Item(String u,String t,String k){uri=u;title=t;kind=k;}}
  static final class CopyResult {int count,failed;String lastError="";}
  static String name(Context c,Uri uri){
    try(Cursor cur=c.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
      if(cur!=null&&cur.moveToFirst())return cur.getString(0);
    }catch(Exception ignored){}
    String seg=uri.getLastPathSegment();return seg==null?"선택한 파일":seg;
  }
  static String shortName(String n){
    String s=n.replaceAll("(?i)(?:__[a-f0-9]{8,}[-_a-f0-9]*)(?=\\.(mp3|mp4)$)","");
    return s.length()>94?s.substring(0,90)+"…":s;
  }
  static List<Item> list(Context c,String kind){
    ArrayList<Item> items=new ArrayList<>();
    try{
      JSONArray src=new JSONArray(c.getSharedPreferences("media",0).getString(kind,"[]"));
      for(int i=0;i<src.length();i++){
        JSONObject it=src.getJSONObject(i);
        items.add(new Item(it.getString("uri"),it.getString("name"),kind));
      }
    }catch(Exception ignored){}
    return items;
  }
  private static void save(Context c,String kind,List<Item> items){
    JSONArray result=new JSONArray();
    for(Item it:items){JSONObject o=new JSONObject();try{o.put("uri",it.uri);o.put("name",it.title);}catch(Exception ignored){}result.put(o);}
    c.getSharedPreferences("media",0).edit().putString(kind,result.toString()).apply();
  }
  static CopyResult addCopies(Context c,Intent data,String kind){
    if(data==null)return new CopyResult();
    ArrayList<Uri> chosen=new ArrayList<>();
    if(data.getClipData()!=null){
      for(int i=0;i<data.getClipData().getItemCount();i++)chosen.add(data.getClipData().getItemAt(i).getUri());
    }else if(data.getData()!=null)chosen.add(data.getData());
    return addUris(c,chosen,kind);
  }
  static CopyResult addUris(Context c,List<Uri> chosen,String kind){
    CopyResult result=new CopyResult();if(chosen==null)return result;
    List<Item> prev=list(c,kind);
    File folder=c.getExternalFilesDir(kind);
    if(folder==null)folder=new File(c.getFilesDir(),kind);
    if(!folder.isDirectory()&&!folder.mkdirs()){
      result.failed=chosen.size();result.lastError="보관 폴더 생성 실패";return result;
    }
    for(Uri uri:chosen){
      if(uri==null)continue;
      String display=name(c,uri);
      // Keep only the requested type, do not accidentally ingest unrelated media.
      String ext="MP3".equals(kind)?".mp3":".mp4";
      String lower=display.toLowerCase(Locale.ROOT);
      if(!lower.endsWith(ext)){result.failed++;result.lastError="형식 불일치: "+shortName(display);continue;}
      String safe=display.replaceAll("[\\\\/\\p{Cntrl}:*?\"<>|]","_");
      if(safe.length()>95)safe=safe.substring(0,95-ext.length())+ext;
      File tmp=null;
      try{
        String unique=UUID.randomUUID().toString().substring(0,8);
        File dest=new File(folder,unique+"_"+safe);
        tmp=new File(folder,unique+"_pending.part");
        try(InputStream in=c.getContentResolver().openInputStream(uri);OutputStream out=new BufferedOutputStream(new FileOutputStream(tmp))){
          if(in==null)throw new IOException("파일 읽기 권한이 없습니다");
          byte[] block=new byte[65536];int n;long bytes=0;
          while((n=in.read(block))!=-1){out.write(block,0,n);bytes+=n;}
          if(bytes==0)throw new IOException("빈 파일");
        }
        if(!tmp.renameTo(dest))throw new IOException("파일 저장 실패");
        prev.add(new Item(Uri.fromFile(dest).toString(),display,kind));result.count++;
      }catch(Exception e){result.failed++;result.lastError=e.getMessage()==null?"읽기 실패":e.getMessage();
        if(tmp!=null)tmp.delete();}
    }
    save(c,kind,prev);return result;
  }
}
